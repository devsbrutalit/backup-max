const express = require('express')
const axios = require('axios')
const app = express()

app.use(express.urlencoded({extended: false}))
app.set('view engine', 'ejs')
app.use(express.static('public'));

app.get('/', async (req, res) => { 
    //tentando fazer a chamada da api com os produtos para renderizar a pagina
    try {
        const data = await axios.get('https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/products')
        return res.render('index', {data: data})
    } catch (error) {
        res.send(error.message)
    }
    
})

app.get('/product/:pk', async(req, res) => {
    try {
        const pk = req.params.pk
        const data = await axios.get('https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/product/' + pk)
        const product = data.data[0]
        return res.render('product', {data: product})

    } catch(error) {
        res.send(error.message)
    }
})



app.listen(8080,() => {
    console.log('ouvindo na 8080')
})