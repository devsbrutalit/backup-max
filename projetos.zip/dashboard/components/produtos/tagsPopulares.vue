<template>
  <v-card>
    <v-card-title primary-title> Tags mais populares </v-card-title>
    <v-card-text>
      <v-chip
        v-for="item in getTags()"
        :key="item"
        class="mx-1 white--text"
        color="blue"
        >{{ item }}</v-chip
      >
    </v-card-text>
    <v-card-actions class="text-center" style="display: block">
      <span @click="dialogTags = !dialogTags">View All</span>
    </v-card-actions>

    <v-dialog
      v-model="dialogTags"
      scrollable
      :overlay="false"
      max-width="500px"
      transition="dialog-transition"
    >
      <v-card>
        <v-card-title primary-title> Todas as Tags </v-card-title>
        <v-card-text>
          <v-chip
            v-for="item in getTags()"
            :key="item"
            class="mx-1 white--text"
            color="blue"
            >{{ item }}</v-chip
          >
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-card>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
export default {
  data() {
    return {
      dialogTags: false,
    };
  },
  computed: {
    ...mapGetters("products", ["allproducts"]),
  },
  methods: {
    getTags() {
      var tags = [];
      this.allproducts.find((item) => {
        if (item.productTag) {
          item.productTag.find((text) => {
            tags.push(text.text);
          });
        }
      });
      return tags;
    },
  },
};
</script>

<style>
</style>