<template>
  <div style="height: 100%">
    <ProdutoVar :editItem="editItem" v-if="editItem.productVariations" />
    <Produto :editItem="editItem" v-else />
  </div>
</template>

<script>
import Produto from "./edit_products_modules/produto_edit.vue";
import ProdutoVar from "./edit_products_modules/produto_var_edit.vue";
export default {
  components: {
    Produto,
    ProdutoVar,
  },
  data() {
    return {};
  },
  props: {
    editItem: Object,
  },
};
</script>


<style scoped>
.alignCenter {
  width: 90%;
  margin: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
.cardChoise {
  display: block;
}
@media only screen and (max-width: 960px) {
  .alignCenter {
    width: 340px;
  }
  .cardChoise {
    font-size: 15px;
  }
}
</style>