<template>
  <v-container>
    <div v-show="showChoice" class="text-center alignCenter">
      <h2>Tipo de produto</h2>

      <v-row no-gutters class="mt-5">
        <v-col
          cols="6"
          :class="$vuetify.breakpoint.smAndDown ? 'px-2' : 'px-10'"
        >
          <v-hover v-slot="{ hover }">
            <v-card
              height="100%"
              :elevation="hover ? 16 : 2"
              :style="{ transform: hover ? 'translate(0, -5px)' : '' }"
              style="transition: all 0.1s ease-out"
              color="white"
              @click="showCreateProduct(0)"
            >
              <v-card-title class="cardChoise"> Sem Variação </v-card-title>
              <v-img
                class="ma-auto"
                contain
                :width="$vuetify.breakpoint.smAndDown ? 110 : 150"
                :src="require('@/assets/img/produto.jpg')"
              ></v-img>
            </v-card>
          </v-hover>
        </v-col>

        <v-col
          cols="6"
          :class="$vuetify.breakpoint.smAndDown ? 'px-2' : 'px-10'"
        >
          <v-hover v-slot="{ hover }">
            <v-card
              height="100%"
              :elevation="hover ? 16 : 2"
              :style="{ transform: hover ? 'translate(0, -5px)' : '' }"
              style="transition: all 0.1s ease-out"
              @click="showCreateProduct(1)"
            >
              <v-card-title class="cardChoise"> Com Variação </v-card-title>
              <v-img
                class="ma-auto"
                contain
                :width="$vuetify.breakpoint.smAndDown ? 110 : 150"
                :src="require('@/assets/img/produtoVariado.jpg')"
              ></v-img>
            </v-card>
          </v-hover>
        </v-col>
        <v-col
          cols="4"
          :class="$vuetify.breakpoint.smAndDown ? 'px-2' : 'px-10'"
        >

        <!--
          <v-hover v-slot="{ hover }">
            <v-card
              height="100%"
              :elevation="hover ? 16 : 2"
              :style="{ transform: hover ? 'translate(0, -5px)' : '' }"
              style="transition: all 0.1s ease-out"
              color="white"
              @click="showCreateProduct(2)"
            >
            
              <v-card-title class="cardChoise"> Kit / Combo </v-card-title>
              <v-img
                class="ma-auto"
                contain
                :width="$vuetify.breakpoint.smAndDown ? 150 : 200"
                :src="require('@/assets/img/kitConjunto.jpg')"
              ></v-img>
            </v-card>
          </v-hover>
        -->
        </v-col>
      </v-row>
    </div>

    <Produto v-if="showCreateForm === 0" />
    <ProdutoVar v-if="showCreateForm === 1" />
    <!--<ProdutoCombo v-if="showCreateForm === 2" /> -->
  </v-container>
</template>

<script>
import Produto from "./add_produtos_modules/produto";
import ProdutoVar from "./add_produtos_modules/produto_var";
import ProdutoCombo from "./add_produtos_modules/produto_combo";
export default {
  components: {
    Produto,
    ProdutoVar,
    ProdutoCombo,
  },
  data() {
    return {
      showChoice: true,
      showCreateForm: "",
    };
  },
  methods: {
    showCreateProduct(value) {
      this.showCreateForm = value;
      this.showChoice = false;
    },
  },
};
</script>


<style scoped>
.alignCenter {
  width: 90%;
  margin: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
}
.cardChoise {
  display: block;
}
@media only screen and (max-width: 960px) {
  .alignCenter {
    width: 340px;
  }
  .cardChoise {
    font-size: 15px;
  }
}
</style>