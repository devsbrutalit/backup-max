<template>
  <v-container>
    <v-stepper
      v-model="e1"
      class="pb-2"
      style="box-shadow: none; background: transparent"
    >
      <h1 class="text-center">Editar Produto</h1>
      <!-- Step 1 -->
      <v-stepper-items>
        <v-stepper-content step="1" class="px-2">
          <v-row class="ma-0">
            <v-col cols="12">
              <v-card class="px-5" tile color="transparent" elevation="0">
                <v-row>
                  <!-- Nome Produto -->
                  <v-col cols="12" sm="6" md="6">
                    <div>Nome do produto</div>
                    <v-text-field
                      v-model="editItem.productName"
                      :error-messages="productNameErrors"
                      @input="$v.editItem.productName.$touch()"
                      @blur="$v.editItem.productName.$touch()"
                      required
                      solo
                    ></v-text-field>
                  </v-col>

                  <!-- Marca Produto -->
                  <!-- <v-col cols="12" sm="6" md="6">
                    <div>Marca</div>
                    <v-text-field
                      v-model="editItem.productMarca"
                      :error-messages="editItem.productMarcaErrors"
                      @input="$v.editItem.productMarca.$touch()"
                      @blur="$v.editItem.productMarca.$touch()"
                      required
                      solo
                    ></v-text-field>
                  </v-col> -->

                  <!-- Categoria Produto -->
                  <v-col cols="12" sm="6" md="6">
                    <div>Categoria</div>
                    <v-select
                      v-model="editItem.productCtg"
                      :items="filterCategory"
                      item-text="categoryName"
                      return-object
                      label="Selecionar categoria"
                      @change="teste()"
                      :error-messages="productCtgErrors"
                      @input="$v.editItem.productCtg.$touch()"
                      @blur="$v.editItem.productCtg.$touch()"
                      solo
                      required
                    ></v-select>
                    <div v-show="categorylvl2Show">SubCategoria 1</div>
                    <v-select
                      v-model="productCtg2"
                      v-show="categorylvl2Show"
                      :items="category2"
                      item-text="categoryName"
                      item-value="categorySlug"
                      label="Nenhum"
                      clearable
                      solo
                    ></v-select>
                    <div v-show="categorylvl3Show">SubCategoria 2</div>
                    <v-select
                      v-model="productCtg3"
                      v-show="categorylvl3Show"
                      :items="category3"
                      item-text="categoryName"
                      item-value="pk"
                      label="Nenhum"
                      clearable
                      solo
                      required
                    ></v-select>
                    <div v-show="categorylvl4Show">SubCategoria 3</div>
                    <v-select
                      v-model="productCtg4"
                      v-show="categorylvl4Show"
                      :items="category4"
                      item-text="categoryName"
                      item-value="pk"
                      label="Nenhum"
                      clearable
                      solo
                      required
                    ></v-select>
                  </v-col>

                  <!-- Preço Produto -->
                  <v-col cols="12" sm="6" md="3" class="py-0">
                    <div>Preço</div>
                    <v-text-field
                      v-model="editItem.productValue"
                      type="number"
                      @change="applyDiscount"
                      :error-messages="productValueErrors"
                      @input="$v.editItem.productValue.$touch()"
                      @blur="$v.editItem.productValue.$touch()"
                      required
                      solo
                    ></v-text-field>
                  </v-col>

                  <!-- Código Produto -->
                  <v-col cols="12" sm="6" md="3" class="py-0">
                    <div>Código do produto</div>
                    <v-text-field
                      v-model="editItem.productSku"
                      label="SKU"
                      solo
                    ></v-text-field>
                  </v-col>

                  <!-- Tag Produto -->
                  <v-col cols="12" sm="6" md="3" class="py-0">
                    <div>Tag</div>
                    <vue-tags-input
                      v-model="productTag"
                      :tags="editItem.productTag ? editItem.productTag : []"
                      @tags-changed="(newTags) => (productTagList = newTags)"
                    />
                  </v-col>

                  <!-- Quantidade Produto -->
                  <v-col cols="12" sm="6" md="3" class="py-0">
                    <div>Quantidade</div>
                    <v-text-field
                      v-model="editItem.productQtd"
                      label="Quantidade"
                      type="number"
                      solo
                      required
                    ></v-text-field>
                  </v-col>

                  <!-- Desconto Produto -->
                  <v-col cols="12" sm="6" md="3" class="py-0">
                    <v-row no-gutters style="height: 24px">
                      Desconto
                      <v-spacer></v-spacer>
                      %
                      <v-switch
                        v-model="switchDiscount"
                        @change="applyDiscount()"
                        true-value="$"
                        false-value="%"
                        class="pt-0 mt-0 ml-2 mr-n2"
                        inset
                      ></v-switch>
                      $
                    </v-row>
                    <v-text-field
                      v-model="editItem.productDiscount"
                      @change="applyDiscount"
                      label="Desconto promocional"
                      type="number"
                      solo
                      required
                    ></v-text-field>
                  </v-col>

                  <!-- Preço com Desconto produto -->
                  <v-col cols="12" sm="6" md="3" class="py-0">
                    <div>Preço com desconto</div>
                    <v-text-field
                      class="text-red"
                      color="red"
                      v-model="editItem.productValueDiscount"
                      label="Preço promocional"
                      solo
                      readonly
                      required
                    ></v-text-field>
                  </v-col>

                  <v-col cols="12" sm="12" md="12">
                    <!-- Descrição Produto -->
                    <div>Descrição do produto</div>
                    <v-textarea
                      v-model="editItem.productDescription"
                      :error-messages="productDescriptionErrors"
                      @input="$v.editItem.productDescription.$touch()"
                      @blur="$v.editItem.productDescription.$touch()"
                      required
                      solo
                    ></v-textarea>
                  </v-col>
                </v-row>
              </v-card>
            </v-col>
          </v-row>
        </v-stepper-content>

        <!-- Conteudo 2 -->
        <v-stepper-content step="2" class="px-2">
          <div class="imageThumb">
            <v-file-input
              truncate-length="15"
              hide-input
              multiple
              v-model="selectFiles"
              style="flex: 0"
              @change="consoleData"
            ></v-file-input>
            <div
              class="mr-5 pa-5"
              v-for="(item, index) in chosenFilesPreview"
              :key="index"
            >
              <v-img max-width="140px" :src="item.image">
                <v-btn
                  v-if="!item.default"
                  @click="removeImage(index)"
                  icon
                  small
                  color="black"
                  style="position: absolute; right: 0"
                >
                  <v-icon>mdi-close</v-icon>
                </v-btn>

                <v-btn
                  v-if="!item.default"
                  @click="setMainImage(index)"
                  icon
                  small
                  color="black"
                  style="position: absolute; right: 0; bottom: 0"
                >
                  <v-icon>
                    {{ item.mainImage ? "mdi-star" : "mdi-star-outline" }}
                  </v-icon>
                </v-btn>
              </v-img>
            </div>
          </div>

          <v-card class="px-4" tile color="transparent" elevation="0">
            <v-row>
              <v-col cols="12" sm="6" md="3">
                <div>Peso(kg)</div>
                <v-text-field
                  v-model="editItem.productPeso"
                  solo
                  required
                ></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <div>Altura(cm)</div>
                <v-text-field
                  v-model="editItem.productAltura"
                  :error-messages="productAlturaErrors"
                  @input="$v.editItem.productAltura.$touch()"
                  @blur="$v.editItem.productAltura.$touch()"
                  solo
                  required
                ></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <div>Largura(cm)</div>
                <v-text-field
                  v-model="editItem.productLargura"
                  :error-messages="productLarguraErrors"
                  @input="$v.editItem.productLargura.$touch()"
                  @blur="$v.editItem.productLargura.$touch()"
                  solo
                  required
                ></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <div>Comprimento(cm)</div>
                <v-text-field
                  v-model="editItem.productComprimento"
                  :error-messages="productComprimentoErrors"
                  @input="$v.editItem.productComprimento.$touch()"
                  @blur="$v.editItem.productComprimento.$touch()"
                  solo
                  required
                ></v-text-field>
              </v-col>
            </v-row>
          </v-card>

          <v-checkbox
            v-model="showProduct"
            color="#41433e"
            class="ml-5 font-weight-bold"
            :label="`Visível na página`"
          ></v-checkbox>

          <!-- Seção Produtos Relacionados -->
          <div class="text-center my-5" style="font-size: 20px">
            <h3>Produtos Relacionados</h3>
            <v-row>
              <v-col>
                <v-card elevation="0" color="transparent">
                  <v-card-title style="display: block" class="text-center">
                    Selecionar manualmente
                  </v-card-title>
                  <v-card-text>
                    <v-list
                      v-for="(item, i) in productRelacionship"
                      :key="i"
                      class="mb-2"
                    >
                      <v-list-item>
                        <v-list-item-avatar
                          tile
                          height="100%"
                          min-width="60px"
                          width="60px"
                        >
                          <v-img
                            :src="
                              item.productVariations
                                ? item.productVariations[0].productPicture.find(
                                    (main) => main.mainImage === true
                                  ).image
                                : item.productPicture.find(
                                    (main) => main.mainImage === true
                                  ).image
                            "
                          ></v-img>
                        </v-list-item-avatar>
                        <v-list-item-content>
                          <v-list-item-title>
                            {{ item.productName }}
                          </v-list-item-title>
                        </v-list-item-content>
                        <v-list-item-action>
                          <v-btn icon @click="removeRelation(i)">
                            <v-icon color="grey lighten-1"> mdi-close </v-icon>
                          </v-btn>
                        </v-list-item-action>
                      </v-list-item>
                    </v-list>

                    <v-btn
                      text
                      fab
                      x-large
                      :disabled="relationDisable"
                      @click="openModalForRelation()"
                    >
                      <v-icon size="71">mdi-plus-circle-outline</v-icon>
                    </v-btn>
                  </v-card-text>
                </v-card>
              </v-col>

              <v-col>
                <v-card elevation="0" color="transparent">
                  <v-card-title style="display: block" class="text-center">
                    Mesma categoria
                  </v-card-title>
                  <v-card-text>
                    <v-btn
                      text
                      fab
                      x-large
                      @click="productRelacionshipType = 'categoria'"
                    >
                      <v-icon size="71">
                        {{
                          productRelacionshipType === "categoria"
                            ? "mdi-checkbox-blank-circle"
                            : "mdi-checkbox-blank-circle-outline"
                        }}
                      </v-icon>
                    </v-btn>
                  </v-card-text>
                </v-card>
              </v-col>

              <v-col>
                <v-card elevation="0" color="transparent">
                  <v-card-title style="display: block" class="text-center">
                    Aleatório
                  </v-card-title>
                  <v-card-text>
                    <v-btn
                      text
                      fab
                      x-large
                      @click="productRelacionshipType = 'random'"
                    >
                      <v-icon size="71">
                        {{
                          productRelacionshipType === "random"
                            ? "mdi-checkbox-blank-circle"
                            : "mdi-checkbox-blank-circle-outline"
                        }}
                      </v-icon>
                    </v-btn>
                  </v-card-text>
                </v-card>
              </v-col>
            </v-row>
          </div>
        </v-stepper-content>
      </v-stepper-items>

      <v-stepper-header
        style="max-width: 250px; box-shadow: none"
        class="mx-auto"
      >
        <v-icon :disabled="e1 === 1" large @click="prev()" class="arrowButton"
          >mdi-arrow-left</v-icon
        >
        <v-stepper-step :complete="e1 > 1" step="1" blank color="#41433e">
        </v-stepper-step>

        <v-stepper-step :complete="e1 > 2" step="2" color="#41433e">
        </v-stepper-step>

        <v-icon :disabled="e1 === 2" large @click="next()" class="arrowButton"
          >mdi-arrow-right</v-icon
        >
      </v-stepper-header>

      <div class="text-center py-2">
        <v-btn
          color="white"
          width="45%"
          height="40px"
          class="mx-2 red--text"
          :disabled="e1 === 1"
          @click="prev()"
        >
          Cancel
        </v-btn>
        <v-btn
          v-show="nextShow"
          color="#aef82d"
          width="45%"
          height="40px"
          class="mx-2 black--text"
          @click="next()"
        >
          Avançar
        </v-btn>
        <v-btn
          v-show="submitShow"
          color="#aef82d"
          width="45%"
          height="40px"
          class="mx-2 black--text"
          @click="submit()"
        >
          Atualizar Produto
        </v-btn>

        <!-- Modal de Produtos Relacionados -->
        <v-dialog v-model="dialog" max-width="300px">
          <v-card>
            <v-card-text>
              <v-select
                clearable
                color="green"
                :items="ListProducts"
                item-text="productName"
                v-model="itemRelation"
                label="Selecionar um produto"
                class="pt-5"
              ></v-select>
            </v-card-text>
            <v-card-actions>
              <v-btn text color="green" @click="setRelation(itemRelation)">
                Adicionar
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
      </div>
    </v-stepper>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { between, required } from "vuelidate/lib/validators";
import Product from "@/repositories/Product";
export default {
  validations: {
    editItem: {
      productName: { required },
      // productMarca: { required },
      productCtg: { required },
      productValue: { required },
      productDescription: { required },
      productAltura: { between: between(2, 105) },
      productLargura: { between: between(11, 60) },
      productComprimento: { between: between(18, 105) },
    },
  },
  props: {
    editItem: Object,
  },
  computed: {
    ...mapGetters("products", ["allproducts"]),
    ListProducts() {
      return this.allproducts.filter(
        (item) => item.productShow != false && item.pk !== this.$route.params.pk
      );
    },
    ...mapGetters("categories", ["allcategories"]),
    ListCategories() {
      return this.allcategories;
    },
    ...mapGetters("products", ["getSwitch"]),
    SwitchValue() {
      return this.getSwitch;
    },

    // Restriçao a cinco campos para produtos relacionados
    relationDisable() {
      if (this.productRelacionship.length === 5) {
        return true;
      }
    },
    // Filtro de categorias
    filterCategory() {
      const itens = [];
      this.allcategories.find((item) => {
        if (item.categoryType === "categoria") {
          itens.push(item);
        }
      });
      return itens;
    },

    filteredTags() {
      return this.autocompleteTags.filter((i) => {
        return (
          i.text.toLowerCase().indexOf(this.productTag.toLowerCase()) !== -1
        );
      });
    },

    // Verificação de Campos obrigatorios
    productNameErrors() {
      const errors = [];
      if (!this.$v.editItem.productName.$dirty) return errors;
      !this.$v.editItem.productName.required &&
        errors.push("Campo obrigatório");
      return errors;
    },
    // productMarcaErrors() {
    //   const errors = [];
    //   if (!this.$v.editItem.productMarca.$dirty) return errors;
    //   !this.$v.editItem.productMarca.required &&
    //     errors.push("Campo obrigatório");
    //   return errors;
    // },
    productCtgErrors() {
      const errors = [];
      if (!this.$v.editItem.productCtg.$dirty) return errors;
      !this.$v.editItem.productCtg.required && errors.push("Campo obrigatório");
      return errors;
    },
    productValueErrors() {
      const errors = [];
      if (!this.$v.editItem.productValue.$dirty) return errors;
      !this.$v.editItem.productValue.required &&
        errors.push("Campo obrigatório");
      return errors;
    },
    productDescriptionErrors() {
      const errors = [];
      if (!this.$v.editItem.productDescription.$dirty) return errors;
      !this.$v.editItem.productDescription.required &&
        errors.push("Campo obrigatório");
      return errors;
    },
    productAlturaErrors() {
      const errors = [];
      if (!this.$v.editItem.productAltura.$dirty) return errors;
      !this.$v.editItem.productAltura.between &&
        errors.push("Valor deve estar entre 2 e 105");
      // !this.$v.editItem.productAltura.required && errors.push("Campo obrigatório");
      return errors;
    },
    productLarguraErrors() {
      const errors = [];
      if (!this.$v.editItem.productLargura.$dirty) return errors;
      !this.$v.editItem.productLargura.between &&
        errors.push("Valor deve estar entre 11 e 60");
      // !this.$v.editItem.productAltura.required && errors.push("Campo obrigatório");
      return errors;
    },
    productComprimentoErrors() {
      const errors = [];
      if (!this.$v.editItem.productComprimento.$dirty) return errors;
      !this.$v.editItem.productComprimento.between &&
        errors.push("Valor deve estar entre 18 e 105");
      // !this.$v.editItem.productAltura.required && errors.push("Campo obrigatório");
      return errors;
    },
  },
  watch: {
    e1: function () {
      if (this.SwitchAtr === "Sim") {
        if (this.e1 === 3) {
          this.nextShow = false;
          this.submitShow = true;
        } else if (this.e1 < 3) {
          this.nextShow = true;
          this.submitShow = false;
        }
      } else {
        if (this.e1 === 2) {
          this.nextShow = false;
          this.submitShow = true;
        } else if (this.e1 < 2) {
          this.nextShow = true;
          this.submitShow = false;
        }
      }
    },
    "editItem.productCtg": {
      // Watcher Verificando se o elemento escolhido no array possui uma subcategoria
      handler(value) {
        this.category2 = [];
        this.allcategories.find((object) => {
          if (object.categorylvl1 === value.pk) {
            this.category2.push(object);
            this.categorylvl2Show = true;
            this.productCtg3 = "";
            this.categorylvl3Show = false;
            this.categorylvl4Show = false;
          } else {
            if (value.pk) {
              if (!this.category2.some((i) => i.categorylvl1.includes(value.pk))) {
                this.productCtg2 = "";
                this.categorylvl2Show = false;
              }
            }
          }
        });
      },
    },
    productCtg2: {
      handler(value) {
        // Watcher Verificando se o sub elemento escolhido no array possui uma subcategoria
        if (this.category2) {
          this.allcategories.find((object) => {
            if (object.categorylvl2 === value.pk) {
              if (value.pk) {
                this.category3.push(object);
                this.productCtg4 = "";
                this.categorylvl3Show = true;
                this.categorylvl4Show = false;
              }
            } else {
              if (value.pk) {
                if (
                  !this.category3.some((i) => i.categorylvl2.includes(value.pk))
                ) {
                  this.productCtg3 = "";
                  this.categorylvl3Show = false;
                  this.categorylvl4Show = false;
                }
              }
            }
          });
        }
      },
    },
    productCtg3: {
      handler(value) {
        // Watcher Verificando se o sub elemento escolhido no array possui uma subcategoria
        if (this.category3) {
          this.allcategories.find((object) => {
            if (object.categorylvl3 === value.pk) {
              if (value.pk) {
                this.category4.push(object);
                this.categorylvl4Show = true;
              }
            } else {
              if (value.pk) {
                if (
                  !this.category4.some((i) => i.categorylvl3.includes(value.pk))
                ) {
                  this.categorylvl4 = "";
                  this.categorylvl4Show = false;
                }
              }
            }
          });
        }
      },
    },
  },
  data() {
    return {
      selectFiles: null,
      chosenFiles: [],
      chosenFilesPreview: [
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
      ],
      // tagArray: [],
      showProduct: false,
      snackbar: false,
      indexRelation: null,
      dialog: false,
      timeout: 2500,
      e1: 1,
      itemRelation: "",
      step: 1,
      prevShow: false,
      nextShow: true,
      submitShow: false,
      SwitchAtr: "Não",
      switchDiscount: "%",
      switchRelacionship: "Não",
      productRelacionshipType: "",
      productName: "",
      // productMarca: "",
      productValue: "",
      productCtg: "",
      productCtg2: "",
      productCtg3: "",
      productCtg4: "",
      categorylvl2Show: false,
      categorylvl3Show: false,
      categorylvl4Show: false,
      productIMG: [],
      imagesTemp: [],
      productSku: "",
      productQtd: "",
      productDiscount: "",
      productValueDiscount: "",
      productDescription: "",
      productRelacionship: [],
      productRelacionshipCount: ["1", "2", "3", "4", "5"],
      productPeso: "",
      productAltura: "",
      productLargura: "",
      productComprimento: "",
      productTag: "",
      productTagList: [],
      productAtr: [],
      productList: [],
      attribute: [],
      category: [],
      category2: [],
      category3: [],
      category4: [],
      created: false,
      attributeTemp: [],
      ex12: 0,
      files: [],
      ex13: {},
    };
  },
  methods: {
    teste(){
      console.log(this.editItem.productCtg)
    },
    ...mapActions("categories", ["loadCategories"]),
    ...mapActions("products", ["loadProducts"]),
    async consoleData() {
      this.selectFiles.map(async (item) => {
        const toBase64 = (file) =>
          new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = (error) => reject(error);
          });

        const url = {
          image: URL.createObjectURL(item),
          mainImage: false,
        };

        item = {
          image: await toBase64(item),
          mainImage: false,
        };
        if (this.chosenFiles.length >= 4) this.chosenFiles.pop();
        this.chosenFiles.unshift(item);

        if (this.chosenFilesPreview.length >= 4) this.chosenFilesPreview.pop();
        this.chosenFilesPreview.unshift(url);
        console.log(this.chosenFiles);
      });
    },
    removeImage(index) {
      this.chosenFilesPreview.splice(index, 1);
      this.chosenFiles.splice(index, 1);
    },
    setMainImage(index) {
      if (this.chosenFiles[index].image.startsWith("data:image")) {
        this.chosenFilesPreview[index].mainImage = !this.chosenFilesPreview[
          index
        ].mainImage;
        this.chosenFiles[index].mainImage = !this.chosenFiles[index].mainImage;
      } else {
        this.chosenFilesPreview[index].mainImage = !this.chosenFilesPreview[
          index
        ].mainImage;
      }
      console.log(this.chosenFiles);
    },

    applyDiscount() {
      if (this.switchDiscount === "$") {
        this.productValueDiscount = this.productValue - this.productDiscount;
      } else {
        this.productValueDiscount =
          this.productValue - (this.productDiscount / 100) * this.productValue;
      }
    },

    openModalForRelation() {
      this.productRelacionshipType = "manual";
      this.dialog = true;
    },

    // Adiciona um produto a um array de produtos relacionados
    setRelation(item) {
      // Procura o produto selecionado no array productList
      this.ListProducts.find((object) => {
        if (object.productName === item) {
          this.productRelacionship.push(object);
        }
      });
      // Reset do Modal e item selecionado
      this.itemRelation = "";
      this.dialog = false;
    },

    removeRelation(index) {
      this.productRelacionship.splice(index, 1);
    },

    async submit() {
      //Gerando Objeto
      var newProduct = {
        productId: this.$route.params.pk,
        productName: this.editItem.productName,
        // productMarca: this.editItem.productMarca,
        productCtg: this.editItem.productCtg.categoryName,
        productValue: parseFloat(this.editItem.productValue).toFixed(2),
        productSku: this.editItem.productSku,
        productTag: this.productTagList,
        productQtd: this.editItem.productQtd,
        productDiscount: parseFloat(this.editItem.productDiscount).toFixed(2),
        productValueDiscount: parseFloat(
          this.editItem.productValueDiscount
        ).toFixed(2),
        productDescription: this.editItem.productDescription,
        productPeso: this.editItem.productPeso,
        productAltura: this.editItem.productAltura,
        productLargura: this.editItem.productLargura,
        productComprimento: this.editItem.productComprimento,
        productShow: this.showProduct,
        productRelacionshipType: this.productRelacionshipType,
        productPicture: [...this.chosenFiles],
        // productRelacionship: this.productRelacionship,
      };

      console.log(this.editItem.productCtg)

      // Verificando se produtos relacionaods será automatico ou não
      if (this.productRelacionshipType === "categoria") {
        const list = [...this.ListProducts].sort(() => Math.random() - 0.5);
        const categoryList = list.filter(
          (item) => item.productCtg === this.productCtg.categoryName
        );
        const randomCategoryList = categoryList.slice(0, 4);
        newProduct.productRelacionship = randomCategoryList.map(
          (item) => item.pk
        );
      } else if (this.productRelacionshipType === "random") {
        const list = [...this.ListProducts].sort(() => Math.random() - 0.5);
        const randomList = list.slice(0, 4);
        newProduct.productRelacionship = randomList.map((item) => item.pk);
      } else {
        newProduct.productRelacionship = this.productRelacionship.map(
          (item) => item.pk
        );
      }

      if (this.productCtg2) {
        newProduct.productCtg1 = this.defineCategory(this.productCtg2);
      }
      console.log(newProduct);
      Product.updateProduct(newProduct).then((response) => {
        response
          .json()
          .then(() => {
            this.snackbarText = "Produto atualizado";
            this.snackbar = true;
            setTimeout(() => {
              this.$router.push("/produtos/todosProdutos");
            }, 2000);
          })
          .catch((error) => {
            console.log("error", error);
            this.snackbarText = "Erro ao tentar atualizar o produto";
            this.snackbar = true;
          });
      });
    },

    next() {
      // this.$v.$touch();
      // if (this.$v.$invalid) {
      //   console.log("Campos não preenchidos");
      //   console.log(this.$v.$invalid);
      // } else {
      this.e1++;
      // }
    },
    prev() {
      this.e1--;
    },

    defineCategory(value) {
      var name = "";
      this.allcategories.find((object) => {
        if (object.pk === value) {
          console.log(object);
          name = object.categoryName;
        }
      });
      return name;
    },

    setCategory2(value) {
      const ValueObject = this.allcategories.find(
        (item) => item.categoryName === value
      );
      this.category2 = [];
      this.allcategories.find((object) => {
        if (object.categorylvl1 === ValueObject.pk) {
          this.category2.push(object);
          this.categorylvl2Show = true;
          this.productCtg3 = "";
          this.categorylvl3Show = false;
          this.categorylvl4Show = false;
        } else {
          if (value) {
            if (
              !this.category2.some((i) =>
                i.categorylvl1.includes(ValueObject.pk)
              )
            ) {
              this.productCtg2 = "";
              this.categorylvl2Show = false;
            }
          }
        }
      });
    },
  },
  async mounted() {
    this.loadCategories();
    this.loadProducts();
    this.chosenFilesPreview = [...this.editItem.productPicture];
    this.chosenFiles = [...this.editItem.productPicture];
    // this.editItem.productCtg = this.allcategories.find((object) => object.categoryName === this.editItem.productCtg);
    this.productRelacionship = this.editItem.productRelacionship.map((item) => {
      return this.ListProducts.find((object) => object.pk === item);
    });
    this.productRelacionshipType = this.editItem.productRelacionshipType;
    this.showProduct = this.editItem.productShow;
  },
};
</script>


<style scoped>
::v-deep .text-red input {
  color: rgb(219, 44, 44) !important;
}
::v-deep .v-application--is-ltr .v-stepper__step__step {
  width: 30px;
  height: 30px;
  font-size: 25px;
}
::v-deep .show-btns {
  color: rgb(26, 24, 24) !important;
}
::v-deep .v-input--switch--inset .v-input--switch__track {
  width: 42px !important;
  height: 22px !important;
}
::v-deep .v-input--switch--inset .v-input--switch__thumb {
  width: 14px !important;
  height: 14px !important;
}
::v-deep .v-input--selection-controls__ripple {
  height: 27px;
  width: 27px;
}
::v-deep .imageThumb {
  display: flex;
  justify-content: center;
}
</style>