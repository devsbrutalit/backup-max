<template>
  <v-stepper
    v-model="e1"
    class="pb-2"
    style="box-shadow: none; background: transparent"
  >
    <h1 class="text-center">Adicionar Produto</h1>
    <!-- Step 1 -->
    <v-stepper-items>
      <v-stepper-content step="1" class="px-2">
        <v-row class="ma-0">
          <v-col cols="12" sm="6" md="4">
            Escolha as variações do produto
            <!-- Switch com todos os atributos cadastrados -->
            <v-switch
              v-for="(item, i) in ListAttributes"
              :key="i"
              :label="item.attributeName"
              :value="item"
              v-model="attributeTemp"
              color="green"
              multiple
              hide-details
            ></v-switch>
          </v-col>

          <v-col cols="12" sm="6" md="8">
            <v-card class="px-5" tile color="transparent" elevation="0">
              <v-row>
                <!-- Nome Produto -->
                <v-col cols="12" sm="6" md="6">
                  <div>Nome do produto</div>
                  <v-text-field
                    v-model="productName"
                    solo
                    required
                  ></v-text-field>
                </v-col>
                <!-- Marca Produto -->
                <!-- <v-col cols="12" sm="6" md="6">
                  <div>Marca</div>
                  <v-text-field
                    v-model="productMarca"
                    solo
                    required
                  ></v-text-field>
                </v-col> -->
                <!-- Categoria Produto -->
                <v-col cols="12" sm="6" md="6">
                  <div>Categoria</div>
                  <v-select
                    v-model="productCtg"
                    :items="filterCategory"
                    item-text="categoryName"
                    item-value="pk"
                    label="Selecionar categoria"
                    solo
                    required
                  ></v-select>
                  <div v-show="categorylvl2Show">SubCategoria 1</div>
                  <v-select
                    v-model="productCtg2"
                    v-show="categorylvl2Show"
                    :items="category2"
                    item-text="categoryName"
                    item-value="pk"
                    label="Nenhum"
                    clearable
                    solo
                    required
                  ></v-select>
                  <div v-show="categorylvl3Show">SubCategoria 2</div>
                  <v-select
                    v-model="productCtg3"
                    v-show="categorylvl3Show"
                    :items="category3"
                    item-text="categoryName"
                    item-value="pk"
                    label="Nenhum"
                    clearable
                    solo
                    required
                  ></v-select>
                  <div v-show="categorylvl4Show">SubCategoria 3</div>
                  <v-select
                    v-model="productCtg4"
                    v-show="categorylvl4Show"
                    :items="category4"
                    item-text="categoryName"
                    item-value="pk"
                    label="Nenhum"
                    clearable
                    solo
                    required
                  ></v-select>
                </v-col>
                <!-- Código Produto -->
                <v-col cols="12" sm="6" md="3" class="py-0">
                  <div>Código do produto</div>
                  <v-text-field
                    v-model="productSku"
                    label="SKU"
                    solo
                    required
                  ></v-text-field>
                </v-col>
                <!-- Tag Produto -->
                <v-col cols="12" sm="6" md="3" class="py-0">
                  <div>Tag</div>
                  <vue-tags-input
                    v-model="productTag"
                    :tags="productTagList"
                    :autocomplete-items="filteredTags"
                    @tags-changed="(newTags) => (productTagList = newTags)"
                  />
                </v-col>
                <!-- Descrição Produto -->
                <v-col cols="12" sm="12" md="12">
                  <div>Descrição do produto</div>
                  <v-textarea
                    v-model="productDescription"
                    solo
                    required
                  ></v-textarea>
                </v-col>
              </v-row>
            </v-card>

            <v-sheet
              color="ma-auto"
              elevation="1"
              :style="{ width: $vuetify.breakpoint.xs ? '100%' : '70%' }"
              class="text-center my-5"
              style="font-size: 12px"
            >
              <div class="py-2 px-10">
                <v-icon color="black">mdi-information</v-icon>
                <br />
                Os preços e a quantidade dos produtos com variações é definido
                em cada variação adicionada.
              </div>
            </v-sheet>
          </v-col>
        </v-row>
      </v-stepper-content>

      <!-- step 2 -->
      <v-stepper-content step="2" class="px-2">
        <!-- TODO Adicionar Fotos de uma maneira melhor -->
        <div v-if="itemToEditPicture" class="imageThumb">
          <v-file-input
            truncate-length="15"
            hide-input
            multiple
            v-model="selectFiles"
            style="flex: 0"
            @change="setProductPicture"
          ></v-file-input>
          <div
            class="mr-5 pa-5"
            v-for="(item, index) in chosenFilesPreview"
            :key="index"
          >
            <v-img max-width="140px" :src="item.image">
              <v-btn
                v-if="!item.default"
                @click="removeImage(index)"
                icon
                small
                color="black"
                style="position: absolute; right: 0"
              >
                <v-icon>mdi-close</v-icon>
              </v-btn>

              <v-btn
                v-if="!item.default"
                @click="setMainImage(index)"
                icon
                small
                color="black"
                style="position: absolute; right: 0; bottom: 0"
              >
                <v-icon>
                  {{ item.mainImage ? "mdi-star" : "mdi-star-outline" }}
                </v-icon>
              </v-btn>
            </v-img>
          </div>
        </div>
        
        <v-card class="px-4" tile color="transparent" elevation="0">
          <v-row>
            <v-col
              cols="12"
              sm="6"
              md="4"
              v-for="(item, i) in attributeTemp"
              :key="i"
              v-show="!itemToEdit"
            >
              <div>{{ item.attributeName }}</div>
              <!-- Select de cores -->
              <v-select
                v-if="item.attributetype === 'Cor'"
                v-model="productColor[i]"
                :items="item.variations"
                item-text="name"
                :label="item.attributeName"
                return-object
                required
                solo
              >
                <!-- Item Selecionado -->
                <template v-slot:selection="items">
                  <v-avatar
                    size="20"
                    :color="items.item.cor"
                    class="mr-2"
                    style="border: 1px solid black !important"
                  >
                  </v-avatar>
                  - {{ items.item.name }}
                </template>

                <!-- Items para selecionar -->
                <template v-slot:item="items">
                  <div v-if="items.item.cor">
                    <v-avatar
                      size="20"
                      :color="items.item.cor"
                      class="mr-2"
                      style="border: 1px solid black !important"
                    ></v-avatar>
                    - {{ items.item.name }}
                  </div>
                  <div v-if="!items.item.cor">
                    {{ items.item.name }}
                  </div>
                </template>
              </v-select>

              <!-- Select de numeros e textos -->
              <v-select
                v-else
                v-model="productAttributes"
                :items="item.variations"
                item-text="name"
                :label="item.attributeName"
                multiple
                @change="objectAttribute"
                return-object
                required
                solo
              >
              </v-select>
            </v-col>

            <!-- Quantidade Produto -->
            <v-col cols="12" sm="6" md="4">
              <div>Quantidade</div>
              <v-text-field
                v-model="productQtd"
                label="Quantidade"
                type="number"
                solo
                required
              ></v-text-field>
            </v-col>
            <!-- Preço Produto -->
            <v-col cols="12" sm="6" md="4">
              <div>Preço</div>
              <v-text-field
                v-model="productValue"
                @change="applyDiscount"
                label="Preço"
                type="number"
                solo
                required
              ></v-text-field>
            </v-col>
            <!-- Código Produto -->
            <v-col cols="12" sm="6" md="4">
              <div>Código do produto</div>
              <v-text-field
                v-model="productSku"
                label="SKU"
                solo
                required
              ></v-text-field>
            </v-col>
            <!-- Desconto Produto -->
            <v-col cols="12" sm="6" md="4">
              <v-row no-gutters style="height: 24px">
                Desconto
                <v-spacer></v-spacer>
                %
                <v-switch
                  v-model="switchDiscount"
                  @change="applyDiscount()"
                  true-value="$"
                  false-value="%"
                  class="pt-0 mt-0 ml-2 mr-n2"
                  inset
                ></v-switch>
                $
              </v-row>
              <v-text-field
                v-model="productDiscount"
                @change="applyDiscount"
                label="Desconto promocional"
                solo
                required
              ></v-text-field>
            </v-col>
            <!-- Preço com Desconto produto -->
            <v-col cols="12" sm="6" md="4">
              <div>Preço com desconto</div>
              <v-text-field
                class="text-red"
                color="red"
                v-model="productValueDiscount"
                label="Preço com desconto"
                solo
                readonly
                required
              ></v-text-field>
            </v-col>
          </v-row>
          <!-- Dimensões do produto -->
          <v-row>
            <v-col cols="12" sm="6" md="3">
              <div>Peso(kg)</div>
              <v-text-field
                v-model="productPeso"
                label="Acima de 1kg"
                solo
                required
              ></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="3">
              <div>Altura(cm)</div>
              <v-text-field
                v-model="productAltura"
                label="Entre 2cm e 105cm"
                solo
                required
              ></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="3">
              <div>Largura(cm)</div>
              <v-text-field
                v-model="productLargura"
                label="Entre 11cm e 60cm"
                solo
                required
              ></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="3">
              <div>Comprimento(cm)</div>
              <v-text-field
                v-model="productComprimento"
                label="Entre 18cm e 105cm"
                solo
                required
              ></v-text-field>
            </v-col>
          </v-row>
        </v-card>
        <!-- Botão para atualizar uma variação -->
        <div v-if="itemToEdit" class="text-right">
          <v-btn
            color="#aef82d"
            @click="updateAttribute()"
            class="ma-5 text-none rounded-xl"
          >
            Atualizar Variação
          </v-btn>
        </div>
        <!-- Botão para criar uma variação -->
        <div v-else class="text-right">
          <v-btn
            :disabled="variacoes.length === 10"
            color="#aef82d"
            @click="createAttribute()"
            class="ma-5 text-none rounded-xl"
          >
            Criar Variação
          </v-btn>
        </div>
      </v-stepper-content>

      <!-- Conteudo 3 Apenas com Variação -->
      <v-stepper-content step="3" class="px-2">
        <span>Variações do produto</span>
        <v-card style="background: transparent" elevation="0">
          <v-data-table
            :headers="headers"
            :items="variacoes"
            class="elevation-1"
            hide-default-footer
          >
            <!-- Template do valor dos item -->
            <template v-slot:[`item.productValue`]="{ item }">
              <span v-if="item.productValue !== item.productValueDiscount">
                <span class="text-decoration-line-through">
                  de R$ {{ item.productValue }}
                </span>
                por R$ {{ item.productValueDiscount }}
              </span>
              <span v-else> R$ {{ item.productValue }} </span>
            </template>

            <!-- Template items variados -->
            <template v-slot:[`item.productAttributes`]="{ item }">
              <span>
                <v-avatar
                  size="20"
                  :color="item.productColor.cor"
                  class="mr-2"
                  style="border: 1px solid black !important"
                >
                </v-avatar>
                {{ item.productColor.name }} /
              </span>
              <span>{{ item.attName }}: {{ item.name }}</span>
              <span v-if="item.productPicture" class="ml-5">
                <v-icon>mdi-image</v-icon>
              </span>
            </template>

            <template v-slot:[`item.actions`]="{ item }">
              <v-icon @click="editAttribute(item)" color="red">
                mdi-pencil
              </v-icon>

              <v-icon @click="deleteAttribute(item)" color="red">
                mdi-delete
              </v-icon>
            </template></v-data-table
          >

          <div class="text-left">
            <v-btn
              :disabled="variacoes.length === 10"
              class="mt-5 text-none rounded-xl black-text"
              color="#aef82d"
              @click="e1 = 2"
            >
              Adicionar outra variação
            </v-btn>
          </div>

          <v-sheet
            color="light-green lighten-5 ma-auto"
            elevation="1"
            :style="{ width: $vuetify.breakpoint.xs ? '100%' : '70%' }"
            class="text-center my-5"
            style="font-size: 12px"
          >
            <div class="py-2 px-10">
              <v-icon color="green">mdi-information</v-icon>
              <br />
              Você pode adicionar até 10 tipos de variações por produto.
            </div>
          </v-sheet>

          <v-data-table
            :headers="productHeader"
            :items="productDetails()"
            hide-default-footer
          >
          </v-data-table>
          <v-checkbox
            class="ml-5"
            v-model="showProduct"
            :label="`Visível na página`"
          ></v-checkbox>

          <!-- Seção Produtos Relacionados -->
          <div class="text-center my-5" style="font-size: 20px">
            <h3>Produtos Relacionados</h3>
            <v-row>
              <v-col>
                <v-card elevation="0" color="transparent">
                  <v-card-title style="display: block" class="text-center">
                    Selecionar manualmente
                  </v-card-title>
                  <v-card-text>
                    <v-list
                      v-for="(item, i) in productRelacionship"
                      :key="i"
                      class="mb-2"
                    >
                      <v-list-item>
                        <v-list-item-avatar
                          tile
                          height="100%"
                          min-width="60px"
                          width="60px"
                        >
                          <v-img
                            :src="
                              item.productVariations
                                ? item.productVariations[0].productPicture.find(
                                    (main) => main.mainImage === true
                                  ).image
                                : item.productPicture.find(
                                    (main) => main.mainImage === true
                                  ).image
                            "
                          ></v-img>
                        </v-list-item-avatar>
                        <v-list-item-content>
                          <v-list-item-title>
                            {{ item.productName }}
                          </v-list-item-title>
                        </v-list-item-content>
                        <v-list-item-action>
                          <v-btn icon @click="removeRelation(i)">
                            <v-icon color="grey lighten-1"> mdi-close </v-icon>
                          </v-btn>
                        </v-list-item-action>
                      </v-list-item>
                    </v-list>

                    <v-btn
                      text
                      fab
                      x-large
                      :disabled="relationDisable"
                      @click="openModalForRelation()"
                    >
                      <v-icon size="71">mdi-plus-circle-outline</v-icon>
                    </v-btn>
                  </v-card-text>
                </v-card>
              </v-col>

              <v-col>
                <v-card elevation="0" color="transparent">
                  <v-card-title style="display: block" class="text-center">
                    Mesma categoria
                  </v-card-title>
                  <v-card-text>
                    <v-btn
                      text
                      fab
                      x-large
                      @click="productRelacionshipType = 'categoria'"
                    >
                      <v-icon size="71">
                        {{
                          productRelacionshipType === "categoria"
                            ? "mdi-checkbox-blank-circle"
                            : "mdi-checkbox-blank-circle-outline"
                        }}
                      </v-icon>
                    </v-btn>
                  </v-card-text>
                </v-card>
              </v-col>

              <v-col>
                <v-card elevation="0" color="transparent">
                  <v-card-title style="display: block" class="text-center">
                    Aleatório
                  </v-card-title>
                  <v-card-text>
                    <v-btn
                      text
                      fab
                      x-large
                      @click="productRelacionshipType = 'random'"
                    >
                      <v-icon size="71">
                        {{
                          productRelacionshipType === "random"
                            ? "mdi-checkbox-blank-circle"
                            : "mdi-checkbox-blank-circle-outline"
                        }}
                      </v-icon>
                    </v-btn>
                  </v-card-text>
                </v-card>
              </v-col>
            </v-row>
          </div>
        </v-card>
      </v-stepper-content>
    </v-stepper-items>

    <v-stepper-header
      style="max-width: 335px; box-shadow: none"
      class="mx-auto"
    >
      <!-- style="position:absolute;left:31%;bottom:76px"  -->
      <v-icon :disabled="e1 === 1" large @click="prev()" class="arrowButton"
        >mdi-arrow-left</v-icon
      >
      <v-stepper-step :complete="e1 > 1" step="1" blank color="#41433e">
      </v-stepper-step>

      <v-stepper-step :complete="e1 > 2" step="2" color="#41433e">
      </v-stepper-step>

      <v-stepper-step step="3" color="#41433e"> </v-stepper-step>
      <v-icon :disabled="e1 === 3" large @click="next()" class="arrowButton"
        >mdi-arrow-right</v-icon
      >
    </v-stepper-header>
    <div class="text-center py-2">
      <v-btn
        color="white"
        width="45%"
        height="40px"
        class="mx-2 red--text"
        :disabled="e1 === 1"
        @click="prev()"
      >
        Cancel
      </v-btn>
      <v-btn
        v-show="nextShow"
        color="#aef82d"
        width="45%"
        height="40px"
        class="mx-2 black--text"
        @click="next()"
      >
        Avançar
      </v-btn>
      <v-btn
        v-show="submitShow"
        color="#aef82d"
        width="45%"
        height="40px"
        class="mx-2 black--text"
        @click="submit()"
      >
        Criar Produto
      </v-btn>

      <!-- Modal de Produtos Relacionados -->
      <v-dialog v-model="dialog" max-width="300px">
        <v-card>
          <v-card-text>
            <v-select
              clearable
              color="green"
              :items="ListProducts"
              item-text="productName"
              v-model="itemRelation"
              label="Selecionar um produto"
              class="pt-5"
            ></v-select>
          </v-card-text>
          <v-card-actions>
            <v-btn text color="green" @click="setRelation(itemRelation)">
              Adicionar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </div>
    <v-snackbar v-model="snackbar" :timeout="timeout" color="success">
      {{ snackbarText }}
      <template v-slot:action="{ attrs }">
        <v-btn color="" text v-bind="attrs" @click="snackbar = false">
          <v-icon>mdi-close</v-icon>
        </v-btn>
      </template>
    </v-snackbar>
  </v-stepper>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import Product from "@/repositories/Product";
export default {
  props: {
    value: Boolean,
  },
  computed: {
    ...mapGetters("products", ["allproducts"]),
    ListProducts() {
      return this.allproducts.filter(
        (item) => item.productShow != false && item.productName
      );
    },
    ...mapGetters("categories", ["allcategories"]),
    ListCategories() {
      return this.allcategories;
    },
    ...mapGetters("attributes", ["allAttributes"]),
    ListAttributes() {
      return this.allAttributes;
    },

    // Restriçao a cinco campos para produtos relacionados
    relationDisable() {
      if (this.productRelacionship.length === 5) {
        return true;
      }
      if (this.switchRelacionship === "Sim") {
        return true;
      }
    },

    // Filtro de categorias
    filterCategory() {
      const itens = [];
      this.allcategories.find((item) => {
        if (item.categoryType === "categoria") {
          itens.push(item);
        }
      });
      return itens;
    },
    filteredTags() {
      return this.autocompleteTags.filter((i) => {
        return (
          i.text.toLowerCase().indexOf(this.productTag.toLowerCase()) !== -1
        );
      });
    },
  },
  watch: {
    e1: function () {
      if (this.e1 === 3) {
        this.nextShow = false;
        this.submitShow = true;
      } else if (this.e1 < 3) {
        this.nextShow = true;
        this.submitShow = false;
      }
    },
    productCtg: {
      // Watcher Verificando se o elemento escolhido no array possui uma subcategoria
      handler(value) {
        this.category2 = [];
        this.allcategories.find((object) => {
          if (object.categorylvl1 === value) {
            this.category2.push(object);
            this.categorylvl2Show = true;
            this.productCtg3 = "";
            this.categorylvl3Show = false;
            this.categorylvl4Show = false;
          } else {
            if (value) {
              if (!this.category2.some((i) => i.categorylvl1.includes(value))) {
                this.productCtg2 = "";
                this.categorylvl2Show = false;
              }
            }
          }
        });
      },
    },
    productCtg2: {
      handler(value) {
        // Watcher Verificando se o sub elemento escolhido no array possui uma subcategoria
        if (this.category2) {
          this.allcategories.find((object) => {
            if (object.categorylvl2 === value) {
              if (value) {
                this.category3.push(object);
                this.productCtg4 = "";
                this.categorylvl3Show = true;
                this.categorylvl4Show = false;
              }
            } else {
              if (value) {
                if (
                  !this.category3.some((i) => i.categorylvl2.includes(value))
                ) {
                  this.productCtg3 = "";
                  this.categorylvl3Show = false;
                  this.categorylvl4Show = false;
                }
              }
            }
          });
        }
      },
    },
    productCtg3: {
      handler(value) {
        // Watcher Verificando se o sub elemento escolhido no array possui uma subcategoria
        if (this.category3) {
          this.allcategories.find((object) => {
            if (object.categorylvl3 === value) {
              if (value) {
                this.category4.push(object);
                this.categorylvl4Show = true;
              }
            } else {
              if (value) {
                if (
                  !this.category4.some((i) => i.categorylvl3.includes(value))
                ) {
                  this.categorylvl4 = "";
                  this.categorylvl4Show = false;
                }
              }
            }
          });
        }
      },
    },
  },
  data() {
    return {
      selectFiles: null,
      chosenFiles: [],
      chosenFilesPreview: [
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
      ],

      e1: 1,
      showProduct: false,
      snackbar: false,
      snackbarText: "",
      timeout: 2500,
      dialog: false,
      itemRelation: "",
      indexRelation: null,
      step: 1,
      nextShow: true,
      submitShow: false,
      switchDiscount: "%",
      switchRelacionship: "Não",
      productRelacionshipType: "",
      productName: "",
      // productMarca: "",
      productValue: "",
      productCtg: "",
      productCtg2: "",
      productCtg3: "",
      productCtg4: "",
      categorylvl2Show: false,
      categorylvl3Show: false,
      categorylvl4Show: false,
      productIMG: [],
      productSku: "",
      productSkuVariation: "",
      productQtd: 0,
      productDiscount: "",
      productValueDiscount: "",
      productDescription: "",
      productRelacionship: [],
      productRelacionshipCount: ["1", "2", "3", "4", "5"],
      productPeso: 0,
      productAltura: 0,
      productLargura: 0,
      productComprimento: 0,
      productTag: "",
      productTagList: [],
      autocompleteTags: [],
      productColor: [],
      productAttributes: [],
      category2: [],
      category3: [],
      category4: [],
      created: false,
      attributeTemp: [],
      itemToEdit: null,
      itemToEditIndex: null,
      itemToEditPicture: true,
      variacoes: [],
      productHeader: [
        { text: "Nome", value: "productName" },
        // { text: "Marca", value: "productMarca" },
        { text: "Categoria", value: "productCtg" },
        { text: "SubCategoria", value: "productCtg2" },
        { text: "SKU", value: "productSku" },
      ],
      headers: [
        { text: "Variações", value: "productAttributes" },
        { text: "SKU", value: "productSku" },
        { text: "Qtd", value: "productQtd" },
        { text: "Preço", value: "productValue" },
        { text: "Desconto ativo", value: "productDiscount" },
        { text: "Actions", value: "actions", sortable: false },
      ],
    };
  },
  methods: {
    ...mapActions("categories", ["loadCategories"]),
    ...mapActions("products", ["loadProducts"]),
    ...mapActions("attributes", ["loadAttributes"]),
    async setProductPicture() {
      this.selectFiles.map(async (item) => {
        const toBase64 = (file) =>
          new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = (error) => reject(error);
          });

        const url = {
          image: URL.createObjectURL(item),
          mainImage: false,
        };

        item = {
          image: await toBase64(item),
          mainImage: false,
        };
        if (this.chosenFiles.length >= 4) this.chosenFiles.pop();
        this.chosenFiles.unshift(item);

        if (this.chosenFilesPreview.length >= 4) this.chosenFilesPreview.pop();
        this.chosenFilesPreview.unshift(url);
        console.log(this.chosenFiles);
      });
    },
    removeImage(index) {
      this.chosenFilesPreview.splice(index, 1);
      this.chosenFiles.splice(index, 1);
    },
    setMainImage(index) {
      if (this.itemToEdit) {
        this.chosenFiles[index].mainImage = !this.chosenFiles[index].mainImage;
      } else {
        this.chosenFilesPreview[index].mainImage = !this.chosenFilesPreview[
          index
        ].mainImage;
        this.chosenFiles[index].mainImage = !this.chosenFiles[index].mainImage;
      }
    },

    objectAttribute(object) {
      this.allAttributes.map((attribute) => {
        object.map((item) => {
          if (attribute.variations.includes(item)) {
            item.attName = attribute.attributeName;
          } else {
            console.log("não tem");
          }
        });
      });
    },
    setCor(object, item) {
      console.log(object);
      console.log(item);
      const value = object.find((o) => o.name === item);
      return value.cor;
    },
    applyDiscount() {
      if (this.switchDiscount === "$") {
        this.productValueDiscount = this.productValue - this.productDiscount;
      } else {
        this.productValueDiscount =
          this.productValue - (this.productDiscount / 100) * this.productValue;
      }
    },

    openModalForRelation() {
      this.productRelacionshipType = "manual";
      this.dialog = true;
    },

    // Adiciona um produto a um array de produtos relacionados
    setRelation(item) {
      // Procura o produto selecionado no array productList
      this.ListProducts.find((object) => {
        if (object.productName === item) {
          this.productRelacionship.push(object);
        }
      });
      // Reset do Modal e item selecionado
      this.itemRelation = "";
      this.dialog = false;
    },

    removeRelation(index) {
      this.productRelacionship.splice(index, 1);
    },

    productDetails() {
      const Details = [
        {
          productName: this.productName,
          // productMarca: this.productMarca,
          productCtg: this.defineCategory(this.productCtg),
          productCtg2: this.defineCategory(this.productCtg2),
          productSku: this.productSku,
        },
      ];
      return Details;
    },

    createAttribute() {
      var attributes = [...this.productAttributes];
      attributes.map((e, index) => {
        e.attName;
        e.name;
        e.productColor = Object.assign({}, this.productColor[0]);
        e.productQtd = parseInt(this.productQtd);
        e.productValue = parseFloat(this.productValue).toFixed(2);
        e.productSku = this.productSku;
        e.productDiscount = parseFloat(this.productDiscount).toFixed(2);
        e.productValueDiscount = parseFloat(this.productValueDiscount).toFixed(2);
        e.productPeso = this.productPeso;
        e.productAltura = this.productAltura;
        e.productLargura = this.productLargura;
        e.productComprimento = this.productComprimento;
        if (index === 0) e.productPicture = [...this.chosenFiles];

        this.variacoes.push(Object.assign({}, e));
      });

      console.log(attributes);

      this.e1 = 3;
      this.snackbarText = "Variação criada com sucesso";
      this.snackbar = true;

      this.productQtd = "";
      this.productValue = "";
      this.productSkuVariation = "";
      this.productDiscount = "";
      this.productValueDiscount = "";
      this.productPeso = "";
      this.productAltura = "";
      this.productLargura = "";
      this.productComprimento = "";
      this.productAttributes = [];
      this.selectFiles = [];
      this.chosenFiles = [];
      this.chosenFilesPreview = [
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
      ];
    },
    editAttribute(value) {
      if (!value.productPicture) {
        this.itemToEditPicture = false;
      } else {
        this.itemToEditPicture = true;
        this.chosenFilesPreview = [...value.productPicture];
        this.chosenFiles = [...value.productPicture];
      }

      this.itemToEdit = value;
      this.itemToEditIndex = this.variacoes.findIndex((item) => item === value);

      this.productQtd = value.productQtd;
      this.productValue = value.productValue;
      this.productSkuVariation = value.productSkuVariation;
      this.productDiscount = value.productDiscount;
      this.productValueDiscount = value.productValueDiscount;
      this.productPeso = value.productPeso;
      this.productAltura = value.productAltura;
      this.productLargura = value.productLargura;
      this.productComprimento = value.productComprimento;

      this.e1 = 2;
    },

    deleteAttribute(value) {
      const itemRemove = this.variacoes.findIndex((item) => item === value);
      this.variacoes.splice(itemRemove, 1);
    },

    updateAttribute() {
      this.itemToEdit.productQtd = parseInt(this.productQtd);
      this.itemToEdit.productValue = this.productValue;
      this.itemToEdit.productSkuVariation = this.productSkuVariation;
      this.itemToEdit.productDiscount = this.productDiscount;
      this.itemToEdit.productValueDiscount = this.productValueDiscount;
      this.itemToEdit.productPeso = this.productPeso;
      this.itemToEdit.productAltura = this.productAltura;
      this.itemToEdit.productLargura = this.productLargura;
      this.itemToEdit.productComprimento = this.productComprimento;
      this.itemToEdit.productAttributes = this.productAttributes;
      if (this.itemToEditIndex === 0)
        this.itemToEdit.productPicture = [...this.chosenFiles];

      this.variacoes.splice(this.itemToEditIndex, 1, this.itemToEdit);

      this.e1 = 3;
      this.itemToEdit = null;
      this.itemToEditIndex = null;
      this.productQtd = "";
      this.productValue = "";
      this.productSkuVariation = "";
      this.productDiscount = "";
      this.productValueDiscount = "";
      this.productPeso = "";
      this.productAltura = "";
      this.productLargura = "";
      this.productComprimento = "";
      this.productAttributes = [];
      this.selectFiles = [];
      this.chosenFiles = [];
      this.chosenFilesPreview = [
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
      ];
    },

    async submit() {
      // Gerando Objeto
      var newProduct = {
        productName: this.productName,
        // productMarca: this.productMarca,
        productCtg: this.defineCategory(this.productCtg),
        productSku: this.productSku,
        productDescription: this.productDescription,
        productVariations: this.variacoes,
        productShow: this.showProduct,
        productTag: this.productTagList,
        productRelacionshipType: this.productRelacionshipType,
      };

      // Verificando se produtos relacionaods será automatico ou não
      if (this.productRelacionshipType === "categoria") {
        const list = [...this.ListProducts].sort(() => Math.random() - 0.5);
        const categoryList = list.filter(
          (item) => item.productCtg === this.productCtg.categoryName
        );
        const randomCategoryList = categoryList.slice(0, 4);
        newProduct.productRelacionship = randomCategoryList.map(
          (item) => item.pk
        );
      } else if (this.productRelacionshipType === "random") {
        const list = [...this.ListProducts].sort(() => Math.random() - 0.5);
        const randomList = list.slice(0, 4);
        newProduct.productRelacionship = randomList.map((item) => item.pk);
      } else {
        newProduct.productRelacionship = this.productRelacionship.map(
          (item) => item.pk
        );
      }

      if (this.productCtg2) {
        newProduct.productCtg1 = this.defineCategory(this.productCtg2);
      }
      console.log(newProduct);

// Lógica para exibir se foi ou não criado o produto e redirecionar - RESOLVIDO
      Product.createProducts(newProduct).then(()=>{

        this.snackbarText = "Produto criado"
        this.snackbar = true;

        setTimeout(()=> {

          this.$router.push("/produtos/todosProdutos")}, 2000)})

          .catch((error) => {

            console.log("error", error)
            this.snackbarText = "Erro ao tentar criar o produto"
            this.snackbar = true;
      })
// RESOLVIDO
    },
    next() {
      this.e1++;
    },
    prev() {
      this.e1--;
    },

    defineCategory(value) {
      var name = "";
      this.allcategories.find((object) => {
        if (object.pk === value) {
          console.log(object);
          name = object.categoryName;
        }
      });
      return name;
    },
    getTags() {
      var tags = [];
      this.allproducts.find((item) => {
        if (item.productTag) {
          item.productTag.find((text) => {
            tags.push(text);
          });
        }
      });
      this.autocompleteTags = tags;
    },
  },
  mounted() {
    this.loadCategories();
    this.loadProducts();
    this.loadAttributes();
    this.getTags();
    // const instance = this.$refs.Vuedropzone.dropzone;
  },
};
</script>


<style scoped>
::v-deep .v-application--is-ltr .v-stepper__step__step {
  width: 30px;
  height: 30px;
  font-size: 25px;
}
::v-deep .show-btns {
  color: rgb(26, 24, 24) !important;
}
::v-deep .v-input--switch--inset .v-input--switch__track {
  width: 42px !important;
  height: 22px !important;
}
::v-deep .v-input--switch--inset .v-input--switch__thumb {
  width: 14px !important;
  height: 14px !important;
}

::v-deep .imageThumb {
  display: flex;
  justify-content: center;
}
</style>