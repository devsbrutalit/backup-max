<template>
  <v-container>
    <div class="text-center">
      <h1>Cadastrar produto sem variação</h1>
    </div>

    <v-stepper
      v-model="e1"
      class="pb-2"
      style="box-shadow: none; background: transparent"
    >
      <!-- Step 1 -->
      <v-stepper-items>
        <v-stepper-content step="1" class="px-2">
          <v-row class="ma-0">
            <!--
            <v-col cols="12" sm="6" md="4">
              <span class="green--text"
                >Adicione as imagens do seu produto aqui
              </span>
            </v-col> -->

            <!-- <v-col cols="12" sm="6" md="8">
              <handy-uploader
                :documentAttachment.sync="handyAttachments"
                :fileUploaderType="'table'"
                :maxFileSize="10240"
                :imageCompressor="true"
                :imageCompressLevel="0.8"
                :maxFileCount="4"
                :badgeCounter="true"
                :thumb="true"
                :tableHeight="200"
                :btnColor="'green'"
                :tableThumbColumn="true"
                :changeFileName="true"
                :addFileTag="true"
                :tags="['Principal']"
              >
              </handy-uploader>
            </v-col> -->

            <v-col cols="12">
              <v-card class="px-5" tile elevation="0" color="transparent">
                <v-row>
                  <!-- Nome Produto -->
                  <v-col cols="12" sm="6" md="6">
                    <div>Nome do produto</div>
                    <v-text-field
                      v-model="productName"
                      :error-messages="productNameErrors"
                      @input="$v.productName.$touch()"
                      @blur="$v.productName.$touch()"
                      required
                      solo
                    ></v-text-field>
                  </v-col>

                  <!-- Marca Produto -->
                  <!-- <v-col cols="12" sm="6" md="6">
                    <div>Marca</div>
                    <v-text-field
                      v-model="productMarca"
                      :error-messages="productMarcaErrors"
                      @input="$v.productMarca.$touch()"
                      @blur="$v.productMarca.$touch()"
                      required
                      solo
                    ></v-text-field>
                  </v-col> -->

                  <!-- Categoria Produto -->
                  <v-col cols="12" sm="6" md="6">
                    <div>Categoria</div>
                    <v-select
                      v-model="productCtg"
                      :items="filterCategory"
                      item-text="categoryName"
                      item-value="pk"
                      label="Selecionar categoria"
                      :error-messages="productCtgErrors"
                      @input="$v.productCtg.$touch()"
                      @blur="$v.productCtg.$touch()"
                      solo
                      required
                    ></v-select>
                    <div v-show="categorylvl2Show">SubCategoria 1</div>
                    <v-select
                      v-model="productCtg2"
                      v-show="categorylvl2Show"
                      :items="category2"
                      item-text="categoryName"
                      item-value="pk"
                      label="Nenhum"
                      clearable
                      solo
                    ></v-select>
                    <div v-show="categorylvl3Show">SubCategoria 2</div>
                    <v-select
                      v-model="productCtg3"
                      v-show="categorylvl3Show"
                      :items="category3"
                      item-text="categoryName"
                      item-value="pk"
                      label="Nenhum"
                      clearable
                      solo
                      required
                    ></v-select>
                    <div v-show="categorylvl4Show">SubCategoria 3</div>
                    <v-select
                      v-model="productCtg4"
                      v-show="categorylvl4Show"
                      :items="category4"
                      item-text="categoryName"
                      item-value="pk"
                      label="Nenhum"
                      clearable
                      solo
                      required
                    ></v-select>
                  </v-col>

                  <!-- Quantidade Produto -->
                  <v-col cols="12" sm="6" md="3" class="py-0">
                    <div>Quantidade</div>
                    <v-text-field
                      v-model="productQtd"
                      label="Quantidade"
                      type="number"
                      solo
                      required
                    ></v-text-field>
                  </v-col>

                  <!-- Preço Produto -->
                  <v-col cols="12" sm="6" md="3" class="py-0">
                    <div>Preço</div>
                    <v-text-field
                      v-model="productValue"
                      type="number"
                      @change="applyDiscount"
                      :error-messages="productValueErrors"
                      @input="$v.productValue.$touch()"
                      @blur="$v.productValue.$touch()"
                      required
                      solo
                    ></v-text-field>
                  </v-col>

                  <!-- Desconto Produto -->
                  <v-col cols="12" sm="6" md="3" class="py-0">
                    <v-row no-gutters style="height: 24px">
                      Desconto
                      <v-spacer></v-spacer>
                      %
                      <v-switch
                        v-model="switchDiscount"
                        @change="applyDiscount()"
                        true-value="$"
                        false-value="%"
                        class="pt-0 mt-0 ml-2 mr-n2"
                        inset
                      ></v-switch>
                      $
                    </v-row>
                    <v-text-field
                      v-model="productDiscount"
                      @change="applyDiscount"
                      label="Desconto promocional"
                      type="number"
                      solo
                      required
                    ></v-text-field>
                  </v-col>

                  <!-- Preço com Desconto produto -->
                  <v-col cols="12" sm="6" md="3" class="py-0">
                    <div>Preço com desconto</div>
                    <v-text-field
                      class="text-red"
                      color="red"
                      v-model="productValueDiscount"
                      label="Preço promocional"
                      solo
                      readonly
                      required
                    ></v-text-field>
                  </v-col>

                  <!-- Código Produto -->
                  <v-col cols="12" sm="6" md="6" class="py-0">
                    <div>Código do produto</div>
                    <v-text-field
                      v-model="productSku"
                      label="SKU"
                      solo
                    ></v-text-field>
                  </v-col>

                  <!-- Tag Produto -->
                  <v-col cols="12" sm="6" md="6" class="py-0">
                    <div>Tag</div>
                    <vue-tags-input
                      v-model="productTag"
                      :tags="productTagList"
                      :autocomplete-items="filteredTags"
                      @tags-changed="(newTags) => (productTagList = newTags)"
                    />
                  </v-col>

                  <!-- Descrição Produto -->
                  <v-col cols="12" sm="12" md="12">
                    <div>Descrição do produto</div>
                    <v-textarea
                      v-model="productDescription"
                      :error-messages="productDescriptionErrors"
                      @input="$v.productDescription.$touch()"
                      @blur="$v.productDescription.$touch()"
                      required
                      solo
                    ></v-textarea>
                  </v-col>
                </v-row>
              </v-card>
            </v-col>
          </v-row>
        </v-stepper-content>

        <!-- Conteudo 2 -->
        <v-stepper-content step="2" class="px-2">
          <!-- TODO Adicionar Fotos de uma maneira melhor -->
          <div class="imageThumb">
            <v-file-input
              truncate-length="15"
              hide-input
              multiple
              v-model="selectFiles"
              style="flex: 0"
              @change="setProductPicture"
            ></v-file-input>
            <div
              class="mr-5 pa-5"
              v-for="(item, index) in chosenFilesPreview"
              :key="index"
            >
              <v-img max-width="140px" :src="item.image">
                <v-btn
                  v-if="!item.default"
                  @click="removeImage(index)"
                  icon
                  small
                  color="black"
                  style="position: absolute; right: 0"
                >
                  <v-icon>mdi-close</v-icon>
                </v-btn>

                <v-btn
                  v-if="!item.default"
                  @click="setMainImage(index)"
                  icon
                  small
                  color="black"
                  style="position: absolute; right: 0; bottom: 0"
                >
                  <v-icon>
                    {{ item.mainImage ? "mdi-star" : "mdi-star-outline" }}
                  </v-icon>
                </v-btn>
              </v-img>
            </div>
          </div>

          <v-card class="px-4" tile color="transparent" elevation="0">
            <v-row>
              <v-col cols="12" sm="6" md="3">
                <div>Peso(kg)</div>
                <v-text-field
                  v-model="productPeso"
                  label="Acima de 1kg"
                  solo
                  required
                ></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <div>Altura(cm)</div>
                <v-text-field
                  v-model="productAltura"
                  :error-messages="productAlturaErrors"
                  @input="$v.productAltura.$touch()"
                  @blur="$v.productAltura.$touch()"
                  label="Entre 2cm e 105cm"
                  solo
                  required
                ></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <div>Largura(cm)</div>
                <v-text-field
                  v-model="productLargura"
                  :error-messages="productLarguraErrors"
                  @input="$v.productLargura.$touch()"
                  @blur="$v.productLargura.$touch()"
                  label="Entre 11cm e 60cm"
                  solo
                  required
                ></v-text-field>
              </v-col>
              <v-col cols="12" sm="6" md="3">
                <div>Comprimento(cm)</div>
                <v-text-field
                  v-model="productComprimento"
                  :error-messages="productComprimentoErrors"
                  @input="$v.productComprimento.$touch()"
                  @blur="$v.productComprimento.$touch()"
                  label="Entre 18cm e 105cm"
                  solo
                  required
                ></v-text-field>
              </v-col>
            </v-row>
          </v-card>

          <v-checkbox
            class="ml-5"
            v-model="showProduct"
            :label="`Visível na página`"
          ></v-checkbox>

          <!-- Seção Produtos Relacionados -->
          <div class="text-center my-5" style="font-size: 20px">
            <h3>Produtos Relacionados</h3>
            <v-row>
              <v-col>
                <v-card elevation="0" color="transparent">
                  <v-card-title style="display: block" class="text-center">
                    Selecionar manualmente
                  </v-card-title>
                  <v-card-text>
                    <v-list
                      v-for="(item, i) in productRelacionship"
                      :key="i"
                      class="mb-2"
                    >
                      <v-list-item>
                        <v-list-item-avatar
                          tile
                          height="100%"
                          min-width="60px"
                          width="60px"
                        >
                          <v-img
                            :src="
                              item.productVariations
                                ? item.productVariations[0].productPicture.find(
                                    (main) => main.mainImage === true
                                  ).image
                                : item.productPicture.find(
                                    (main) => main.mainImage === true
                                  ).image
                            "
                          ></v-img>
                        </v-list-item-avatar>
                        <v-list-item-content>
                          <v-list-item-title>
                            {{ item.productName }}
                          </v-list-item-title>
                        </v-list-item-content>
                        <v-list-item-action>
                          <v-btn icon @click="removeRelation(i)">
                            <v-icon color="grey lighten-1"> mdi-close </v-icon>
                          </v-btn>
                        </v-list-item-action>
                      </v-list-item>
                    </v-list>

                    <v-btn
                      text
                      fab
                      x-large
                      :disabled="relationDisable"
                      @click="openModalForRelation()"
                    >
                      <v-icon size="71">mdi-plus-circle-outline</v-icon>
                    </v-btn>
                  </v-card-text>
                </v-card>
              </v-col>

              <v-col>
                <v-card elevation="0" color="transparent">
                  <v-card-title style="display: block" class="text-center">
                    Mesma categoria
                  </v-card-title>
                  <v-card-text>
                    <v-btn
                      text
                      fab
                      x-large
                      @click="productRelacionshipType = 'categoria'"
                    >
                      <v-icon size="71">
                        {{
                          productRelacionshipType === "categoria"
                            ? "mdi-checkbox-blank-circle"
                            : "mdi-checkbox-blank-circle-outline"
                        }}
                      </v-icon>
                    </v-btn>
                  </v-card-text>
                </v-card>
              </v-col>

              <v-col>
                <v-card elevation="0" color="transparent">
                  <v-card-title style="display: block" class="text-center">
                    Aleatório
                  </v-card-title>
                  <v-card-text>
                    <v-btn
                      text
                      fab
                      x-large
                      @click="productRelacionshipType = 'random'"
                    >
                      <v-icon size="71">
                        {{
                          productRelacionshipType === "random"
                            ? "mdi-checkbox-blank-circle"
                            : "mdi-checkbox-blank-circle-outline"
                        }}
                      </v-icon>
                    </v-btn>
                  </v-card-text>
                </v-card>
              </v-col>
            </v-row>
          </div>
        </v-stepper-content>
      </v-stepper-items>

      <v-stepper-header
        style="max-width: 250px; box-shadow: none"
        class="mx-auto"
      >
        <v-icon :disabled="e1 === 1" large @click="prev()" class="arrowButton"
          >mdi-arrow-left</v-icon
        >
        <v-stepper-step :complete="e1 > 1" step="1" blank color="#41433e">
        </v-stepper-step>

        <v-stepper-step :complete="e1 > 2" step="2" color="#41433e">
        </v-stepper-step>

        <v-icon :disabled="e1 === 2" large @click="next()" class="arrowButton"
          >mdi-arrow-right</v-icon
        >
      </v-stepper-header>

      <div class="text-center py-2">
        <v-btn
          color="white"
          width="45%"
          height="40px"
          class="mx-2 red--text"
          :disabled="e1 === 1"
          @click="prev()"
        >
          Cancel
        </v-btn>
        <v-btn
          v-show="nextShow"
          color="#aef82d"
          width="45%"
          height="40px"
          class="mx-2 black--text"
          @click="next()"
        >
          Avançar
        </v-btn>
        <v-btn
          v-show="submitShow"
          color="#aef82d"
          width="45%"
          height="40px"
          class="mx-2 black--text"
          @click="submit()"
        >
          Criar Produto
        </v-btn>

        <!-- Modal de Produtos Relacionados -->
        <v-dialog v-model="dialog" max-width="300px">
          <v-card>
            <v-card-text>
              <v-select
                clearable
                color="green"
                :items="ListProducts"
                item-text="productName"
                v-model="itemRelation"
                label="Selecionar um produto"
                class="pt-5"
              ></v-select>
            </v-card-text>
            <v-card-actions>
              <v-btn
                v-if="indexRelation != null"
                text
                color="error"
                @click="removeRelation()"
              >
                Remover
              </v-btn>
              <v-btn text color="#aef82d" @click="setRelation(itemRelation)">
                Adicionar
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
      </div>
      
      <v-snackbar v-model="snackbar" :timeout="timeout" color="success">
          {{ snackbarText }}
        <template v-slot:action="{ attrs }">
          <v-btn color="" text v-bind="attrs" @click="snackbar = false">
            <v-icon>mdi-close</v-icon>
          </v-btn>
        </template>
      </v-snackbar>
    </v-stepper>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { between, required } from "vuelidate/lib/validators";
import Product from "@/repositories/Product";
import handyUploader from "@/node_modules/handy-uploader/src/components/handyUploader";
export default {
  components: {
    handyUploader,
  },
  validations: {
    productName: { required },
    // productMarca: { required },
    productCtg: { required },
    productValue: { required },
    productDescription: { required },
    productAltura: { between: between(2, 105) },
    productLargura: { between: between(11, 60) },
    productComprimento: { between: between(18, 105) },
  },
  props: {
    value: Boolean,
  },
  computed: {
    ...mapGetters("products", ["allproducts"]),
    ListProducts() {
      return this.allproducts.filter(
        (item) => item.productShow != false && item.productName
      );
    },
    ...mapGetters("categories", ["allcategories"]),
    ListCategories() {
      return this.allcategories;
    },

    // Restriçao a cinco campos para produtos relacionados
    relationDisable() {
      if (this.productRelacionship.length === 5) {
        return true;
      }
      if (this.switchRelacionship === "Sim") {
        return true;
      }
    },

    // Filtro de categorias
    filterCategory() {
      const itens = [];
      this.allcategories.find((item) => {
        if (item.categoryType === "categoria") {
          itens.push(item);
        }
      });
      return itens;
    },

    // Verificação de Campos obrigatorios
    productNameErrors() {
      const errors = [];
      if (!this.$v.productName.$dirty) return errors;
      !this.$v.productName.required && errors.push("Campo obrigatório");
      return errors;
    },
    // productMarcaErrors() {
    //   const errors = [];
    //   if (!this.$v.productMarca.$dirty) return errors;
    //   !this.$v.productMarca.required && errors.push("Campo obrigatório");
    //   return errors;
    // },
    productCtgErrors() {
      const errors = [];
      if (!this.$v.productCtg.$dirty) return errors;
      !this.$v.productCtg.required && errors.push("Campo obrigatório");
      return errors;
    },
    productValueErrors() {
      const errors = [];
      if (!this.$v.productValue.$dirty) return errors;
      !this.$v.productValue.required && errors.push("Campo obrigatório");
      return errors;
    },
    productDescriptionErrors() {
      const errors = [];
      if (!this.$v.productDescription.$dirty) return errors;
      !this.$v.productDescription.required && errors.push("Campo obrigatório");
      return errors;
    },
    productAlturaErrors() {
      const errors = [];
      if (!this.$v.productAltura.$dirty) return errors;
      !this.$v.productAltura.between &&
        errors.push("Valor deve estar entre 2 e 105");
      // !this.$v.editItem.productAltura.required && errors.push("Campo obrigatório");
      return errors;
    },
    productLarguraErrors() {
      const errors = [];
      if (!this.$v.productLargura.$dirty) return errors;
      !this.$v.productLargura.between &&
        errors.push("Valor deve estar entre 11 e 60");
      // !this.$v.editItem.productAltura.required && errors.push("Campo obrigatório");
      return errors;
    },
    productComprimentoErrors() {
      const errors = [];
      if (!this.$v.productComprimento.$dirty) return errors;
      !this.$v.productComprimento.between &&
        errors.push("Valor deve estar entre 18 e 105");
      // !this.$v.editItem.productAltura.required && errors.push("Campo obrigatório");
      return errors;
    },
    filteredTags() {
      return this.autocompleteTags.filter((i) => {
        return (
          i.text.toLowerCase().indexOf(this.productTag.toLowerCase()) !== -1
        );
      });
    },
  },
  watch: {
    e1: function () {
      if (this.SwitchAtr === "Sim") {
        if (this.e1 === 3) {
          this.nextShow = false;
          this.submitShow = true;
        } else if (this.e1 < 3) {
          this.nextShow = true;
          this.submitShow = false;
        }
      } else {
        if (this.e1 === 2) {
          this.nextShow = false;
          this.submitShow = true;
        } else if (this.e1 < 2) {
          this.nextShow = true;
          this.submitShow = false;
        }
      }
    },
    productCtg: {
      // Watcher Verificando se o elemento escolhido no array possui uma subcategoria
      handler(value) {
        this.category2 = [];
        this.allcategories.find((object) => {
          if (object.categorylvl1 === value) {
            this.category2.push(object);
            this.categorylvl2Show = true;
            this.productCtg3 = "";
            this.categorylvl3Show = false;
            this.categorylvl4Show = false;
          } else {
            if (value) {
              if (!this.category2.some((i) => i.categorylvl1.includes(value))) {
                this.productCtg2 = "";
                this.categorylvl2Show = false;
              }
            }
          }
        });
      },
    },
    productCtg2: {
      handler(value) {
        // Watcher Verificando se o sub elemento escolhido no array possui uma subcategoria
        if (this.category2) {
          this.allcategories.find((object) => {
            if (object.categorylvl2 === value) {
              if (value) {
                this.category3.push(object);
                this.productCtg4 = "";
                this.categorylvl3Show = true;
                this.categorylvl4Show = false;
              }
            } else {
              if (value) {
                if (
                  !this.category3.some((i) => i.categorylvl2.includes(value))
                ) {
                  this.productCtg3 = "";
                  this.categorylvl3Show = false;
                  this.categorylvl4Show = false;
                }
              }
            }
          });
        }
      },
    },
    productCtg3: {
      handler(value) {
        // Watcher Verificando se o sub elemento escolhido no array possui uma subcategoria
        if (this.category3) {
          this.allcategories.find((object) => {
            if (object.categorylvl3 === value) {
              if (value) {
                this.category4.push(object);
                this.categorylvl4Show = true;
              }
            } else {
              if (value) {
                if (
                  !this.category4.some((i) => i.categorylvl3.includes(value))
                ) {
                  this.categorylvl4 = "";
                  this.categorylvl4Show = false;
                }
              }
            }
          });
        }
      },
    },
  },
  data() {
    return {
      selectFiles: null,
      chosenFiles: [],
      chosenFilesPreview: [
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
        { image: require("@/assets/img/defaultImage.jpg"), default: true },
      ],
      // tagArray: [],
      showProduct: false,
      snackbar: false,
      snackbarText: "",
      indexRelation: null,
      dialog: false,
      timeout: 2500,
      e1: 1,
      itemRelation: "",
      step: 1,
      prevShow: false,
      nextShow: true,
      submitShow: false,
      SwitchAtr: "Não",
      switchDiscount: "%",
      switchRelacionship: "Não",
      productRelacionshipType: "",
      productName: "",
      // productMarca: "",
      productValue: "",
      productCtg: "",
      productCtg2: "",
      productCtg3: "",
      productCtg4: "",
      categorylvl2Show: false,
      categorylvl3Show: false,
      categorylvl4Show: false,
      productIMG: [],
      imagesTemp: [],
      productSku: "",
      productQtd: 0,
      productDiscount: "",
      productValueDiscount: "",
      productDescription: "",
      productRelacionship: [],
      productRelacionshipCount: ["1", "2", "3", "4", "5"],
      productPeso: "",
      productAltura: "",
      productLargura: "",
      productComprimento: "",
      productTag: "",
      productTagList: [],
      autocompleteTags: [],
      productAtr: [],
      productList: [],
      attribute: [],
      category: [],
      category2: [],
      category3: [],
      category4: [],
      created: false,
      attributeTemp: [],
      ex12: 0,
      files: [],
      ex13: {},
    };
  },
  methods: {
    ...mapActions("products", ["ChangeSwitch"]),
    ...mapActions("categories", ["loadCategories"]),
    ...mapActions("products", ["loadProducts"]),
    async setProductPicture() {

      this.selectFiles.map(async (item) => {
        const toBase64 = (file) =>
          new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = (error) => reject(error);
          });

        const url = {
          image: URL.createObjectURL(item),
          mainImage: false,
        };

        item = {
          image: await toBase64(item),
          mainImage: false,
        };

        if (this.chosenFiles.length >= 4) {this.chosenFiles.pop()};
        this.chosenFiles.unshift(item);

        if (this.chosenFilesPreview.length >= 4) { this.chosenFilesPreview.pop()};
        this.chosenFilesPreview.unshift(url);
        console.log(this.chosenFiles);
      });
    },
    removeImage(index) {
      this.chosenFilesPreview.splice(index, 1);
      this.chosenFiles.splice(index, 1);
    },
    setMainImage(index) {
      this.chosenFilesPreview[index].mainImage = !this.chosenFilesPreview[index]
        .mainImage;
      this.chosenFiles[index].mainImage = !this.chosenFiles[index].mainImage;
    },
    applyDiscount() {
      if (this.switchDiscount === "$") {
        this.productValueDiscount = this.productValue - this.productDiscount;
      } else {
        this.productValueDiscount =
          this.productValue - (this.productDiscount / 100) * this.productValue;
      }
    },

    openModalForRelation() {
      this.productRelacionshipType = "manual";
      this.dialog = true;
    },

    // Adiciona um produto a um array de produtos relacionados
    setRelation(item) {
      // Procura o produto selecionado no array productList
      this.ListProducts.find((object) => {
        if (object.productName === item) {
          this.productRelacionship.push(object);
        }
      });
      // Reset do Modal e item selecionado
      this.itemRelation = "";
      this.dialog = false;
    },

    removeRelation(index) {
      this.productRelacionship.splice(index, 1);
    },

    async submit() {
      //Gerando Objeto
      var newProduct = {
        productName: this.productName,
        // productMarca: this.productMarca,
        productCtg: this.defineCategory(this.productCtg),
        productValue: parseFloat(this.productValue).toFixed(2),
        productSku: this.productSku,
        productTag: this.productTagList,
        productQtd: parseInt(this.productQtd),
        productDiscount: parseFloat(this.productDiscount).toFixed(2),
        productValueDiscount: parseFloat(this.productValueDiscount).toFixed(2),
        productDescription: this.productDescription,
        productPeso: this.productPeso,
        productAltura: this.productAltura,
        productLargura: this.productLargura,
        productComprimento: this.productComprimento,
        productShow: this.showProduct,
        productPicture: [...this.chosenFiles],
        productRelacionshipType: this.productRelacionshipType,
      };

      // Verificando se produtos relacionaods será automatico ou não
      if (this.productRelacionshipType === "categoria") {
        const list = [...this.ListProducts].sort(() => Math.random() - 0.5);
        const categoryList = list.filter(
          (item) => item.productCtg === this.defineCategory(this.productCtg)
        );
        const randomCategoryList = categoryList.slice(0, 4);
        newProduct.productRelacionship = randomCategoryList.map(
          (item) => item.pk
        );
      } else if (this.productRelacionshipType === "random") {
        const list = [...this.ListProducts].sort(() => Math.random() - 0.5);
        const randomList = list.slice(0, 4);
        newProduct.productRelacionship = randomList.map((item) => item.pk);
      } else {
        newProduct.productRelacionship = this.productRelacionship.map(
          (item) => item.pk
        );
      }

      if (this.productCtg2) {
        newProduct.productCtg1 = this.defineCategory(this.productCtg2);
      }
      console.log(newProduct);
      // Product.createProducts(newProduct).then((response) => {
      //   response
      //     .json()
      //     .then(() => {
      //       this.
      
      
      Text = "Produto criado";
      //       this.snackbar = true;
      //       setTimeout(() => {
      //         this.$router.push("/produtos/todosProdutos");
      //       }, 2000);
      //     })
      //     .catch((error) => {
      //       console.log("error", error);
      //       this.snackbarText = "Erro ao tentar criar o produto";
      //       this.snackbar = true;
      //     });
      // });


      Product.createProducts(newProduct).then(() => {

          this.snackbarText = "Produto criado";
          this.snackbar = true;

          setTimeout(() => {
              this.$router.push("/produtos/todosProdutos");
            }, 2000);
      }).catch((error) => {
          console.log("error", error);
          this.snackbarText = "Erro ao tentar criar o produto";
          this.snackbar = true;
      })
    },
    next() {
      this.$v.$touch();
      if (this.$v.$invalid) {
        console.log("Campos não preenchidos");
        console.log(this.$v.$invalid);
      } else {
        this.e1++;
      }
    },
    prev() {
      this.e1--;
    },

    defineCategory(value) {
      var name = "";
      this.allcategories.find((object) => {
        if (object.pk === value) {
          console.log(object);
          name = object.categoryName;
        }
      });
      return name;
    },

    getTags() {
      var tags = [];
      this.allproducts.find((item) => {
        if (item.productTag) {
          item.productTag.find((text) => {
            tags.push(text);
          });
        }
      });
      this.autocompleteTags = tags;
    },
  },
  mounted() {
    this.loadCategories();
    this.loadProducts();
    this.getTags();
  },
};
</script>


<style scoped>
::v-deep .imageThumb {
  display: flex;
  justify-content: center;
}
::v-deep .text-red input {
  color: rgb(219, 44, 44) !important;
}
::v-deep .v-application--is-ltr .v-stepper__step__step {
  width: 30px;
  height: 30px;
  font-size: 25px;
}
::v-deep .show-btns {
  color: rgb(26, 24, 24) !important;
}
::v-deep .v-input--switch--inset .v-input--switch__track {
  width: 42px !important;
  height: 22px !important;
}
::v-deep .v-input--switch--inset .v-input--switch__thumb {
  width: 14px !important;
  height: 14px !important;
}
::v-deep .v-input--selection-controls__ripple {
  height: 27px;
  width: 27px;
}
</style>