<template>
  <v-stepper v-model="e1" class="pb-2" style="box-shadow: none">
    <h1 class="green--text ml-10">Adicionar Produto</h1>
    <!-- Step 1 -->
    <v-stepper-items>
      <v-stepper-content step="1" class="px-2">
        <v-row class="ma-0">
          <v-col cols="12" sm="6" md="4">
            <span class="green--text"
              >Adicione as imagens do seu produto aqui
            </span>
          </v-col>

          <v-col cols="12" sm="6" md="8">
            <handy-uploader
              :documentAttachment.sync="handyAttachments"
              :fileUploaderType="'table'"
              :maxFileSize="10240"
              :imageCompressor="true"
              :imageCompressLevel="0.8"
              :maxFileCount="4"
              :badgeCounter="true"
              :thumb="true"
              :tableHeight="200"
              :btnColor="'green'"
              :tableThumbColumn="true"
              :changeFileName="true"
              :addFileTag="true"
              :tags="['Principal']"
            >
            </handy-uploader>
          </v-col>

          <v-col cols="12">
            <v-card class="px-5" tile color="blue lighten-5">
              <v-btn
                class="text-none my-5"
                @click="produtosModal = !produtosModal"
                >Incluir Produto</v-btn
              >
              {{productCombo}}
              <v-row>
                <!-- Nome Produto -->
                <v-col cols="12" sm="6" md="6">
                  <div>Nome do Combo</div>
                  <v-text-field
                    v-model="productName"
                    :error-messages="productNameErrors"
                    @input="$v.productName.$touch()"
                    @blur="$v.productName.$touch()"
                    required
                    solo
                  ></v-text-field>
                </v-col>
                <!-- Categoria Produto -->
                <v-col cols="12" sm="6" md="6">
                  <div>Categoria</div>
                  <v-select
                    v-model="productCtg"
                    :items="filterCategory"
                    item-text="categoryName"
                    item-value="pk"
                    label="Selecionar categoria"
                    :error-messages="productCtgErrors"
                    @input="$v.productCtg.$touch()"
                    @blur="$v.productCtg.$touch()"
                    solo
                    required
                  ></v-select>
                  <div v-show="categorylvl2Show">SubCategoria 1</div>
                  <v-select
                    v-model="productCtg2"
                    v-show="categorylvl2Show"
                    :items="category2"
                    item-text="categoryName"
                    item-value="pk"
                    label="Nenhum"
                    clearable
                    solo
                  ></v-select>
                  <div v-show="categorylvl3Show">SubCategoria 2</div>
                  <v-select
                    v-model="productCtg3"
                    v-show="categorylvl3Show"
                    :items="category3"
                    item-text="categoryName"
                    item-value="pk"
                    label="Nenhum"
                    clearable
                    solo
                    required
                  ></v-select>
                  <div v-show="categorylvl4Show">SubCategoria 3</div>
                  <v-select
                    v-model="productCtg4"
                    v-show="categorylvl4Show"
                    :items="category4"
                    item-text="categoryName"
                    item-value="pk"
                    label="Nenhum"
                    clearable
                    solo
                    required
                  ></v-select>
                </v-col>
                <!-- Preço Produto -->
                <v-col cols="12" sm="6" md="3" class="py-0">
                  <div>Preço</div>
                  <v-text-field
                    v-model="productValue"
                    type="number"
                    @change="applyDiscount"
                    :error-messages="productValueErrors"
                    @input="$v.productValue.$touch()"
                    @blur="$v.productValue.$touch()"
                    required
                    solo
                  ></v-text-field>
                </v-col>
                <!-- Código Produto -->
                <v-col cols="12" sm="6" md="3" class="py-0">
                  <div>Código do produto</div>
                  <v-text-field
                    v-model="productSku"
                    label="SKU"
                    solo
                  ></v-text-field>
                </v-col>
                <!-- Tag Produto -->
                <v-col cols="12" sm="6" md="3" class="py-0">
                  <div>Tag</div>
                  <vue-tags-input
                    v-model="productTag"
                    :tags="productTagList"
                    :autocomplete-items="filteredTags"
                    @tags-changed="(newTags) => (productTagList = newTags)"
                  />
                </v-col>
                <!-- Quantidade Produto -->
                <v-col cols="12" sm="6" md="3" class="py-0">
                  <div>Quantidade</div>
                  <v-text-field
                    v-model="productQtd"
                    label="Quantidade"
                    type="number"
                    solo
                    required
                  ></v-text-field>
                </v-col>
                <!-- Desconto Produto -->
                <v-col cols="12" sm="6" md="3" class="py-0">
                  <v-row no-gutters style="height: 24px">
                    Desconto
                    <v-spacer></v-spacer>
                    %
                    <v-switch
                      v-model="switchDiscount"
                      @change="applyDiscount()"
                      true-value="$"
                      false-value="%"
                      class="pt-0 mt-0 ml-2 mr-n2"
                      inset
                    ></v-switch>
                    $
                  </v-row>
                  <v-text-field
                    v-model="productDiscount"
                    @change="applyDiscount"
                    label="Desconto promocional"
                    type="number"
                    solo
                    required
                  ></v-text-field>
                </v-col>
                <!-- Preço com Desconto produto -->
                <v-col cols="12" sm="6" md="3" class="py-0">
                  <div>Preço com desconto</div>
                  <v-text-field
                    class="text-red"
                    color="red"
                    v-model="productValueDiscount"
                    label="Preço promocional"
                    solo
                    readonly
                    required
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="12" md="12">
                  <!-- Descrição Produto -->
                  <div>Descrição do produto</div>
                  <v-textarea
                    v-model="productDescription"
                    :error-messages="productDescriptionErrors"
                    @input="$v.productDescription.$touch()"
                    @blur="$v.productDescription.$touch()"
                    required
                    solo
                  ></v-textarea>
                </v-col>
              </v-row>
            </v-card>
          </v-col>
        </v-row>
      </v-stepper-content>

      <!-- Conteudo 2 -->
      <v-stepper-content step="2" class="px-2">
        <!-- Quadro Informativo -->
        <v-sheet
          color="light-green lighten-5 ma-auto"
          elevation="1"
          height="80"
          :style="{ width: $vuetify.breakpoint.xs ? '100%' : '50%' }"
          class="text-center my-5"
          style="font-size: 12px"
        >
          <div class="py-2 px-10">
            <v-icon color="green">mdi-information</v-icon>
            <br />
            Para ajudar você no cálculo do frete todos os valores abaixo devem
            ser preenchidos.
          </div>
        </v-sheet>

        <!-- Quadro Informativo a respeito dos tamanhos limite dos correios-->
        <v-sheet
          color="light-green lighten-5 ma-auto"
          elevation="1"
          :style="{ width: $vuetify.breakpoint.xs ? '100%' : '90%' }"
          class="text-left my-5"
          style="font-size: 12px"
        >
          <div class="py-2 px-10 text-center">
            <span
              >A altura deve estar entre 2cm e 105cm; A largura deve estar entre
              11cm e 60cm; O Comprimento deve estar entre 18cm e 105cm</span
            >
            <p>
              A soma resultante do comprimento + largura + altura não deve
              superar a 200 cm
            </p>
          </div>
        </v-sheet>

        <v-card class="px-4" tile color="blue lighten-5">
          <v-row>
            <v-col cols="12" sm="6" md="3">
              <div>Peso(kg)</div>
              <v-text-field v-model="productPeso" solo required></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="3">
              <div>Altura(cm)</div>
              <v-text-field
                v-model="productAltura"
                :error-messages="productAlturaErrors"
                @input="$v.productAltura.$touch()"
                @blur="$v.productAltura.$touch()"
                solo
                required
              ></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="3">
              <div>Largura(cm)</div>
              <v-text-field
                v-model="productLargura"
                :error-messages="productLarguraErrors"
                @input="$v.productLargura.$touch()"
                @blur="$v.productLargura.$touch()"
                solo
                required
              ></v-text-field>
            </v-col>
            <v-col cols="12" sm="6" md="3">
              <div>Comprimento(cm)</div>
              <v-text-field
                v-model="productComprimento"
                :error-messages="productComprimentoErrors"
                @input="$v.productComprimento.$touch()"
                @blur="$v.productComprimento.$touch()"
                solo
                required
              ></v-text-field>
            </v-col>
          </v-row>
        </v-card>

        <v-checkbox
          class="ml-5"
          v-model="showProduct"
          :label="`Visível na página`"
        ></v-checkbox>

        <!-- Seção Produtos Relacionados -->
        <div class="text-center my-5" style="font-size: 20px">
          Adicionar Produtos Relacionados
          <div class="mx-10">
            <v-switch
              v-model="switchRelacionship"
              true-value="Sim"
              false-value="Não"
              :label="`Relacionar aleatoriamente? : ${switchRelacionship.toString()}`"
            ></v-switch>
          </div>
        </div>

        <!-- Lista de Items Relacionados -->
        <v-row>
          <v-col
            cols="6"
            sm="6"
            md="2"
            class="text-center"
            v-for="(item, i) in productRelacionship"
            :key="i"
          >
            <v-hover v-slot="{ hover }">
              <!-- Card Desktop -->
              <v-card class="hidden-xs-only" :disabled="relationDisable">
                <v-img height="100%" :src="item.productPicture[0]">
                  <v-btn
                    fab
                    elevation="0"
                    @click="
                      dialog = !dialog;
                      indexRelation = i;
                    "
                    style="margin-top: 50%"
                    :class="{ 'show-btns': hover }"
                    color="transparent"
                  >
                    <v-icon
                      large
                      :class="{ 'show-btns': hover }"
                      color="transparent"
                      >mdi-plus-circle-outline</v-icon
                    >
                  </v-btn>
                </v-img>
                {{ item.productName }}
              </v-card>
            </v-hover>

            <!-- Card Mobile -->
            <v-card class="hidden-sm-and-up" :disabled="relationDisable">
              <v-img
                height="100%"
                :src="item.productPicture[0]"
                @click="
                  dialog = !dialog;
                  indexRelation = i;
                "
              ></v-img>
              {{ item.productName }}
            </v-card>
          </v-col>

          <!-- Botão para adicionar mais produtos, limitado ao um total de 5 -->
          <v-col cols="6" sm="6" md="2" class="text-center">
            <v-btn
              :disabled="relationDisable"
              icon
              elevation="0"
              @click="
                dialog = !dialog;
                indexRelation = null;
              "
              style="margin-top: 50%"
            >
              <v-icon large>mdi-plus-circle-outline</v-icon>
            </v-btn>
          </v-col>
        </v-row>
      </v-stepper-content>
    </v-stepper-items>

    <v-stepper-header
      style="max-width: 250px; box-shadow: none"
      class="mx-auto"
    >
      <v-icon :disabled="e1 === 1" large @click="prev()" class="arrowButton"
        >mdi-arrow-left</v-icon
      >
      <v-stepper-step :complete="e1 > 1" step="1" blank color="green">
      </v-stepper-step>

      <v-stepper-step :complete="e1 > 2" step="2" color="green">
      </v-stepper-step>

      <v-icon :disabled="e1 === 2" large @click="next()" class="arrowButton"
        >mdi-arrow-right</v-icon
      >
    </v-stepper-header>

    <div class="text-center py-2">
      <v-btn
        color="white"
        width="45%"
        height="40px"
        class="mx-2 red--text"
        :disabled="e1 === 1"
        @click="prev()"
      >
        Cancel
      </v-btn>
      <v-btn
        v-show="nextShow"
        color="green"
        width="45%"
        height="40px"
        class="mx-2 white--text"
        @click="next()"
      >
        Avançar
      </v-btn>
      <v-btn
        v-show="submitShow"
        color="green"
        width="45%"
        height="40px"
        class="mx-2 white--text"
        @click="submit()"
      >
        Criar Produto
      </v-btn>

      <!-- Modal de Produtos Relacionados -->
      <v-dialog v-model="dialog" max-width="300px">
        <v-card>
          <v-card-text>
            <v-select
              clearable
              color="green"
              :items="ListProducts"
              item-text="productName"
              v-model="itemRelation"
              label="Selecionar um produto"
              class="pt-5"
            ></v-select>
          </v-card-text>
          <v-card-actions>
            <v-btn
              v-if="indexRelation != null"
              text
              color="error"
              @click="removeRelation()"
            >
              Remover
            </v-btn>
            <v-btn text color="green" @click="setRelation(itemRelation)">
              Adicionar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>

      <!-- Modal de Produtos -->
      <v-dialog v-model="produtosModal" max-width="300px">
        <v-card>
          <v-card-text>
            <v-select
              clearable
              color="green"
              :items="ListProducts"
              item-text="productName"
              v-model="itemRelation"
              label="Selecionar um produto"
              class="pt-5"
              return-object
            ></v-select>
          </v-card-text>
          <v-card-actions>
            <v-btn
              v-if="indexRelation != null"
              text
              color="error"
              @click="removeRelation()"
            >
              Remover
            </v-btn>
            <v-btn text color="green" @click="setCombo(itemRelation)">
              Adicionar
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </div>
  </v-stepper>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { between, required } from "vuelidate/lib/validators";
import Product from "@/repositories/Product";
import handyUploader from "@/node_modules/handy-uploader/src/components/handyUploader";
export default {
  components: {
    handyUploader,
  },
  validations: {
    productName: { required },
    productCtg: { required },
    productValue: { required },
    productDescription: { required },
    productAltura: { between: between(2, 105) },
    productLargura: { between: between(11, 60) },
    productComprimento: { between: between(18, 105) },
  },
  props: {
    value: Boolean,
  },
  computed: {
    ...mapGetters("products", ["allproducts"]),
    ListProducts() {
      return this.allproducts;
    },
    ...mapGetters("categories", ["allcategories"]),
    ListCategories() {
      return this.allcategories;
    },
    ...mapGetters("products", ["getSwitch"]),
    SwitchValue() {
      return this.getSwitch;
    },
    show: {
      get() {
        return this.value;
      },
      set(value) {
        this.$emit("close");
      },
    },
    // Restriçao a cinco campos para produtos relacionados
    relationDisable() {
      if (this.productRelacionship.length === 5) {
        return true;
      }
      if (this.switchRelacionship === "Sim") {
        return true;
      }
    },
    // Filtro de categorias
    filterCategory() {
      const itens = [];
      this.allcategories.find((item) => {
        if (item.categoryType === "categoria") {
          itens.push(item);
        }
      });
      return itens;
    },
    // Verificação de Campos obrigatorios
    productNameErrors() {
      const errors = [];
      if (!this.$v.productName.$dirty) return errors;
      !this.$v.productName.required && errors.push("Campo obrigatório");
      return errors;
    },
    productCtgErrors() {
      const errors = [];
      if (!this.$v.productCtg.$dirty) return errors;
      !this.$v.productCtg.required && errors.push("Campo obrigatório");
      return errors;
    },
    productValueErrors() {
      const errors = [];
      if (!this.$v.productValue.$dirty) return errors;
      !this.$v.productValue.required && errors.push("Campo obrigatório");
      return errors;
    },
    productDescriptionErrors() {
      const errors = [];
      if (!this.$v.productDescription.$dirty) return errors;
      !this.$v.productDescription.required && errors.push("Campo obrigatório");
      return errors;
    },
    productAlturaErrors() {
      const errors = [];
      if (!this.$v.productAltura.$dirty) return errors;
      !this.$v.productAltura.between &&
        errors.push("Valor deve estar entre 2 e 105");
      // !this.$v.editItem.productAltura.required && errors.push("Campo obrigatório");
      return errors;
    },
    productLarguraErrors() {
      const errors = [];
      if (!this.$v.productLargura.$dirty) return errors;
      !this.$v.productLargura.between &&
        errors.push("Valor deve estar entre 11 e 60");
      // !this.$v.editItem.productAltura.required && errors.push("Campo obrigatório");
      return errors;
    },
    productComprimentoErrors() {
      const errors = [];
      if (!this.$v.productComprimento.$dirty) return errors;
      !this.$v.productComprimento.between &&
        errors.push("Valor deve estar entre 18 e 105");
      // !this.$v.editItem.productAltura.required && errors.push("Campo obrigatório");
      return errors;
    },
    filteredTags() {
      return this.autocompleteTags.filter((i) => {
        return (
          i.text.toLowerCase().indexOf(this.productTag.toLowerCase()) !== -1
        );
      });
    },
  },
  watch: {
    e1: function () {
      if (this.SwitchAtr === "Sim") {
        if (this.e1 === 3) {
          this.nextShow = false;
          this.submitShow = true;
        } else if (this.e1 < 3) {
          this.nextShow = true;
          this.submitShow = false;
        }
      } else {
        if (this.e1 === 2) {
          this.nextShow = false;
          this.submitShow = true;
        } else if (this.e1 < 2) {
          this.nextShow = true;
          this.submitShow = false;
        }
      }
    },
    productCtg: {
      // Watcher Verificando se o elemento escolhido no array possui uma subcategoria
      handler(value) {
        this.category2 = [];
        this.allcategories.find((object) => {
          if (object.categorylvl1 === value) {
            this.category2.push(object);
            this.categorylvl2Show = true;
            this.productCtg3 = "";
            this.categorylvl3Show = false;
            this.categorylvl4Show = false;
          } else {
            if (value) {
              if (!this.category2.some((i) => i.categorylvl1.includes(value))) {
                this.productCtg2 = "";
                this.categorylvl2Show = false;
              }
            }
          }
        });
      },
    },
    productCtg2: {
      handler(value) {
        // Watcher Verificando se o sub elemento escolhido no array possui uma subcategoria
        if (this.category2) {
          this.allcategories.find((object) => {
            if (object.categorylvl2 === value) {
              if (value) {
                this.category3.push(object);
                this.productCtg4 = "";
                this.categorylvl3Show = true;
                this.categorylvl4Show = false;
              }
            } else {
              if (value) {
                if (
                  !this.category3.some((i) => i.categorylvl2.includes(value))
                ) {
                  this.productCtg3 = "";
                  this.categorylvl3Show = false;
                  this.categorylvl4Show = false;
                }
              }
            }
          });
        }
      },
    },
    productCtg3: {
      handler(value) {
        // Watcher Verificando se o sub elemento escolhido no array possui uma subcategoria
        if (this.category3) {
          this.allcategories.find((object) => {
            if (object.categorylvl3 === value) {
              if (value) {
                this.category4.push(object);
                this.categorylvl4Show = true;
              }
            } else {
              if (value) {
                if (
                  !this.category4.some((i) => i.categorylvl3.includes(value))
                ) {
                  this.categorylvl4 = "";
                  this.categorylvl4Show = false;
                }
              }
            }
          });
        }
      },
    },
  },
  data() {
    return {
      // tagArray: [],
      produtosModal: false,
      productCombo: [],
      showProduct: false,
      handyAttachments: [],
      snackbar: false,
      indexRelation: null,
      dialog: false,
      timeout: 2500,
      e1: 1,
      itemRelation: "",
      step: 1,
      prevShow: false,
      nextShow: true,
      submitShow: false,
      SwitchAtr: "Não",
      switchDiscount: "%",
      switchRelacionship: "Não",
      productName: "",
      productMarca: "",
      productValue: "",
      productCtg: "",
      productCtg2: "",
      productCtg3: "",
      productCtg4: "",
      categorylvl2Show: false,
      categorylvl3Show: false,
      categorylvl4Show: false,
      productIMG: [],
      imagesTemp: [],
      productSku: "",
      productQtd: 0,
      productDiscount: "",
      productValueDiscount: "",
      productDescription: "",
      productRelacionship: [],
      productRelacionshipCount: ["1", "2", "3", "4", "5"],
      productPeso: "",
      productAltura: "",
      productLargura: "",
      productComprimento: "",
      productTag: "",
      productTagList: [],
      autocompleteTags: [],
      productAtr: [],
      productList: [],
      attribute: [],
      category: [],
      category2: [],
      category3: [],
      category4: [],
      created: false,
      attributeTemp: [],
      ex12: 0,
      files: [],
      ex13: {},

      // dropzoneOptions: {
      //   url: "http://httpbin.org/anything",
      //   thumbnailWidth: 150, // px
      //   thumbnailHeight: 100,
      //   maxFiles: 2,
      //   // previewTemplate: this.template(),
      //   addRemoveLinks: true,
      //   headers: { "My-Awesome-Header": "header value" },
      // },
    };
  },
  methods: {
    ...mapActions("products", ["ChangeSwitch"]),
    ...mapActions("categories", ["loadCategories"]),
    ...mapActions("products", ["loadProducts"]),
    applyDiscount() {
      if (this.switchDiscount === "$") {
        this.productValueDiscount = this.productValue - this.productDiscount;
      } else {
        this.productValueDiscount =
          this.productValue - (this.productDiscount / 100) * this.productValue;
      }
    },
    // Adiciona um produto a um array de produtos relacionados
    setRelation(item) {
      // Procura o protudo selecionado no array productList
      this.ListProducts.find((object) => {
        if (object.productName === item) {
          // Caso o index seja definido no modal, sera realizado uma troca do elemento do array pelo elemento selecionado
          // Depois a variavel indexRelation e resetada
          if (this.indexRelation != null) {
            this.productRelacionship.splice(this.indexRelation, 1, object);
            this.indexRelation = null;
            // Senão apenas adicione o objeto ao array
          } else {
            this.productRelacionship.push(object);
          }
        }
      });
      // Reset do Modal e item selecionado
      this.itemRelation = "";
      this.dialog = false;
    },
    setCombo(item) {
      const newProductCombo = {
        productName: item.productName,
        pk: item.pk
      }
      this.productCombo.push(newProductCombo)
      // Reset do Modal e item selecionado
      this.itemRelation = "";
      this.produtosModal = false;
    },
    removeRelation() {
      this.productRelacionship.splice(this.indexRelation, 1);
      this.indexRelation = null;
      this.itemRelation = "";
      this.dialog = false;
    },
    generateRandomNumber() {
      var randomNumber = this.ListProducts.length;
      var index = Math.floor(Math.random() * randomNumber);
      return index;
    },
    async submit() {
      //Gerando Objeto
      var newProduct = {
        productIMG: this.handyAttachments,
        productName: this.productName,
        productCtg: this.defineCategory(this.productCtg),
        productValue: parseFloat(this.productValue).toFixed(2),
        productSku: this.productSku,
        productTag: this.productTagList,
        productQtd: parseInt(this.productQtd),
        productDiscount: parseFloat(this.productDiscount).toFixed(2),
        productValueDiscount: parseFloat(this.productValueDiscount).toFixed(2),
        productDescription: this.productDescription,
        productPeso: this.productPeso,
        productAltura: this.productAltura,
        productLargura: this.productLargura,
        productComprimento: this.productComprimento,
        productCombo: this.productCombo
        // productRelacionship: this.productRelacionship,
      };
      // Verificando se produtos relacionaods será automatico ou não
      if (this.switchRelacionship === "Não") {
        newProduct.productRelacionship = this.productRelacionship.map(
          (item) => item.pk
        );
      } else if (this.switchRelacionship === "Sim") {
        var productList = [];
        for (let index = 0; index < 5; index++) {
          var value = this.generateRandomNumber(); //gera numero aleatoria baseado no length da lista de produtos
          if (productList.includes(this.ListProducts[value].pk)) {
            // Validade se produto já foi selecionado
            while (productList.includes(this.ListProducts[value].pk)) {
              //Cai no while até pegar um produto que não tenha sido selecionado
              value = this.generateRandomNumber();
            }
            productList.push(this.ListProducts[value].pk);
          } else {
            productList.push(this.ListProducts[value].pk);
          }
        }
        newProduct.productRelacionship = productList;
      }
      if (this.productCtg2) {
        newProduct.productCtg1 = this.defineCategory(this.productCtg2);
      }
      console.log(newProduct);
      Product.createProducts(newProduct).then((response) => {
        response
          .json()
          .then((data) => {
            console.log(data);
            if (response.status === 201) {
              this.closeModal();
            } else {
              this.color = "error";
              (this.text = "Erro ao criar produto"), (this.snackbar = true);
            }
          })
          .catch((error) => console.log("error", error));
      });
    },  
    next() {
      this.$v.$touch();
      if (this.$v.$invalid) {
        console.log("Campos não preenchidos");
        console.log(this.$v.$invalid);
      } else {
        this.e1++;
      }
    },
    prev() {
      this.e1--;
    },
    closeModal() {
      this.$forceUpdate();
      this.show = false;
      // this.productName = "";
      // this.handyAttachments = [];
      // this.productMarca = "";
      // this.productCtg = "";
      // this.productSku = "";
      // this.productQtd = "";
      // this.productTag = "";
      // this.productTagList = [];
      // this.productValue = "";
      // this.productDiscount = "";
      // this.productValueDiscount = "";
      // this.productDescription = "";
      // this.productPeso = "";
      // this.productAltura = "";
      // this.productLargura = "";
      // this.productComprimento = "";
      // this.productRelacionship = "";
      // this.variacoes = [];
      // this.productAtr = [];
      // this.attributeTemp = [];
      // this.productRelacionship = [];
      // this.e1 = 1;
    },
    defineCategory(value) {
      var name = "";
      this.allcategories.find((object) => {
        if (object.pk === value) {
          console.log(object);
          name = object.categorySlug;
        }
      });
      return name;
    },
    getTags() {
      var tags = [];
      this.allproducts.find((item) => {
        if (item.productTag) {
          item.productTag.find((text) => {
            tags.push(text);
          });
        }
      });
      this.autocompleteTags = tags;
    },
  },
  mounted() {
    this.loadCategories();
    this.loadProducts();
    this.getTags();
  },
};
</script>


<style scoped>
::v-deep .text-red input {
  color: rgb(219, 44, 44) !important;
}
::v-deep .v-application--is-ltr .v-stepper__step__step {
  width: 30px;
  height: 30px;
  font-size: 25px;
}
::v-deep .show-btns {
  color: rgb(26, 24, 24) !important;
}
::v-deep .v-input--switch--inset .v-input--switch__track {
  width: 42px !important;
  height: 22px !important;
}
::v-deep .v-input--switch--inset .v-input--switch__thumb {
  width: 14px !important;
  height: 14px !important;
}
::v-deep .v-input--selection-controls__ripple {
  height: 27px;
  width: 27px;
}
</style>