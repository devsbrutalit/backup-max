<template>
  <div class="mx-auto" style="max-width: 480px">
    <v-card elevation="8">
      <v-card-text class="text-center text-h6 font-weight-bold">
        <p class="black--text">Total de produtos</p>
        <p class="headline black--text text-h4 font-weight-bold">
          {{ allproducts.length }}
        </p>
      </v-card-text>
    </v-card>

    <!-- Card para chamar modal para adicionar produtos -->
    <div v-for="item in buttonOptions" :key="item.title">
      <v-hover v-slot="{ hover }">
        <NuxtLink :to="item.to" style="text-decoration: none; color: inherit">
          <v-card
            class="my-5 text-center black--text"
            :class="{ 'on-hover': hover }"
            elevation="0"
            color="transparent"
          >
            <v-card-actions>
              <v-icon
                size="90"
                color="black"
                class="mr-auto"
                :class="{ 'on-hover-icon': hover }"
              >
                mdi-plus-circle-outline
              </v-icon>
              <span style="font-size: 2rem">{{ item.title }}</span>
            </v-card-actions>
          </v-card>
        </NuxtLink>
      </v-hover>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
export default {
  props: {
    source: String,
  },
  computed: {
    ...mapGetters("products", ["allproducts"]),
  },
  data() {
    return {
      buttonOptions: [
        { title: "Add Produto", to: "/produtos/add_produtos" },
        { title: "Add Categoria", to: "/produtos/categorias" },
        { title: "Add Atributo", to: "/produtos/atributos" },
      ],
    };
  },
  methods: {
    ...mapActions("products", ["loadProducts"]),
    forceRerender() {
      this.componentKey += 1;
    },
    eventEmit() {
      this.loadProducts();
      this.addproduto = false;
    },
  },
  created() {
    this.loadProducts();
  },
};
</script>

<style scoped>
.on-hover {
  transition: background 0.5s;
  background: #41433e!important;
  color: #aef82d !important;
}

.on-hover-icon {
  color: #aef82d !important;
}
</style>