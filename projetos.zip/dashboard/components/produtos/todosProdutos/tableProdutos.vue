<template>
  <div>
    <v-data-table
      :headers="headers"
      :items="getAllproducts"
      class="elevation-1"
      height="800px"
      fixed-header
      hide-default-footer
      disable-pagination
    >
      <!-- Template Filtros -->
      <!-- Filtro de Categorias -->
      <template v-slot:[`header.productCtg`]>
        <div style="display: inline-block; padding: 16px 0">Por Categoria</div>
        <div style="display: inline-block; margin-top: 8px">
          <v-menu offset-y :close-on-content-click="false">
            <template v-slot:activator="{ on, attrs }">
              <v-btn color="indigo" icon v-bind="attrs" v-on="on">
                <v-icon small> mdi-filter-variant </v-icon>
              </v-btn>
            </template>
            <v-list>
              <v-list-item-group v-model="name" multiple>
                <v-list-item
                  v-for="(item, index) in allProductName"
                  :key="index"
                  :value="item"
                >
                  <template v-slot:default="{ active }">
                    <v-list-item-action>
                      <v-checkbox
                        :input-value="active"
                        :true-value="item"
                        color="primary"
                        :ripple="false"
                        dense
                      ></v-checkbox>
                    </v-list-item-action>
                    <v-list-item-title>{{ item }}</v-list-item-title>
                  </template>
                </v-list-item>
              </v-list-item-group>
              <v-divider></v-divider>
              <v-btn text block @click="clearAll()" color="warning"
                >Clear all</v-btn
              >
            </v-list>
          </v-menu>
        </div>
      </template>

      <!-- Filtro de Qtd -->
      <!-- <template v-slot:[`header.productQtd`]>
            <div style="display: inline-block; padding: 16px 0;">Por Qtd</div>
            <div style="display: inline-block; margin-top: 8px">
             <v-menu offset-y :close-on-content-click="false">
              <template v-slot:activator="{ on, attrs }">
              <v-btn color="indigo" icon v-bind="attrs" v-on="on">
                <v-icon small>
                  mdi-filter-variant
                </v-icon>
              </v-btn>
              </template>
              <v-list>
              <v-list-item-group v-model="qtd" multiple>
                <v-list-item
                  v-for="(item, index) in allQtd"
                  :key="index" :value="item"
                >
                <template v-slot:default="{ active }">
                  <v-list-item-action>
                <v-checkbox :input-value="active" :true-value="item" color="primary" :ripple="false" dense></v-checkbox>
                </v-list-item-action>
                  <v-list-item-title>{{ item }}</v-list-item-title>
                </template>
                </v-list-item>
              </v-list-item-group>
              <v-divider></v-divider>
              <v-btn text block @click="clearAll()" color="warning">Clear all</v-btn>
              </v-list>
            </v-menu>
            </div>
          </template> -->

      <!-- Filtro de Valor -->
      <!-- <template v-slot:[`header.productValue`]>
            <div style="display: inline-block; padding: 16px 0;">Por preço</div>
            <div style="display: inline-block; margin-top: 8px">
             <v-menu offset-y :close-on-content-click="false">
              <template v-slot:activator="{ on, attrs }">
              <v-btn color="indigo" icon v-bind="attrs" v-on="on">
                <v-icon small>
                  mdi-filter-variant
                </v-icon>
              </v-btn>
              </template>
              <v-list>
              <v-list-item-group v-model="value" multiple>
                <v-list-item
                  v-for="(item, index) in allValue"
                  :key="index" :value="item"
                >
                <template v-slot:default="{ active }">
                  <v-list-item-action>
                <v-checkbox :input-value="active" :true-value="item" color="primary" :ripple="false" dense></v-checkbox>
                </v-list-item-action>
                  <v-list-item-title>{{ item }}</v-list-item-title>
                </template>
                </v-list-item>
              </v-list-item-group>
              <v-divider></v-divider>
              <v-btn text block @click="clearAll()" color="warning">Clear all</v-btn>
              </v-list>
            </v-menu>
            </div>
          </template> -->

      <!-- Filtro de data Cadastro -->
      <template v-slot:[`header.createdAt`]>
        <div style="display: inline-block; padding: 16px 0">
          Por data de cadastro
        </div>
        <div style="display: inline-block; margin-top: 8px">
          <v-menu offset-y :close-on-content-click="false">
            <template v-slot:activator="{ on, attrs }">
              <v-btn color="indigo" icon v-bind="attrs" v-on="on">
                <v-icon small> mdi-filter-variant </v-icon>
              </v-btn>
            </template>
            <v-list>
              <v-list-item-group v-model="createAt" multiple>
                <v-list-item
                  v-for="(item, index) in allDate"
                  :key="index"
                  :value="item"
                >
                  <template v-slot:default="{ active }">
                    <v-list-item-action>
                      <v-checkbox
                        :input-value="active"
                        :true-value="item"
                        color="primary"
                        :ripple="false"
                        dense
                      ></v-checkbox>
                    </v-list-item-action>
                    <v-list-item-title>{{ item }}</v-list-item-title>
                  </template>
                </v-list-item>
              </v-list-item-group>
              <v-divider></v-divider>
              <v-btn text block @click="clearAll()" color="warning"
                >Clear all</v-btn
              >
            </v-list>
          </v-menu>
        </div>
      </template>
      <!-- Fim templates filtros -->

      <!-- <template v-slot:[`header.actions`]>
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Ex: Nome, SKU, etc..."
          single-line
          hide-details
        ></v-text-field>
      </template> -->

      <!-- Template para imagem -->

      <!-- MAX COMENTOU - TRECHO COMENTADO POR MAX -->
      <!-- <template v-slot:[`item.imagem`]="{ item }">
        <v-img
          max-width="80"
          class="my-2 ma-auto"
          :src="
            item.productVariations
              ? item.productVariations[0].productPicture.find(
                  (main) => main.mainImage === true
                ).image
              : item.productPicture.find((main) => main.mainImage === true)
                  .image
          "
        ></v-img>
      </template> -->

      <template v-slot:[`item.imagem`]="{ item }">
        <v-img
          max-width="80"
          class="my-2 ma-auto"
          :src="verificaImg(item)"></v-img>
      </template>

      


      <!-- item.productVariations[0].productVarImg[0] : (item.productPicture[0] ? item.productPicture[0] : '') -->
      <!-- Template para Categoria/Nome produto -->
      <template v-slot:[`item.productCtg`]="{ item }">
        <v-list-item two-line>
          <v-list-item-content>
            <v-list-item-title>{{ item.productName }}</v-list-item-title>
            <v-list-item-subtitle>{{ item.productCtg }}</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </template>

      <!-- Template para valor do produto COMENTADO POR MAX  ABAIXO-->

      <!--
      <template v-slot:[`item.productValue`]="{ item }">
        <span
          v-text="
            item.productVariations
              ? 'R$ ' + item.productVariations[0].productValue
              : 'R$ ' + item.productValue
          "
        ></span>
      </template>

      -->

      <!-- Template para data de criação/dias passados -->
      <template v-slot:[`item.createdAt`]="{ item }">
        <v-list-item two-line>
          <v-list-item-content>
            <v-list-item-title
              class="text-left black--text"
              style="font-size: 14px"
              ><v-icon small>mdi-timer-outline</v-icon>
              {{
                daysPassed(item.createdAt) + " Dias atrás"
              }}</v-list-item-title
            >
            <v-list-item-subtitle
              class="text-left black--text"
              style="font-size: 14px"
              ><v-icon small>mdi-timer-outline</v-icon>
              {{ setDate(item.createdAt) }}</v-list-item-subtitle
            >
          </v-list-item-content>
        </v-list-item>
      </template>

      <template v-slot:[`item.productShow`]="{ item }">
        <v-chip v-if="item.productShow === true" color="#AEF82D">ON</v-chip>
        <v-chip v-else color="red">OFF</v-chip>
      </template>

      <!-- Template para ações -->
      <template v-slot:[`item.actions`]="{ item }">
        <v-icon @click="confirmProductDelete(item)" color="red">
          mdi-delete
        </v-icon>
        <NuxtLink
          :to="'/produtos/todosProdutos/' + item.pk"
          style="text-decoration: none; color: inherit"
        >
          <v-icon color="blue"> mdi-pencil-circle </v-icon>
        </NuxtLink>
      </template>
    </v-data-table>

    <!-- Chamada do Modal para editar produtos -->
    <v-dialog
      v-model="editproduto"
      persistent
      width="auto "
      :fullscreen="$vuetify.breakpoint.xsOnly"
      content-class="dialogFull"
      transition="dialog-right-transition"
    >
      <EditProduto
        v-on:productCreated="eventEmit"
        :editItem="editItem"
        @close="editproduto = false"
      />
    </v-dialog>

    <!-- Modal para confirmação de deleção de produto -->
    <v-dialog v-model="confirmDelete" max-width="400" @keydown.esc="cancel">
      <v-card>
        <v-toolbar dark color="grey lighten-3" dense flat>
          <v-toolbar-title class="text-body-1 font-weight-bold grey--text">
            Confirmação para deleção de Produto
          </v-toolbar-title>
        </v-toolbar>
        <v-card-text class="pa-4 black--text">
          Realmente deseja deletar o produto ?
        </v-card-text>
        <v-card-actions class="pt-3">
          <v-spacer></v-spacer>
          <v-btn
            v-if="!noconfirm"
            color="grey"
            text
            class="body-2 font-weight-bold"
            @click.native="confirmDelete = false"
            >Cancel</v-btn
          >
          <v-btn
            color="primary"
            class="body-2 font-weight-bold"
            outlined
            @click.native="deleteProduct()"
            >Deletar</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import Product from "@/repositories/Product";
// import AddProduto from "@/components/produtos/add_produtos.vue";
// import EditProduto from "@/components/produtos/edit_produtos.vue";

export default {
  components: {
    // AddProduto,
    // EditProduto,
  },
  props: {
    source: String,
  },
  computed: {
    ...mapGetters("products", ["allproducts"]),
    getAllproducts() {
      this.produtos = this.allproducts;
      return this.produtos;
    },
    allProductName() {
      const category = [];
      this.produtos.map((f) => {
        if (!category.includes(f.productCtg)) {
          category.push(f.productCtg);
        }
      });
      return category;
    },
    allQtd() {
      const qtd = [];
      this.produtos.map((f) => {
        if (!qtd.includes(f.productQtd)) {
          qtd.push(f.productQtd);
        }
      });
      return qtd;
    },
    /* comentado POR MAX
    allValue() {
      const value = [];
      this.produtos.map((f) => {
        if (!value.includes(f.productValue)) {
          value.push(f.productValue);
        }
      });
      return value;
    },*/
    allDate() {
      const createdDate = [];
      this.produtos.map((f) => {
        const date = new Date(f.createdAt);
        const data =
          date.getDate() +
          " " +
          date.toLocaleString("default", { month: "long" }) +
          " " +
          date.getFullYear();
        if (!createdDate.includes(data)) {
          createdDate.push(data);
        }
      });
      return createdDate;
    },
    closeOnContentClick() {
      return this.name.length === 0 ? false : true;
    },
  },
  data() {
    return {
      noconfirm: false,
      confirmDelete: false,
      produtos: [],
      editItem: {},
      itemDeleteTemp: {},
      // search: "",
      name: [],
      qtd: [],
      value: [],
      status: [],
      createAt: [],
      vendas: [],
      filters: { PRODUTO: [], QTD: [], VALOR: [] },
      created: false,
      addproduto: false,
      editproduto: false,
      addcategoria: false,
      addatributo: false,
      headers: [
        { text: "Imagem", align: "center", value: "imagem", sortable: false },
        { text: "produtoSearch", value: "productName", align: " d-none" },
        { text: "categorySearch", value: "productCtg", align: " d-none" },
        { text: "qtdSearch", value: "productQtd", align: " d-none" },
        //{ text: "valorSearch", value: "productValue", align: " d-none" }, MAX
        {
          text: "produto",
          align: "start",
          value: "productCtg",
          filter: (f) => {
            return this.name.length > 0
              ? this.name.includes(f)
              : this.allProductName;
          },
        },
        { text: "Qtd", align: "start", value: "productQtd" }, // filter: f => { return this.qtd.length > 0 ? this.qtd.includes(f) : this.allProductName }},
        // MAX { text: "Valor", align: "center", value: "productValue" }, //filter: f => { return this.value.length > 0 ? this.value.includes(f) : this.allProductName }},
        { text: "Status", align: "center", value: "productShow" },
        {
          text: "CREATED AT",
          align: "center",
          value: "createdAt",
          filter: (f) => {
            const date = new Date(f);
            const data =
              date.getDate() +
              " " +
              date.toLocaleString("default", { month: "long" }) +
              " " +
              date.getFullYear();
            return this.createAt.length > 0
              ? this.createAt.includes(data)
              : this.allProductName;
          },
        },
        { text: "Actions", align: "center", value: "actions", sortable: false },
      ],
    };
  },
  methods: {
    ...mapActions("products", ["loadProducts"]),
         verificaImg(item){
      // if (item.productVariations){
      //   if (item.productVariations[0].productPicture.find(
      //     (main) => main.mainImage === true).image){}
     // }

      if (item.productVariations) { 

      } else {
        if (item.productPicture.find((main) => main.mainImage === true)) {

          return item.productPicture.find((main) => main.mainImage === true).image
        
        } else { 
            return item.productPicture[0].image
          }
      }




       /*return item.productVariations
       ? item.productVariations[0].productPicture.find(
          (main) => main.mainImage === true).image
        : item.productPicture.find((main) => main.mainImage === true).image

  */
     },

    confirmProductDelete(item) {
      this.confirmDelete = true;
      this.itemDeleteTemp = item;
    },

    deleteProduct() {
      Product.deleteProduct(this.itemDeleteTemp).then((response) => {
        response
          .json()
          .then((data) => {
            console.log(data);
            (this.itemDeleteTemp = {}), (this.confirmDelete = false);
            this.loadProducts();
          })
          .catch((error) => console.log("error", error));
      });
    },

    setEditItem(item) {
      console.log(item);
      this.editItem = Object.assign({}, item);
      this.editproduto = !this.editproduto;
    },

    eventEmit() {
      console.log("não caiu aqui");
      this.loadProducts();
    },

    clearAll() {
      this.name = [];
    },

    setDate(value) {
      // const data = date.getDay()
      const date = new Date(value);
      const data =
        date.getDate() +
        " " +
        date.toLocaleString("default", { month: "long" }) +
        " " +
        date.getFullYear();
      return data;
    },

    searchProducts(value) {
      if (value) {
        const fitler = this.produtos.includes(value);
        return filter;
      } else {
        return this.produtos;
      }
    },

    daysPassed(value) {
      const date = new Date(value);
      const now = new Date();
      const Difference_In_Time = now.getTime() - date.getTime();
      const Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
      return parseInt(Difference_In_Days);
    },
  },

  created() {
    this.loadProducts();
    this.verificaImg;
    // console.log(this.allproducts);
  },
};
</script>

<style>
</style>