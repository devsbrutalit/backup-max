<template>
  <v-container style="height: 100%">
    <div class="text-center">
      <span v-if="!editItem" class="headline">Add Categoria</span>
      <span v-if="editItem" class="headline">Editar Categoria</span>
    </div>

    <v-container>
      <v-card class="px-5" tile color="transparent" elevation="0">
        <div class="pt-3">Nome da categoria</div>
        <v-text-field v-model="categoryName" solo required></v-text-field>
        <div>Slug</div>
        <v-text-field v-model="categorySlug" solo required></v-text-field>

        <div v-if="!editItem">Categoria Nivel 1</div>
        <v-select
          v-model="categorylvl1"
          v-if="!editItem"
          :items="onlyCategory"
          item-value="pk"
          item-text="categoryName"
          label="Nenhum"
          clearable
          required
          solo
        ></v-select>

        <div v-if="categorylvl2Show === true && !editItem">
          Categoria Nivel 2
        </div>
        <v-select
          v-if="categorylvl2Show === true && !editItem"
          v-model="categorylvl2"
          :items="category2"
          item-value="pk"
          item-text="categoryName"
          label="Nenhum"
          clearable
          required
          solo
        ></v-select>

        <div v-if="categorylvl3Show === true && !editItem">
          Categoria Nivel 3
        </div>
        <v-select
          v-if="categorylvl3Show === true && !editItem"
          v-model="categorylvl3"
          :items="category3"
          item-value="pk"
          item-text="categoryName"
          label="Nenhum"
          solo
          clearable
          required
        ></v-select>
      </v-card>
      <v-sheet
        color="white ma-auto"
        elevation="1"
        class="text-center my-5"
        style="font-size: 16px"
        v-if="!editItem"
      >
        <div class="py-2 px-10">
          <v-icon color="black">mdi-information</v-icon>
          <br />
          Escolha uma outra categoria já cadastrada para criar a hierarquia de
          categorias e subcategorias. O termo Tênis, pro exemplo, seria uma
          subcategoria de categoria Calçados.
        </div>
      </v-sheet>
    </v-container>

    <div class="text-center">
      <v-btn
        color="white"
        height="40px"
        class="mx-2 red--text"
        to="/produtos/categorias"
      >
        Voltar
      </v-btn>
      <v-btn
        color="#41433e"
        height="40px"
        class="mx-2"
        style="color: #aef82d"
        v-if="!editItem"
        @click="submit()"
      >
        Criar categoria
      </v-btn>

      <v-btn
        color="#41433e"
        height="40px"
        class="mx-2"
        style="color: #aef82d"
        v-if="!editItem"
        @click="update()"
      >
        Atualizar categoria
      </v-btn>
    </div>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import Category from "@/repositories/Category";
export default {
  props: {
    editItem: true,
  },
  computed: {
    ...mapGetters("categories", ["allcategories"]),
    onlyCategory() {
      const itens = [];
      this.allcategories.find((item) => {
        if (item.categoryType === "categoria") {
          itens.push(item);
        }
      });
      return itens;
    },
  },
  watch: {
    categorylvl1: {
      // Watcher Verificando se o elemento escolhido no array possui uma subcategoria
      handler(value) {
        this.category2 = [];
        this.allcategories.find((object) => {
          if (object.categorylvl1 === value) {
            if (value) {
              this.category2.push(object);
              console.log(object);
              this.categorylvl2Show = true;
              this.categorylvl3 = "";
              this.categorylvl3Show = false;
            }
          } else {
            if (value) {
              if (!this.category2.some((i) => i.categorylvl1.includes(value))) {
                this.categorylvl2 = "";
                this.categorylvl2Show = false;
              }
            }
          }
        });
      },
    },
    categorylvl2: {
      handler(value) {
        // Watcher Verificando se o sub elemento escolhido no array possui uma subcategoria
        if (this.category2) {
          this.allcategories.find((object) => {
            if (object.categorylvl2 === value) {
              if (value) {
                this.category3.push(object);
                this.categorylvl3Show = true;
              }
            } else {
              if (value) {
                if (
                  !this.category3.some((i) => i.categorylvl2.includes(value))
                ) {
                  this.categorylvl3 = "";
                  this.categorylvl3Show = false;
                }
              }
            }
          });
        }
      },
    },
  },
  data() {
    return {
      categoryName: "",
      categorySlug: "",
      categorylvl1: "",
      categorylvl2: "",
      categorylvl3: "",
      editPage: false,
      categorylvl2Show: false,
      categorylvl3Show: false,
      categoryImg: "no picture",
      selection: [],
      obj: {},
      category: [],
      category2: [],
      category3: [],
    };
  },
  methods: {
    ...mapActions("categories", ["loadCategories"]),

    async submit() {
      var newCategory = {};
      if (this.categorylvl1) {
        if (this.categorylvl2) {
          if (this.categorylvl3) {
            newCategory = {
              categoryType: "categorylvl4",
              categorySlug: this.categorySlug,
              categoryName: this.categoryName,
              categorylvl3: this.categorylvl3,
            };
          } else {
            newCategory = {
              categoryType: "categorylvl3",
              categorySlug: this.categorySlug,
              categoryName: this.categoryName,
              categorylvl2: this.categorylvl2,
            };
          }
        } else {
          newCategory = {
            categoryType: "categorylvl2",
            categorySlug: this.categorySlug,
            categoryName: this.categoryName,
            categorylvl1: this.categorylvl1,
          };
        }
      } else {
        newCategory = {
          categoryName: this.categoryName,
          categorySlug: this.categorySlug,
        };
      }

      // console.log(newCategory);
      Category.createCategory(newCategory).then((response) => {
        response
          .json()
          .then((data) => {
            console.log(data);
            if (response.status === 201) {
              this.created = true;
              this.color = "success";
              (this.text = "Evento criado"), (this.snackbar = true);
              this.closeModal();
            } else {
              this.color = "error";
              (this.text = "Erro ao criar evento"), (this.snackbar = true);
            }
          })
          .catch((error) => console.log("error", error));
      });
    },

    async update() {
      var url = new URL(window.location);
      var pk = url.pathname.replace("/produtos/categorias/id=","")
      console.log(pk)
      const updateCategory = {
        pk: pk,
        categoryName: this.categoryName,
      };
      //console.log(updateCategory);
      // Category.updateCategory(updateCategory).then((response) => {
      //   response
      //     .json()
      //     .then(() => {
      //       if (response.status === 200) {
      //         this.created = true;
      //         this.color = "success";
      //         this.text = "Produto excluído";
      //         this.y = "bottom";
      //         this.snackbar = true;
      //       }
      //     })
      //     .catch((error) => console.log("error", error));
      // });

      console.log('to aqui');
      Category.updateCategory(updateCategory).then(() => {
        

              this.created = true;
              this.color = "success";
              this.text = "Produto excluído";
              this.y = "bottom";
              this.snackbar = true;
            
      })
          .catch((error) => console.log("error", error));
      



    },
    async delete(categoryID) {
      let category = {
        categoryID: categoryID,
      };

      Category.deleteCategory(category).then((response) => {
        response
          .json()
          .then(() => {
            if (response.status === 200) {
              this.color = "success";
              this.text = "Produto excluído";
              this.y = "bottom";
              this.snackbar = true;
              this.getproducts();
            }
          })
          .catch((error) => console.log("error", error));
      });
    },
  },
  created() {
    this.loadCategories();
    
    if (this.editItem) {
      this.categoryName = this.editItem.categoryName;
      this.categorySlug = this.editItem.categorySlug;
    }
  },
};
</script>

<style>
</style>