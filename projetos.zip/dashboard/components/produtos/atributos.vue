<template>
  <v-container>
    <v-stepper v-model="e1" class="pa-2" style="box-shadow: none;background:transparent">
      <v-row>
        <v-col cols="12" sm="6" md="4" class="pl-10">
          <h1 v-if="!editItem">Adicionar Atributo</h1>
          <h1 v-else>Editar Atributo</h1>
          <span>
            Adicione um atributo para incluir nas variações de produtos.
          </span>
        </v-col>
        <v-col cols="12" sm="6" md="8" class="pr-11">
          <v-sheet
            elevation="1"
            height="140"
            width="670"
            class="text-center my-5 ma-auto"
            style="font-size: 12px"
          >
            <div class="py-2 px-10">
              <v-icon color="black">mdi-information</v-icon>
              <br />
              Crie aqui as variações para você usar em seus produtos.
              <br />
              <p class="mt-2">
                Uma variação também conhecida como atributo, define o tipo de
                opção que o seu cliente escolherá na hora de comprar um produto.
                Por exemplo: cor, Tamanho, Material, e para cada um os seus
                respectivos valores, pro exemplo: Azul, Vermelho e Verde para
                Cora;P, M e G para Tamanho;Plático, Vidro e Alumínio para
                Material.
              </p>
            </div>
          </v-sheet>
        </v-col>
      </v-row>
      <v-stepper-items>
        
        <!-- Passo 1 -->
        <v-stepper-content step="1" class="px-10 py-0">
          <v-row no-gutters>
            <v-col cols="12">
              <v-card class="px-5" tile color="transparent">
                <v-row>
                  <!-- Nome Atributo -->
                  <v-col cols="12" sm="6" md="6">
                    <div>Nome do atributo</div>
                    <v-text-field
                      v-model="attributeName"
                      solo
                      required
                    ></v-text-field>
                  </v-col>
                  <!-- Tipo do atributo -->
                  <v-col cols="12" sm="6" md="6">
                    <div>Tipo de atributo</div>
                    <v-select
                      v-model="attributetype"
                      :disabled="editItem ? true : false"
                      :items="['Cor', 'Número', 'Texto']"
                      @change="reset()"
                      label="Escolha um tipo(cor, número ou texto)"
                      solo
                      required
                    ></v-select>
                  </v-col>
                </v-row>
              </v-card>
            </v-col>
          </v-row>
        </v-stepper-content>

        <!-- Seleção Cor -->
        <!-- Passo 2 -->
        <v-stepper-content
          step="2"
          class="py-0 px-10"
          v-if="attributetype === 'Cor'"
        >
          <v-row no-gutters>
            <v-col cols="12" sm="6" md="4">
              <h3>Nome do atributo</h3>
              <h2>{{ attributeName }}</h2>
              <h3>Tipo</h3>
              <h2>{{ attributetype }}</h2>
            </v-col>
            <v-col cols="12" sm="6" md="8">
              <v-card class="px-4" tile color="transparent" elevation="0">
                <div>Nome da variação</div>
                <v-text-field
                  v-model="variationName"
                  solo
                  required
                ></v-text-field>

                <div>Slug</div>
                <v-text-field
                  v-model="variationSlug"
                  solo
                  required
                ></v-text-field>

                <v-row>
                  <v-col cols="12" sm="6" md="8">
                    <div>Selecionar Cor</div>
                    <input type="color" @change="myColor($event)" />
                    <v-color-picker
                      dot-size="23"
                      hide-mode-switch
                      hide-canvas
                      mode="hexa"
                      :swatches="swatches"
                      show-swatches
                      v-model="variationtypeCor"
                      class="pb-1"
                    ></v-color-picker>
                  </v-col>
                  <v-col cols="12" sm="6" md="4" class="pl-0">
                    <div style="padding-top: 50%">
                      <v-btn
                        color="#41433e"
                        style="color: #aef82d"
                        @click="createVariation()"
                      >
                        Criar nova variação
                      </v-btn>
                    </div>
                  </v-col>
                </v-row>
              </v-card>
            </v-col>
          </v-row>
          <!-- Tabela Temporaria com variações -->
          <div>Variações cadastradas</div>
          <v-data-table
            :headers="headersCor"
            :items="variacoes"
            class="elevation-1"
            hide-default-footer
            height="160"
          >
            <template v-slot:[`item.cor`]="{ item }">
              <v-avatar
                :color="item.cor"
                size="25"
                class="avatarBorder"
                tile
              ></v-avatar>
            </template>
            <template v-slot:[`item.actions`]="{ item }">
              <v-icon @click="deleteAttributeTemp(item.name)" color="red">
                mdi-delete
              </v-icon>
              <v-icon @click="editAttribute(item)" color="red">
                mdi-pencil
              </v-icon>
            </template>
          </v-data-table>
        </v-stepper-content>
        <!-- Passo 3 -->
        <v-stepper-content
          step="3"
          class="py-0 px-10"
          v-if="attributetype === 'Cor'"
        >
          <v-container>
            <v-row no-gutters>
              <v-col cols="12" sm="6" md="6">
                <h3>Nome do atributo</h3>
                <h2>{{ attributeName }}</h2>
              </v-col>
              <v-col cols="12" sm="6" md="6">
                <h3>Tipo</h3>
                <h2>{{ attributetype }}</h2>
              </v-col>
            </v-row>
            <h2 class="text-center py-2">Variações cadastradas</h2>
            <v-data-table
              :headers="headersCor"
              :items="variacoes"
              class="elevation-1"
              hide-default-footer
              height="350"
            >
              <template v-slot:[`item.cor`]="{ item }">
                <v-avatar
                  :color="item.cor"
                  size="25"
                  class="avatarBorder"
                  tile
                ></v-avatar>
              </template>
              <template v-slot:[`item.actions`]="{ item }">
                <v-icon @click="deleteAttributeTemp(item.name)" color="red">
                  mdi-delete
                </v-icon>
                <v-icon
                  @click="
                    editAttribute(item);
                    e1 = 2;
                  "
                  color="red"
                >
                  mdi-pencil
                </v-icon>
              </template>
            </v-data-table>
            <div class="text-center">
              <v-btn color="#41433e" style="color: #aef82d" @click="e1 = 2" class="my-5">
                Incluir mais variações
              </v-btn>
            </div>
          </v-container>
        </v-stepper-content>

        <!-- Seleção Números -->
        <!-- Passo 2 -->
        <v-stepper-content
          step="2"
          class="py-0 px-10"
          v-if="attributetype === 'Número'"
        >
          <v-row no-gutters>
            <v-col cols="12" sm="6" md="4" style="padding-right: 10px">
              <h3>Nome do atributo</h3>
              <h2>{{ attributeName }}</h2>
              <h3>Tipo</h3>
              <h2>{{ attributetype }}</h2>
            </v-col>
            <v-col cols="12" sm="6" md="8">
              <v-card class="px-4" tile color="transparent" elevation="0">
                <div>Número da variação</div>
                <v-text-field
                  v-model="variationName"
                  type="number"
                  solo
                  required
                ></v-text-field>
              </v-card>
              <div class="text-right py-5">
                <v-btn
                  color="#41433e"
                  style="color: #aef82d"
                  @click="createVariation()"
                >
                  Criar nova variação
                </v-btn>
              </div>
            </v-col>
          </v-row>
          <!-- Tabela Temporaria com variações -->
          <div>Variações cadastradas</div>
          <v-data-table
            :headers="headersNumber"
            :items="variacoes"
            class="elevation-1"
            hide-default-footer
            height="364"
          >
            <template v-slot:[`item.actions`]="{ item }">
              <v-icon @click="deleteAttributeTemp(item.name)" color="red">
                mdi-delete
              </v-icon>
              <v-icon @click="editAttribute(item)" color="red">
                mdi-pencil
              </v-icon>
            </template></v-data-table
          >
        </v-stepper-content>
        <!-- Passo 3 -->
        <v-stepper-content
          step="3"
          class="py-0 px-10"
          v-if="attributetype === 'Número'"
        >
          <v-container>
            <v-row no-gutters>
              <v-col cols="12" sm="6" md="6">
                <h3>Nome do atributo</h3>
                <h2>{{ attributeName }}</h2>
              </v-col>
              <v-col cols="12" sm="6" md="6">
                <h3>Tipo</h3>
                <h2>{{ attributetype }}</h2>
              </v-col>
            </v-row>
            <h2 class="text-center py-2">Variações cadastradas</h2>
            <v-data-table
              :headers="headersNumber"
              :items="variacoes"
              class="elevation-1"
              hide-default-footer
              height="350"
            >
              <template v-slot:[`item.actions`]="{ item }">
                <v-icon @click="deleteAttributeTemp(item.name)" color="red">
                  mdi-delete
                </v-icon>
                <v-icon
                  @click="
                    editAttribute(item);
                    e1 = 2;
                  "
                  color="red"
                >
                  mdi-pencil
                </v-icon>
              </template></v-data-table
            >
            <div class="text-center">
              <v-btn color="#41433e" style="color: #aef82d" @click="e1 = 2" class="my-5">
                Incluir mais variações
              </v-btn>
            </div>
          </v-container>
        </v-stepper-content>

        <!-- Seleção Texto -->
        <!-- Passo 2 -->
        <v-stepper-content
          step="2"
          class="py-0 px-10"
          v-if="attributetype === 'Texto'"
        >
          <v-row no-gutters>
            <v-col cols="12" sm="6" md="4">
              <h3>Nome do atributo</h3>
              <h2>{{ attributeName }}</h2>
              <h3>Tipo</h3>
              <h2>{{ attributetype }}</h2>
            </v-col>
            <v-col cols="12" sm="6" md="8">
              <v-card class="px-4" tile color="transparent" elevation="0">
                <div>Texto da variação</div>
                <v-text-field
                  v-model="variationName"
                  solo
                  required
                ></v-text-field>

                <div>Slug</div>
                <v-text-field
                  v-model="variationSlug"
                  solo
                  required
                ></v-text-field>
              </v-card>
              <div class="text-right py-5">
                <v-btn
                  color="#41433e"
                  style="color: #aef82d"
                  @click="createVariation()"
                >
                  Criar nova variação
                </v-btn>
              </div>
            </v-col>
          </v-row>
          <!-- Tabela Temporaria com variações -->
          <div>Variações cadastradas</div>
          <v-data-table
            :headers="headersTexto"
            :items="variacoes"
            class="elevation-1"
            hide-default-footer
            height="260"
          >
            <template v-slot:[`item.actions`]="{ item }">
              <v-icon @click="deleteAttributeTemp(item.name)" color="red">
                mdi-delete
              </v-icon>
              <v-icon @click="editAttribute(item)" color="red">
                mdi-pencil
              </v-icon>
            </template></v-data-table
          >
        </v-stepper-content>
        <!-- Passo 3 -->
        <v-stepper-content
          step="3"
          class="py-0 px-10"
          v-if="attributetype === 'Texto'"
        >
          <v-container>
            <v-row no-gutters>
              <v-col cols="12" sm="6" md="6">
                <h3>Nome do atributo</h3>
                <h2>{{ attributeName }}</h2>
              </v-col>
              <v-col cols="12" sm="6" md="6">
                <h3>Tipo</h3>
                <h2>{{ attributetype }}</h2>
              </v-col>
            </v-row>
            <h2 class="text-center py-2">Variações cadastradas</h2>
            <v-data-table
              :headers="headersTexto"
              :items="variacoes"
              class="elevation-1"
              hide-default-footer
              height="348"
            >
              <template v-slot:[`item.actions`]="{ item }">
                <v-icon @click="deleteAttributeTemp(item.name)" color="red">
                  mdi-delete
                </v-icon>
                <v-icon
                  @click="
                    editAttribute(item);
                    e1 = 2;
                  "
                  color="red"
                >
                  mdi-pencil
                </v-icon>
              </template></v-data-table
            >
            <div class="text-center">
              <v-btn color="#41433e" style="color: #aef82d" @click="e1 = 2" class="my-5">
                Incluir mais variações
              </v-btn>
            </div>
          </v-container>
        </v-stepper-content>
      </v-stepper-items>

      <div>
        <v-stepper-header
          style="max-width: 338px; box-shadow: none"
          class="mx-auto"
        >
          <v-btn
            small
            fab
            :disabled="e1 === 1"
            @click="prev()"
            style="margin-top: 18px"
          >
            <v-icon large class="arrowButton">mdi-arrow-left</v-icon>
          </v-btn>
          <v-stepper-step :complete="e1 > 1" step="1" blank color="#41433e">
          </v-stepper-step>

          <v-stepper-step :complete="e1 > 2" step="2" color="#41433e">
          </v-stepper-step>

          <v-stepper-step step="3" color="#41433e"> </v-stepper-step>
          <v-btn
            small
            fab
            :disabled="validateNext"
            @click="next()"
            style="margin-top: 18px"
          >
            <v-icon large>mdi-arrow-right</v-icon></v-btn
          >
        </v-stepper-header>

        <div class="text-center">
          <v-btn
            color="white"
            width="45%"
            height="40px"
            class="mx-2"
            :disabled="e1 === 1"
            @click="prev()"
          >
            Cancel
          </v-btn>
          <v-btn
            v-show="nextShow"
            :disabled="validateNext"
            color="#41433e"
            style="color: #aef82d"
            width="45%"
            height="40px"
            class="mx-2"
            @click="next()"
          >
            Avançar
          </v-btn>
          <v-btn
            v-if="this.editItem"
            v-show="submitShow"
            color="#41433e"
            style="color: #aef82d"
            width="45%"
            height="40px"
            class="mx-2"
            @click="update()"
          >
            Atualizar atributo
          </v-btn>
          <v-btn
            v-else
            v-show="submitShow"
            color="#41433e"
            style="color: #aef82d"
            width="45%"
            height="40px"
            class="mx-2"
            @click="submit()"
          >
            Criar atributo
          </v-btn>
        </div>
      </div>
    </v-stepper>
  </v-container>
</template>

<script>
import Attribute from "@/repositories/Attribute";
export default {
  props: {
    editItem: Object,
  },
  computed: {
    validateNext() {
      if (this.e1 === 3) {
        return true;
      }
      if (!this.attributetype) {
        return true;
      }
    },
  },
  watch: {
    e1: function () {
      if (this.e1 === 3) {
        this.nextShow = false;
        this.submitShow = true;
      } else if (this.e1 < 3) {
        this.nextShow = true;
        this.submitShow = false;
      }
    },
  },
  data() {
    return {
      e1: 1,
      step: 1,
      prevShow: false,
      nextShow: true,
      submitShow: false,
      attributeName: "",
      attributetype: null,
      variationName: "",
      variationSlug: "",
      variationtypeCor: "",
      editIndex: null,
      selection: [],
      i: 25,
      obj: {},
      attribute: [],
      swatches: [
        ["#3949ABFF", "#81C784FF"],
        ["#FFFF00FF", "#311B92FF"],
        ["#000000FF", "#F173E4FF"],
        ["#FF0000FF", "#795548FF"],
      ],
      variacoes: [],
      headersCor: [
        {
          text: "Cor",
          align: "start",
          sortable: false,
          value: "cor",
        },
        { text: "Nome da Variação", value: "name" },
        { text: "Slug", value: "slug" },
        { text: "Qtd de produtos vinculados", value: "qtn" },
        { text: "Actions", value: "actions", sortable: false },
      ],
      headersNumber: [
        {
          text: "Número",
          align: "start",
          sortable: false,
          value: "name",
        },
        { text: "Qtd de produtos vinculados", value: "qtn" },
        { text: "Actions", value: "actions", sortable: false },
      ],
      headersTexto: [
        {
          text: "Texto",
          align: "start",
          sortable: false,
          value: "name",
        },
        { text: "Slug", value: "slug" },
        { text: "Qtd de produtos vinculados", value: "qtn" },
        { text: "Actions", value: "actions", sortable: false },
      ],
    };
  },
  methods: {
    myColor(e) {
      // console.log(e.target.value)
      this.variationtypeCor = e.target.value;
    },
    deleteAttributeTemp(name) {
      const checkName = this.variacoes.find((object) => object.name === name);
      if (checkName) {
        const index = this.variacoes.findIndex((item) => item.name === name);
        this.variacoes.splice(index, 1);
      }
    },
    next() {
      this.e1++;
    },
    prev() {
      this.e1--;
    },
    reset() {
      this.variacoes = [];
      this.variationName = "";
      this.variationSlug = "";
      this.variationtypeCor = "";
    },
    async submit() {
      const newAttribute = {
        attributeName: this.attributeName,
        attributetype: this.attributetype,
        variations: this.variacoes,
      };
      console.log(newAttribute);
      Attribute.createAttribute(newAttribute).then((response) => {
        response
          .json()
          .then((data) => {
            console.log(data);
            if (response.status === 201) {
              this.created = true;
              this.color = "success";
              (this.text = "Evento criado"), (this.snackbar = true);
              this.closeModal();
            } else {
              this.color = "error";
              (this.text = "Erro ao criar evento"), (this.snackbar = true);
            }
          })
          .catch((error) => console.log("error", error));
      });
    },
    async update() {
      const updateAttribute = {
        attributeID: this.editItem.pk,
        attributeName: this.attributeName,
        variations: this.variacoes,
      };
      console.log(updateAttribute);
      // alert("Produto não foi atualizado, isso é uma simulação")
      Attribute.updateAttribute(updateAttribute).then((response) => {
        response
          .json()
          .then(() => {
            if (response.status === 200) {
              this.created = true;
              this.color = "success";
              this.text = "Produto alterado com sucesso";
              this.y = "bottom";
              this.snackbar = true;
            }
          })
          .catch((error) => console.log("error", error));
      });
    },
    async delete(attributeID) {
      let attribute = {
        attributeID: attributeID,
      };

      Attribute.deleteAttribute(attribute).then((response) => {
        response
          .json()
          .then(() => {
            if (response.status === 200) {
              this.color = "success";
              this.text = "Produto excluído";
              this.y = "bottom";
              this.snackbar = true;
              this.getproducts();
            }
          })
          .catch((error) => console.log("error", error));
      });
    },
    createVariation() {
      if (this.attributetype === "Cor") {
        const newAttribute = {
          cor: this.variationtypeCor,
          name: this.variationName,
          slug: this.variationSlug.toLowerCase(),
          qtn: 0,
        };
        if (this.editIndex != null) {
          this.variacoes.splice(this.editIndex, 1, newAttribute);
        } else {
          this.variacoes.push(newAttribute);
        }
        this.editIndex = null;
        (this.variationtypeCor = ""),
          (this.variationName = ""),
          (this.variationSlug = "");
      } else if (this.attributetype === "Número") {
        const newAttribute = {
          name: this.variationName,
          qtn: 0,
        };
        if (this.editIndex != null) {
          this.variacoes.splice(this.editIndex, 1, newAttribute);
        } else {
          this.variacoes.push(newAttribute);
        }
        this.editIndex = null;
        this.variationName = "";
      } else {
        const newAttribute = {
          name: this.variationName,
          slug: this.variationSlug,
          qtn: 0,
        };
        if (this.editIndex != null) {
          this.variacoes.splice(this.editIndex, 1, newAttribute);
        } else {
          this.variacoes.push(newAttribute);
        }
        this.editIndex = null;
        this.variationName = "";
        this.variationSlug = "";
      }
    },
    editAttribute(item) {
      this.editIndex = this.variacoes.findIndex(
        (value) => value.name === item.name
      );
      console.log(this.editIndex);
      this.variationName = item.name;
      this.variationSlug = item.slug;
      this.variationtypeCor = item.cor;
    },
    getAttributes() {
      Attribute.getAttributes().then((response) => {
        response
          .json()
          .then((data) => {
            this.attribute = data;
          })
          .catch((error) => console.log("error", error));
      });
    },
  },
  created() {
    this.getAttributes();
    if (this.editItem) {
      this.attributeName = this.editItem.attributeName;
      this.attributetype = this.editItem.attributetype;
      this.variacoes = [...this.editItem.variations];
      // console.log(this.editItem.variations)

      this.e1 = 3;
    }
  },
  mounted() {},
};
</script>

<style>
.avatarBorder {
  border: 1px solid black !important;
}
.v-color-picker {
  max-width: 100% !important;
}
.v-color-picker__controls {
  flex-direction: row;
}
.v-color-picker__preview {
  width: 200px;
}
.v-color-picker__edit {
  width: 200px;
  margin-left: 24px;
}
</style>