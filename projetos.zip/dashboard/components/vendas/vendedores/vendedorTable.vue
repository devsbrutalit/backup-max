<template>
  <v-container fluid>
    <v-card>
      <v-card-title>Ranking de vendedores</v-card-title>
      <v-data-table
        v-model="selected"
        :headers="headers"
        :items="getAllSellers"
        class="elevation-1"
        hide-default-footer
      >
        <template v-slot:footer>
          <nuxt-link to="/vendas/meusVendedores/todosVendedores">
            <div class="text-center">
              <span>Ver todos</span>
            </div>
          </nuxt-link>
        </template>
      </v-data-table>
    </v-card>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import Cupon from "@/repositories/Cupon";
export default {
  computed: {
    ...mapGetters("seller", ["allSellers"]),
    getAllSellers() {
      console.log(this.allSellers);
      return this.allSellers;
    },
  },
  data() {
    return {
      search: "",
      selected: [],
      cupons: [],
      headers: [
        { text: "Vendedor", value: "name" },
        { text: "Vendas", value: "cuponCode" },
        { text: "Meta do mês", value: "cuponDiscount" },
        // { text: "Actions", value: "actions" },
      ],
    };
  },
  methods: {
    ...mapActions("seller", ["loadSellers"]),
    editStatus(item) {},
    getCupons() {
      Cupon.getCupons().then((response) => {
        response
          .json()
          .then((data) => {
            this.cupons = data;
          })
          .catch((error) => console.log("error", error));
      });
    },
  },
  created() {
    this.loadSellers();
  },
};
</script>

<style>
</style>