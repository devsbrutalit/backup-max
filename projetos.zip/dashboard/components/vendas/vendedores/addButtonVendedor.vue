<template>
  <v-container fluid>
    <v-hover v-slot="{ hover }">
      <v-card
        class="my-5 text-center black--text ml-auto"
        style="max-width: 350px"
        :class="{ 'on-hover': hover }"
        elevation="0"
        color="transparent"
      >
        <NuxtLink
          to="/vendas/vendedores/addVendedor"
          style="text-decoration: none; color: inherit"
        >
          <v-card-actions
            style="
              display: flex;
              align-content: center;
              justify-content: center;
            "
          >
            <v-icon
              size="40"
              color="black"
              class="mr-2"
              :class="{ 'on-hover-icon': hover }"
            >
              mdi-plus-circle-outline
            </v-icon>
            <span style="font-size: 1.5rem">Add vendedor</span>
          </v-card-actions>
        </NuxtLink>
      </v-card>
    </v-hover>
  </v-container>
</template>

<script>
export default {
}
</script>

<style scoped>
.on-hover {
  transition: background 0.5s;
  background: #41433e !important;
  color: #aef82d !important;
}

.on-hover-icon {
  color: #aef82d !important;
}
</style>