<template>
  <v-container>
    <v-card elevation="0" style="background-color: transparent">
      <v-card-title
        class="text-center headline black--text"
        style="display: block"
      >
        Cadastrar Vendedor
      </v-card-title>
      <v-card-subtitle class="text-center black--text" style="display: block"
        >Adicione aqui os dados necessários para cadastrar um novo vendedor.
      </v-card-subtitle>

      <v-card-text>
        <v-row>
          <!-- Coluna Nome -->
          <v-col cols="12" sm="6" md="4">
            <v-text-field
              class="mt-2"
              name="name"
              label="Nome Completo"
              v-model="createName"
              :error-messages="nameErrors"
              @input="$v.createName.$touch()"
              @blur="$v.createName.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo CPF -->
          <v-col cols="12" sm="6" md="4">
            <v-text-field
              name="cpf"
              v-mask="'###.###.###-##'"
              v-model="createCPF"
              class="mt-2"
              label="CPF"
              :error-messages="cpfErrors"
              @input="$v.createCPF.$touch()"
              @blur="$v.createCPF.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo RG -->
          <v-col cols="12" sm="6" md="4">
            <v-text-field
              name="rg"
              v-mask="'###.###.###-##'"
              v-model="createRG"
              class="mt-2"
              label="RG"
              :error-messages="cpfErrors"
              @input="$v.createCPF.$touch()"
              @blur="$v.createCPF.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo CEP -->
          <v-col cols="12" sm="3">
            <v-text-field
              name="cep"
              v-model="createCEP"
              v-mask="'#####-###'"
              label="CEP"
              :error-messages="cepErrors"
              @input="$v.createCEP.$touch()"
              @blur="
                $v.createCEP.$touch();
                GetAdress();
              "
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Cel -->
          <v-col cols="12" sm="5">
            <v-text-field
              name="cel"
              v-model="createCel"
              v-mask="'(##) #####-####'"
              label="Telefone Celular"
              :error-messages="celErrors"
              @input="$v.createCel.$touch()"
              @blur="$v.createCel.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Email -->
          <v-col cols="12" sm="4">
            <v-text-field
              name="email"
              v-model="createEmail"
              label="E-mail"
              :error-messages="emailErrors"
              @input="$v.createEmail.$touch()"
              @blur="$v.createEmail.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Endereço -->
          <v-col cols="12">
            <v-text-field
              name="endereco"
              v-model="createEndereco"
              label="Endereço"
              @input="$v.createEndereco.$touch()"
              @blur="$v.createEndereco.$touch()"
              readonly
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Numero -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="numero"
              v-model="createNumber"
              label="Número"
              :error-messages="numberErrors"
              @input="$v.createNumber.$touch()"
              @blur="$v.createNumber.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Complemento -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="complemento"
              v-model="createComplemento"
              label="Complemento"
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Bairro -->
          <v-col cols="12" sm="5">
            <v-text-field
              name="bairro"
              v-model="createBairro"
              label="Bairro"
              @input="$v.createBairro.$touch()"
              @blur="$v.createBairro.$touch()"
              readonly
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Cidade -->
          <v-col cols="12" sm="4">
            <v-text-field
              name="cidade"
              v-model="createCidade"
              label="Cidade"
              @input="$v.createCidade.$touch()"
              @blur="$v.createCidade.$touch()"
              readonly
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Estado -->
          <v-col cols="12" sm="3">
            <v-text-field
              name="estado"
              v-model="createEstado"
              label="Estado"
              @input="$v.createEstado.$touch()"
              @blur="$v.createEstado.$touch()"
              readonly
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Cargo -->
          <v-col cols="12" sm="9">
            <v-text-field
              name="cargo"
              v-model="createCargo"
              label="Cargo"
              outlined
            ></v-text-field>
          </v-col>

          <!-- ID -->
          <v-col cols="12" sm="3">
            <v-text-field
              name="id"
              v-model="createID"
              label="ID"
              outlined
            ></v-text-field>
          </v-col>

          <!-- Meta mensal padrãp -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="meta"
              v-model="createMeta"
              label="Ponto de Referencia"
              outlined
            ></v-text-field>
          </v-col>

          <!-- Unidade -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="unidade"
              v-model="createUnidade"
              label="Unidade"
              outlined
            ></v-text-field>
          </v-col>

          <!-- Dias de Trabalho -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="dayWork"
              v-model="createDayWork"
              label="Dias de trabalho"
              outlined
            ></v-text-field>
          </v-col>

          <!-- Horários de trabalho -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="horario"
              v-model="createHorario"
              label="Horários de trabalho"
              outlined
            ></v-text-field>
          </v-col>
        </v-row>
      </v-card-text>
      <v-card-actions>
        <v-container class="text-center">
          <v-btn
            color="white"
            width="45%"
            height="40px"
            class="mx-2 red--text"
            @click="backPage()"
          >
            Cancel
          </v-btn>
          <v-btn
            color="#41433e"
            style="color: #aef82d"
            width="45%"
            height="40px"
            class="mx-2"
            @click="submit()"
          >
            Cadastrar vendedor
          </v-btn>
        </v-container>
      </v-card-actions>
    </v-card>
  </v-container>
</template>

<script>
import { required, maxLength, email } from "vuelidate/lib/validators";
import Seller from "@/repositories/Seller";
export default {
  validations: {
    createEmail: { required, email },
    createName: { required },
    createCPF: { required, maxLength: maxLength(14) },
    createDate: { required },
    createCEP: { required },
    createEndereco: { required },
    createNumber: { required },
    createBairro: { required },
    createCidade: { required },
    createEstado: { required },
    createCel: { required },
  },
  data() {
    return {
      createName: "",
      createCPF: "",
      createRG: "",
      createCEP: "",
      createCel: "",
      createEmail: "",
      createEndereco: "",
      createNumber: "",
      createComplemento: "",
      createBairro: "",
      createCidade: "",
      createEstado: "",
      createCargo: "",
      createID: "",
      createMeta: "",
      createUnidade: "",
      createDayWork: "",
      createHorario: "",
      dialog: false,
      category: [],
    };
  },
  methods: {
    GetAdress() {
      fetch("https://viacep.com.br/ws/" + this.createCEP + "/json/").then(
        (response) => {
          response
            .json()
            .then((data) => {
              console.log(data);
              this.createBairro = data.bairro;
              this.createEndereco = data.logradouro;
              this.createCidade = data.localidade;
              this.createEstado = data.uf;
            })
            .catch((error) => console.log("error", error));
        }
      );
    },
    validarCPF(createCPF) {
      createCPF = createCPF.replace(/[^\d]+/g, "");
      if (createCPF == "") return false;
      // Elimina CPFs invalidos conhecidos
      if (
        createCPF.length != 11 ||
        createCPF == "00000000000" ||
        createCPF == "11111111111" ||
        createCPF == "22222222222" ||
        createCPF == "33333333333" ||
        createCPF == "44444444444" ||
        createCPF == "55555555555" ||
        createCPF == "66666666666" ||
        createCPF == "77777777777" ||
        createCPF == "88888888888" ||
        createCPF == "99999999999"
      )
        return false;
      // Valida 1o digito
      var add = 0;
      for (var i = 0; i < 9; i++)
        add += parseInt(createCPF.charAt(i)) * (10 - i);
      var rev = 11 - (add % 11);
      if (rev == 10 || rev == 11) rev = 0;
      if (rev != parseInt(createCPF.charAt(9))) return false;
      // Valida 2o digito
      add = 0;
      for (i = 0; i < 10; i++) add += parseInt(createCPF.charAt(i)) * (11 - i);
      rev = 11 - (add % 11);
      if (rev == 10 || rev == 11) rev = 0;
      if (rev != parseInt(createCPF.charAt(10))) return false;
      return true;
    },
    backPage() {
      this.$router.push("/vendas/vendedores");
    },
    async submit() {
      const newSeller = {
        createName: this.createName,
        createCPF: this.createCPF,
        createRG: this.createRG,
        createCEP: this.createCEP,
        createCel: this.createCel,
        createEmail: this.createEmail,
        createEndereco: this.createEndereco,
        createNumber: this.createNumber,
        createComplemento: this.createComplemento,
        createBairro: this.createBairro,
        createCidade: this.createCidade,
        createEstado: this.createEstado,
        createCargo: this.createCargo,
        createID: this.createID,
        createMeta: this.createMeta,
        createUnidade: this.createUnidade,
        createDayWork: this.createDayWork,
        createHorario: this.createHorario,
        createCuponSeller: "TESTE",
      };

      console.log(newSeller);

      Seller.createSeller(newSeller).then((response) => {
        response
          .json()
          .then((data) => {
            console.log(data);
            setTimeout(() => {
              this.$router.push("/vendas/vendedores");
            }, 1500);
          })
          .catch((error) => console.log("error", error));
      });
    },
  },
  computed: {
    emailErrors() {
      const errors = [];
      if (!this.$v.createEmail.$dirty) return errors;
      !this.$v.createEmail.email && errors.push("E-mail deve ser valido");
      !this.$v.createEmail.required && errors.push("Campo obrigatório");
      return errors;
    },
    nameErrors() {
      const errors = [];
      if (!this.$v.createName.$dirty) return errors;
      !this.$v.createName.required && errors.push("Insira um nome");
      return errors;
    },
    cpfErrors() {
      const errors = [];
      if (!this.$v.createCPF.$dirty) return errors;
      !this.$v.createCPF.required && errors.push("Campo obrigatório");
      !this.validarCPF(this.createCPF) && errors.push("CPF deve ser valido");
      return errors;
    },
    dateErrors() {
      const errors = [];
      if (!this.$v.createDate.$dirty) return errors;
      !this.$v.createDate.required && errors.push("Campo obrigatório");
      return errors;
    },
    passwordErrors() {
      const errors = [];
      if (!this.$v.createPassword.$dirty) return errors;
      !this.$v.createPassword.minLength &&
        errors.push("A senha deve conter no minimo 12 caracteres");
      !this.$v.createPassword.required && errors.push("Campo obrigatório");
      return errors;
    },
    cepErrors() {
      const errors = [];
      if (!this.$v.createCEP.$dirty) return errors;
      !this.$v.createCEP.required && errors.push("Campo obrigatório");
      return errors;
    },
    enderecoErrors() {
      const errors = [];
      if (!this.$v.createEndereco.$dirty) return errors;
      !this.$v.createEndereco.required && errors.push("Campo obrigatório");
      return errors;
    },
    numberErrors() {
      const errors = [];
      if (!this.$v.createNumber.$dirty) return errors;
      !this.$v.createNumber.required && errors.push("Campo obrigatório");
      return errors;
    },
    bairroErrors() {
      const errors = [];
      if (!this.$v.createBairro.$dirty) return errors;
      !this.$v.createBairro.required && errors.push("Campo obrigatório");
      return errors;
    },
    cidadeErrors() {
      const errors = [];
      if (!this.$v.createCidade.$dirty) return errors;
      !this.$v.createCidade.required && errors.push("Campo obrigatório");
      return errors;
    },
    estadoErrors() {
      const errors = [];
      if (!this.$v.createEstado.$dirty) return errors;
      !this.$v.createEstado.required && errors.push("Campo obrigatório");
      return errors;
    },
    celErrors() {
      const errors = [];
      if (!this.$v.createCel.$dirty) return errors;
      !this.$v.createCel.required && errors.push("Campo obrigatório");
      return errors;
    },
    acceptTermErrors() {
      const errors = [];
      if (!this.$v.acceptTerm.$dirty) return errors;
      !this.$v.acceptTerm.checked &&
        errors.push("Você deve aceitar para continuar!");
      return errors;
    },
  },
};
</script>

<style>
</style>