<template>
  <v-container fluid>
    <v-card class="px-5 py-3">
      <v-card-title class="pb-0">Total vendido</v-card-title>
      <v-list-item>
        <v-list-item-content class="px-2">
          <v-list-item-title class="font-weight-bold" style="font-size: 20px"
            >R$ {{ totalSold }}</v-list-item-title
          >
        </v-list-item-content>
        <v-list-item-avatar tile>
          <v-icon large>mdi-calendar-today</v-icon>
        </v-list-item-avatar>
      </v-list-item>
    </v-card>

    <v-card class="px-5 py-3 my-5">
      <v-card-title class="pb-0">Qtd de produtos</v-card-title>
      <v-list-item>
        <v-list-item-content class="px-2">
          <v-list-item-title class="font-weight-bold" style="font-size: 20px">{{
            totalItens
          }}</v-list-item-title>
        </v-list-item-content>
        <v-list-item-avatar tile>
          <v-icon large>mdi-calendar-today</v-icon>
        </v-list-item-avatar>
      </v-list-item>
    </v-card>

    <v-card class="px-5 py-3">
      <v-card-title class="pb-0">Qtd de pedidos</v-card-title>
      <v-list-item>
        <v-list-item-content class="px-2">
          <v-list-item-title class="font-weight-bold" style="font-size: 20px">{{
            totalOrders
          }}</v-list-item-title>
        </v-list-item-content>
        <v-list-item-avatar tile>
          <v-icon large>mdi-calendar-today</v-icon>
        </v-list-item-avatar>
      </v-list-item>
    </v-card>

    <v-card class="px-5 py-3 mt-5">
      <v-list-item two-line>
        <v-list-item-content style="max-width: 100px">
          <v-sparkline
            :fill="fill"
            :line-width="width"
            :color="color"
            :padding="padding"
            :smooth="radius || false"
            :value="value"
            auto-draw
          ></v-sparkline>
        </v-list-item-content>
        <v-list-item-content class="text-right">
          <v-list-item-subtitle
            >Em relação ao dia anterior</v-list-item-subtitle
          >
          <v-list-item-title
            class="font-weight-bold red--text"
            style="font-size: 20px"
            >-82,6% <v-icon color="red">mdi-arrow-down</v-icon>
          </v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-card>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
export default {
  computed: {
    ...mapGetters("orders", ["allorders"]),
    totalSold() {
      this.order = Object.assign(this.allorders);

      var newDate = new Date();
      let today = newDate.toISOString().slice(0, 10);

      var total = 0;
      this.order.map((item) => {
        if (item.createdAt.slice(0, 10) === today) {
          item.products.map((object) => {
            total += object.productValueDiscount;
          });
        }
      });
      return total;
    },
    totalItens() {
      this.order = Object.assign(this.allorders);

      var newDate = new Date();
      let today = newDate.toISOString().slice(0, 10);

      var itensTotal = 0;
      this.order.map((item) => {
        if (item.createdAt.slice(0, 10) === today) {
          item.products.map((object) => {
            itensTotal += 1;
          });
        }
      });
      return itensTotal;
    },
    totalOrders() {
      this.order = Object.assign(this.allorders);

      var newDate = new Date();
      let today = newDate.toISOString().slice(0, 10);

      var total = 0;
      this.order.map((item) => {
        if (item.createdAt.slice(0, 10) === today) {
          total += 1;
        }
      });
      return total;
    },
  },
  data() {
    return {
      fill: false,
      padding: 8,
      color: "red",
      radius: 10,
      value: [0, 2, 5, 9, 5, 10, 3, 5, 0],
      width: 8,
    };
  },
};
</script>

<style>
</style>