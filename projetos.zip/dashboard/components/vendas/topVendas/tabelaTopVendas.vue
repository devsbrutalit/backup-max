<template>
  <div>
    <v-data-table :headers="headers" :items="getAllOrders" class="elevation-1">
      <template v-slot:[`item.productName`]="{ item }">
        <v-list-item>
          <v-list-item-avatar tile height="100%" size="50" class="mr-3 my-3">
            <v-img
              max-width="80"
              class="my-2 ma-auto"
              :src="item.productPicture[0]"
            ></v-img>
          </v-list-item-avatar>
          <v-list-item-content>
            <v-list-item-title style="max-width:200px"> {{ item.productName }} </v-list-item-title>
            <v-list-item-subtitle>{{ item.productCtg }}</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </template>

      <template v-slot:[`item.productValue`]="{ item }">
        <span>{{
          new Intl.NumberFormat("pt-BR", {
            style: "currency",
            currency: "BRL",
          }).format(item.productValue)
        }}</span>
      </template>

      <template v-slot:[`item.vendasSoma`]="{ item }">
        <span>{{
          new Intl.NumberFormat("pt-BR", {
            style: "currency",
            currency: "BRL",
          }).format(item.vendasSoma)
        }}</span>
      </template>

      <!-- <template v-slot:[`item.action`]="{ item }">
        <v-icon @click="setItem(item.pkOrder)">mdi-eye</v-icon>
      </template> -->
    </v-data-table>

    <!-- <v-dialog v-model="detailVenda" max-width="50%">
      <VendaDetails
        :orderDetail="orderDetail"
        :showModal="detailVenda"
        @close="closeModal"
      />
    </v-dialog> -->
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import VendaDetails from "./vendaDetailsDaily";
export default {
  components: {
    VendaDetails,
  },
  computed: {
    ...mapGetters("orders", ["allorders"]),
    ...mapGetters("products", ["allproducts"]),
    getAllOrders() {
      this.order = Object.assign(this.allorders);
      var orderItens = [];
      this.order.map((item) => {
        item.products.map((object) => {
          object.methodPay = item.methodPay;
          object.seller = item.seller;
          object.cupom = item.cupom;
          object.payDate = item.createdAt;
          orderItens.push(object);
        });
      });

      const groups = orderItens.reduce(
        (groups, item) => ({
          ...groups,
          [item.productName]: [...(groups[item.productName] || []), item],
        }),
        {}
      );
      console.log(groups)

      var TopItensList = [];
      var newObjectItem = {};
      var totalVendas = 0;
      var ultimaVenda = "";
      for (var prop in groups) {
        groups[prop].map((item) => {
          newObjectItem.pk = item.pk;
          newObjectItem.productName = item.productName;
          newObjectItem.productCtg = item.productCtg;
          newObjectItem.productPicture = item.productPicture || item.productVarImg;
          newObjectItem.productValue = item.productValueDiscount;
          newObjectItem.vendasCupom = 0;
          totalVendas += item.Qtn;
          if(item.payDate > ultimaVenda) ultimaVenda = item.payDate;
        });
        newObjectItem.ultimaVenda = new Date(ultimaVenda).toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });
        newObjectItem.vendasQtd = totalVendas;
        newObjectItem.vendasSoma = (
          newObjectItem.vendasQtd * newObjectItem.productValue
        ).toFixed(2);
        TopItensList.push(newObjectItem);
        totalVendas = 0;
        newObjectItem = {};
        ultimaVenda = "";
      }
      return TopItensList;
    },
  },

  data() {
    return {
      orderDetail: [],
      detailVenda: false,
      order: [],
      headers: [
        { text: "Produto", value: "productName" },
        { text: "Valor", value: "productValue" },
        { text: "Vendas", value: "vendasQtd" },
        { text: "Soma", value: "vendasSoma" },
        { text: "Cupom", value: "vendasCupom" },
        { text: "Ultima Vendas", value: "ultimaVenda" },
        { text: "Status", value: "status" },
        // { text: "Action", value: "action" },
      ],
    };
  },
  methods: {
    ...mapActions("orders", ["loadOrders"]),
    ...mapActions("products", ["loadProducts"]),
    setItem(value) {
      this.detailVenda = true;
      this.order.find((item) => {
        if (value === item.pk) {
          this.orderDetail = item;
        }
      });
      // console.log(item);
      // console.log(this.order)
      // this.orderDetail = item;
    },
    closeModal(value) {
      this.detailVenda = value;
    },
  },
  created() {
    this.loadOrders();
    this.loadProducts();
  },
};
</script>

<style>
</style>