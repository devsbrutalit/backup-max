<template>
  <v-card>
    <div style="position: absolute; right: 2%; top: 10px">
      <v-btn icon @click="closeModal">
        <v-icon>mdi-close</v-icon>
      </v-btn>
    </div>
    <v-card-title> Detalhes do Pedido</v-card-title>
    <v-divider></v-divider>
    <v-list-item class="text-left">
      <v-list-item-content>
        <v-list-item-title>Status: {{ setStatus() }}</v-list-item-title>
        <v-list-item-title>
          Código da transação:
          {{ orderDetail.orderDetails.code._text }}
        </v-list-item-title>
        <v-list-item-title
          >Total: R$
          {{ orderDetail.orderDetails.grossAmount._text }}
        </v-list-item-title>
        <v-list-item-title
          >Meio de pagamento: <span v-html="setMeioPagamento()"></span
        ></v-list-item-title>
        <v-list-item-title v-if="orderDetail.trackCode">
          Código de rastreamento: {{ orderDetail.trackCode }}
        </v-list-item-title>
      </v-list-item-content>
    </v-list-item>
    <div class="text-center">
      <v-text-field
        label="Insira aqui o código do rastreio"
        v-model="newTrackCode"
        class="mx-5"
        solo
      >
      </v-text-field>
      <v-btn
        width="300"
        color="blue"
        class="white--text mb-4"
        :loading="loadingBtn"
        :disabled="newTrackCode.length === 0"
        @click="trackCodeATT()"
        >Atualizar</v-btn
      >
    </div>

    <v-divider></v-divider>

    <div class="text-center">
      <v-progress-circular
        v-if="orderDetail.trackCode"
        indeterminate
        color="primary"
        v-show="show"
      ></v-progress-circular>
    </div>

    <v-row
      v-if="objetoRastreio.length === 0"
      v-show="showMSG"
      align="center"
      justify="center"
      no-gutters
    >
      <v-icon large>mdi-barcode</v-icon
      ><span class="ml-2" style="font-size: 19px">
        Código de Rastreio não encontrado ou incorreto
      </span>
    </v-row>

    <v-row
      v-if="!orderDetail.trackCode"
      align="center"
      justify="center"
      no-gutters
    >
      <v-icon large>mdi-barcode</v-icon
      ><span class="ml-2" style="font-size: 19px">
        Código de Rastreio ainda não disponivel
      </span>
    </v-row>

    <v-timeline
      v-if="objetoRastreio.length > 0 && orderDetail.trackCode"
      align-top
      dense
    >
      <v-timeline-item
        v-for="item in objetoRastreio"
        :key="item.status"
        color="blue"
        class="text-left"
        small
      >
        <strong>{{ item.status }}</strong>
        <div class="caption">{{ item.local }}</div>
        <div class="caption" v-if="item.origem">Origem: {{ item.origem }}</div>
        <div class="caption" v-if="item.destino">
          Destino: {{ item.destino }}
        </div>
        <div class="caption">{{ item.data }}</div>
        <div class="caption">{{ item.hora }}</div>
      </v-timeline-item>
    </v-timeline>

    <v-divider></v-divider>

    <v-card-title style="font-size: 17px" class="pl-4">
      <strong>Produtos</strong>
    </v-card-title>
    <v-row no-gutters>
      <v-col v-for="item in orderDetail.products" :key="item.productName">
        <v-list-item class="text-left">
          <v-list-item-content>
            <v-list-item-title
              >Nome:
              {{ item.productName }}
            </v-list-item-title>
            <v-list-item-title
              >Quantidade:
              {{ item.Qtn }}
            </v-list-item-title>
            <v-list-item-title
              >Valor: R$
              {{ item.productValue }}
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-col>
    </v-row>
    <v-list-item-title class="text-left pl-4"
      >Frete:
      <strong
        >R$
        {{ orderDetail.orderDetails.shipping.cost._text }}
      </strong></v-list-item-title
    >
    <v-list-item-title class="text-left pl-4"
      >Total da Compra:
      <strong
        >R$
        {{ orderDetail.orderDetails.grossAmount._text }}
      </strong></v-list-item-title
    >
    <v-divider></v-divider>

    <v-card-title style="font-size: 17px" class="pl-4">
      <strong>Endereço para entrega</strong>
    </v-card-title>
    <v-row no-gutters>
      <v-col>
        <v-list-item class="text-left">
          <v-list-item-content>
            <v-list-item-title
              >Endereço:
              {{ orderDetail.orderDetails.shipping.address.street._text }}
            </v-list-item-title>
            <v-list-item-title
              >Número:
              {{ orderDetail.orderDetails.shipping.address.number._text }}
            </v-list-item-title>
            <v-list-item-title
              v-if="orderDetail.orderDetails.shipping.address.complement._text"
              >Complemento:
              {{ orderDetail.orderDetails.shipping.address.complement._text }}
            </v-list-item-title>
            <v-list-item-title>
              Bairro:
              {{ orderDetail.orderDetails.shipping.address.district._text }}
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-col>
      <v-col>
        <v-list-item class="text-left">
          <v-list-item-content>
            <v-list-item-title
              >Estado:
              {{ orderDetail.orderDetails.shipping.address.state._text }}
            </v-list-item-title>
            <v-list-item-title
              >Cidade:
              {{ orderDetail.orderDetails.shipping.address.city._text }}
            </v-list-item-title>
            <v-list-item-title
              >CEP:
              {{ orderDetail.orderDetails.shipping.address.postalCode._text }}
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-col>
    </v-row>

    <v-divider></v-divider>

    <!-- <v-list-item>
      <v-list-item-content>
        <v-list-item-title>Produtos</v-list-item-title>
      </v-list-item-content>
    </v-list-item>
    <v-list-item three-line>
      <v-list-item-avatar tile height="100%" size="50" class="mr-3 my-3">
        <v-img
          max-width="80"
          class="my-2 ma-auto"
          :src="orderDetail.productPicture[0]"
        ></v-img>
      </v-list-item-avatar>
      <v-list-item-content>
        <v-list-item-title> {{ orderDetail.productName }} </v-list-item-title>
        <v-list-item-subtitle> {{ orderDetail.productCtg }} </v-list-item-subtitle>
        <v-list-item-subtitle> {{ orderDetail.Qtn }} unidade </v-list-item-subtitle>
      </v-list-item-content>
    </v-list-item> -->
  </v-card>
</template>

<script>
import Pedido from "@/repositories/Orders";
export default {
  props: {
    orderDetail: Object,
  },
  data() {
    return {
      objetoRastreio: [],
      show: false,
      showMSG: false,
      loadingBtn: false,
      newTrackCode: "",
    };
  },
  watch: {
    orderDetail: function () {
      this.show = true;
      this.showMSG = false;
      this.objetoRastreio = [];
      this.rastrearPedido();
    },
  },
  // computed: {
  //   orderLocation: {
  //     get() {
  //       this.rastrearPedido();
  //       return this.$store.state.orderLocation;
  //     },
  //     set(value) {
  //       this.$store.commit("SET_LOCATION_PEDIDO", value);
  //     },
  //   },
  // },
  methods: {
    trackCodeATT() {
      this.loadingBtn = true;
      const Code = {
        orderId: this.orderDetail.pk,
        trackCode: this.newTrackCode,
      };
      Pedido.attTrackCode(Code).then((response) => {
        response
          .json()
          .then(() => {
            location.reload();
            this.loadingBtn = false;
          })
          .catch((error) => console.log("error", error));
      });
    },
    setMeioPagamento() {
      var paymentType = "";
      if (this.orderDetail.orderDetails.paymentMethod.type._text === "1") {
        paymentType = "Cartão de crédito";
      } else if (
        this.orderDetail.orderDetails.paymentMethod.type._text === "2"
      ) {
        paymentType =
          "<a href=" +
          this.orderDetail.orderDetails.paymentLink._text +
          ">Boleto</a>";
      }
      return paymentType;
    },
    setStatus() {
      var statusValue = "";
      if (this.orderDetail.orderDetails.status._text === "1") {
        statusValue = "Aguardando Pagamento";
      } else if (this.orderDetail.orderDetails.status._text === "2") {
        statusValue = "Em análise";
      } else if (this.orderDetail.orderDetails.status._text === "3") {
        statusValue = "Paga";
      } else if (this.orderDetail.orderDetails.status._text === "4") {
        statusValue = "Disponível";
      } else if (this.orderDetail.orderDetails.status._text === "5") {
        statusValue = "Em disputa";
      } else if (this.orderDetail.orderDetails.status._text === "6") {
        statusValue = "Devolvida";
      } else {
        statusValue = "Cancelada";
      }
      return statusValue;
    },
    rastrearPedido() {
      const Code = {
        trackCode: this.orderDetail.trackCode,
      };
      Pedido.localizarPedido(Code).then((response) => {
        response
          .json()
          .then((data) => {
            this.show = false;
            this.showMSG = true;
            this.objetoRastreio = data[0];
          })
          .catch((error) => console.log("error", error));
      });
    },
    closeModal() {
      this.$emit("close", false);
    },
  },
  created() {
    this.show = true;
    this.rastrearPedido();
  },
};
</script>

<style>
</style>