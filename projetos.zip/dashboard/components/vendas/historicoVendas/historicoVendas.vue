<template>
  <div>
    <v-data-table
      :headers="headers"
      :items="getAllOrders"
      class="elevation-1"
      hide-default-footer
    >
      <template v-slot:[`item.productName`]="{ item }">
        <v-list-item>
          <v-list-item-avatar tile height="100%" size="50" class="mr-3 my-3">
            <v-img
              max-width="80"
              class="my-2 ma-auto"
              :src="
                item.productVarImg
                  ? item.productVarImg[0]
                  : item.productPicture
                  ? item.productPicture[0]
                  : ''
              "
            ></v-img>
          </v-list-item-avatar>
          <v-list-item-content>
            <v-list-item-title> {{ item.productName }} </v-list-item-title>
            <v-list-item-subtitle>{{ item.productCtg }}</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </template>

      <template v-slot:[`item.action`]="{ item }">
        <v-icon @click="setItem(item.pkOrder)">mdi-eye</v-icon>
      </template>
    </v-data-table>

    <v-dialog v-model="detailVenda" max-width="50%">
      <VendaDetails :orderDetail="orderDetail" @close="closeModal" />
    </v-dialog>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import VendaDetails from "./vendaDetails";
export default {
  components: {
    VendaDetails,
  },
  computed: {
    ...mapGetters("orders", ["allorders"]),
    getAllOrders() {
      console.log(this.allorders)
      this.order = Object.assign(this.allorders);
      var orderItens = [];
      this.order.map((item) => {
        item.products.map((object) => {
          object.pkOrder = item.pk;
          object.userpkOrder = item.user;
          object.methodPay = item.methodPay;
          object.seller = item.seller;
          object.cupom = item.cupom;
          object.status = item.status;
          object.orderCreatedAt = item.createdAt;
          orderItens.push(object);
        });
      });
      return orderItens;
    },
  },
  data() {
    return {
      orderDetail: [],
      detailVenda: false,
      order: [],
      headers: [
        { text: "Produto", value: "productName" },
        { text: "Valor", value: "productValue" },
        { text: "ID Cliente", value: "userpkOrder" },
        { text: "Pedido", value: "pkOrder" },
        { text: "Método de pagamento", value: "methodPay" },
        { text: "Cupom", value: "cupom" },
        { text: "Vendedor", value: "seller" },
        { text: "CEP", value: "cep" },
        { text: "Frete", value: "frete" },
        { text: "Data", value: "orderCreatedAt" },
        { text: "Status", value: "status" },
        { text: "Action", value: "action" },
      ],
    };
  },
  methods: {
    ...mapActions("orders", ["loadOrders"]),
    setItem(value) {
      this.detailVenda = true;
      this.order.find((item) => {
        if (value === item.pk) {
          this.orderDetail = item;
        }
      });
    },
    closeModal(value) {
      this.detailVenda = value;
    },
  },
  created() {
    this.loadOrders();
  },
};
</script>

<style>
</style>