<template>
  <v-container>
    <v-card elevation="0" style="height: 100%" color="transparent">
      <v-card-title style="display: block" class="text-center">
        <span class="headline">Add cupom</span>
      </v-card-title>
      <v-card-text>
        <v-container>
          <p>Adicione aqui os dados necessários para a criação do cupom.</p>

          <v-card class="px-5" tile color="transparent" elevation="0">
            <div class="pt-3">Nome da campanha</div>
            <v-text-field
              v-model="cuponName"
              label="Nome Cupom"
              solo
              required
            ></v-text-field>
            <div>Código do cupom</div>
            <v-text-field
              v-model="cuponCode"
              label="Código do cupom"
              solo
              required
            ></v-text-field>
            <!-- Desconto Produto -->

            <v-row no-gutters>
              <span class="mr-5">Desconto</span>
              %
              <v-switch
                v-model="switchDiscount"
                true-value="$"
                false-value="%"
                class="pt-0 mt-0 ml-2 mr-n2"
                inset
              ></v-switch>

              <!-- @change="applyDiscount()" -->
              R$
            </v-row>
            <!-- @change="applyDiscount" -->
            <v-text-field
              v-model="cuponDiscount"
              label="Desconto"
              solo
              required
            ></v-text-field>
            <div>Cupom privado ?</div>
            <v-checkbox color="purple" v-model="cupomPrivate"></v-checkbox>
            <div>Quantidade</div>
            <v-text-field
              v-model="cuponQtd"
              label="Quantidade"
              solo
              required
            ></v-text-field>

            <v-dialog
              ref="dialog1"
              v-model="dateModal"
              :return-value.sync="date"
              persistent
              width="290px"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="date"
                  label="Data de Validade"
                  prepend-icon="mdi-calendar"
                  color="purple"
                  readonly
                  solo
                  v-bind="attrs"
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="date"
                :min="new Date().toISOString().substr(0, 10)"
                scrollable
              >
                <v-spacer></v-spacer>
                <v-btn text color="primary" @click="dateModal = false">
                  Cancel
                </v-btn>
                <v-btn text color="primary" @click="$refs.dialog1.save(date)">
                  OK
                </v-btn>
              </v-date-picker>
            </v-dialog>

            <v-dialog
              ref="dialog"
              v-model="timeModal"
              :return-value.sync="time"
              persistent
              width="290px"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="time"
                  label="Hora de Validade"
                  prepend-icon="mdi-clock-time-four-outline"
                  color="purple"
                  solo
                  readonly
                  v-bind="attrs"
                  v-on="on"
                ></v-text-field>
              </template>
              <v-time-picker v-if="timeModal" v-model="time" full-width>
                <v-spacer></v-spacer>
                <v-btn text color="primary" @click="timeModal = false">
                  Cancel
                </v-btn>
                <v-btn text color="primary" @click="$refs.dialog.save(time)">
                  OK
                </v-btn>
              </v-time-picker>
            </v-dialog>
          </v-card>
        </v-container>
      </v-card-text>
      <v-card-actions>
        <v-container class="text-center">
          <v-btn
            color="white"
            height="40px"
            class="mx-2 red--text"
            @click="closeModal"
          >
            Cancel
          </v-btn>
          <v-btn
            color="#41433e"
            style="color: #aef82d"
            height="40px"
            class="mx-2"
            @click="submit()"
          >
            Criar cupom
          </v-btn>
        </v-container>
      </v-card-actions>
    </v-card>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import Cupon from "@/repositories/Cupon";
export default {
  props: {
    value: Boolean,
  },
  computed: {
    ...mapGetters("categories", ["allcategories"]),
    filterCategory() {
      const itens = [{ categoryName: "Qualquer categoria" }];
      this.allcategories.find((item) => {
        if (item.categoryType === "categoria") {
          itens.push(item);
        }
      });
      return itens;
    },
  },
  data() {
    return {
      cuponName: "",
      cuponCode: "",
      cupomPrivate: false,
      switchDiscount: "%",
      cuponDiscount: "",
      cuponCategory: "",
      cuponQtd: "",
      dialog: false,
      dateModal: false,
      date: "",
      timeModal: false,
      time: "",
    };
  },
  methods: {
    ...mapActions("cupons", ["loadCupons"]),
    applyDiscount() {
      if (this.switchDiscount === "$") {
        var newValue = this.cuponDiscount.split(" ");
        newValue.splice(1, 1);
        this.cuponDiscount = "R$ " + newValue;
      } else {
        var newValue = this.cuponDiscount.split(" ");
        newValue.map((item) => {
          if (item === "R$") newValue.splice(0, 1);
        });
        this.cuponDiscount = newValue + " %";
      }
    },
    async submit() {
      const newCupon = {
        cuponName: this.cuponName,
        cuponCode: this.cuponCode,
        cupomPrivate: this.cupomPrivate,
        cuponDiscount:
          this.switchDiscount === "$"
            ? (this.cuponDiscount = "R$ " + this.cuponDiscount)
            : this.cuponDiscount + "%",
        cuponCategory: this.cuponCategory,
        cuponQtd: this.cuponQtd,
        cuponExp: this.date + "T" + (this.time ? this.time : ""),
      };
      // console.log(newCupon);
      Cupon.createCupon(newCupon).then((response) => {
        response
          .json()
          .then(() => {
            setTimeout(() => {
              this.$router.push("/vendas/Cupons");
            }, 1500);
          })
          .catch((error) => console.log("error", error));
      });
    },
    closeModal() {
      this.$forceUpdate();
      this.show = false;
      this.cuponName = "";
      this.cuponCode = "";
      this.cuponID = "";
      this.cuponDiscount = "";
      this.cuponCategory = "";
      this.cuponQtd = "";
      this.date = "";
      this.time = "";
    },
  },
};
</script>

<style>
</style>