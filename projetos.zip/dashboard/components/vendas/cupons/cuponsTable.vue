<template>
  <v-container fluid>
    <!-- Campo de pesquisa -->
    <v-text-field
      v-model="search"
      append-icon="mdi-magnify"
      label="Ex: Procurar por nome"
      style="max-width: 300px"
      class="mb-2"
      single-line
      hide-details
    ></v-text-field>
    <v-select
      v-model="search"
      :items="['Ativo', 'Revogado', 'Desativado']"
      style="max-width: 300px"
      label="Status"
      solo
      clearable
    ></v-select>
    <v-data-table
      v-model="selected"
      :headers="headers"
      :items="getAllCupons"
      item-key="cuponName"
      :search="search"
      class="elevation-1"
    >
      <template v-slot:[`item.actions`]="{ item }">
        <v-icon @click="openEditStatusModal(item)" color="#77E164">
          mdi-pencil-circle
        </v-icon>
        <v-icon @click="confirmDeleteCupom(item)" color="red">
          mdi-delete
        </v-icon>
      </template>
    </v-data-table>

    <v-dialog v-model="cupomStatusModal" width="500">
      <v-card>
        <v-card-title>Status do Cupom</v-card-title>

        <v-card-text>
          <v-select
            color="green"
            v-model="status"
            :items="statusOptions"
            label="Status"
          ></v-select>
        </v-card-text>

        <v-divider></v-divider>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="#77E164" class="text-none" text @click="editStatus()">
            Mudar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <!-- Modal para confirmação de deleção de cupom -->
    <v-dialog v-model="confirmDelete" max-width="400" @keydown.esc="cancel">
      <v-card>
        <v-toolbar dark color="grey lighten-3" dense flat>
          <v-toolbar-title class="text-body-1 font-weight-bold black--text">
            Confirmação para deleção de Cupom
          </v-toolbar-title>
        </v-toolbar>
        <v-card-text class="pa-4 black--text">
          Realmente deseja deletar o cupom ?
        </v-card-text>
        <v-card-actions class="pt-3">
          <v-spacer></v-spacer>
          <v-btn
            color="grey"
            text
            class="body-2 font-weight-bold"
            @click.native="confirmDelete = false"
            >Cancel</v-btn
          >
          <v-btn
            color="purple"
            class="body-2 font-weight-bold"
            outlined
            @click.native="deleteCupom()"
            >Deletar</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import Cupon from "@/repositories/Cupon";
export default {
  computed: {
    ...mapGetters("cupons", ["allCupons"]),
    getAllCupons() {
      return this.allCupons;
    },
  },
  data() {
    return {
      search: "",
      selected: [],
      cupons: [],
      status: "",
      cupomId: "",
      confirmDelete: false,
      cupomStatusModal: false,
      statusOptions: [],
      headers: [
        { text: "Nome da Campanha", value: "cuponName" },
        { text: "Código do cupom", value: "cuponCode" },
        { text: "Desconto", value: "cuponDiscount" },
        { text: "Cupons disponíveis", value: "cuponQtd" },
        { text: "Data de validade", value: "cuponExp" },
        { text: "Status", value: "cuponStatus" },
        { text: "Actions", value: "actions" },
      ],
    };
  },
  methods: {
    ...mapActions("cupons", ["loadCupons"]),
    openEditStatusModal(item) {
      this.status = item.cuponStatus;
      this.cupomId = item.pk;
      this.cupomStatusModal = true;

      const today = new Date();
      const date = new Date(item.cuponExp);

      if (today > date) {
        this.statusOptions = ['Revogado', 'Desativado'];
      } else {
        this.statusOptions = ['Ativo', 'Revogado', 'Desativado'];
      }
    },
    confirmDeleteCupom(item) {
      this.cupomId = item.pk;
      this.confirmDelete = true;
    },
    validationDate(item) {
      const today = new Date();
      const date = new Date(item);

      if (today > date) {
        return true;
      } else {
        return false;
      }
    },
    editStatus() {
      const newStatus = {
        cupomId: this.cupomId,
        newStatus: this.status,
      };
      Cupon.changeStatusCupom(newStatus)
        .then(() => {
          this.loadCupons();
          this.cupomStatusModal = false;
        })
        .catch((error) => console.log("error", error));
    },
    getCupons() {
      Cupon.getCupons().then((response) => {
        response
          .json()
          .then((data) => {
            this.cupons = data;
            console.log(data);
          })
          .catch((error) => console.log("error", error));
      });
    },
    deleteCupom() {
      const Cupom = {
        cupomId: this.cupomId,
      };
      Cupon.deleteCupom(Cupom).then((response) => {
        response
          .json()
          .then((data) => {
            console.log(data);
            this.confirmDelete = false;
            this.loadCupons();
          })
          .catch((error) => console.log("error", error));
      });
    },
  },
  mounted() {
    this.loadCupons();
  },
};
</script>

<style>
</style>