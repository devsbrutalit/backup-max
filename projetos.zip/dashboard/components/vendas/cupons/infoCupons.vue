<template>
  <v-container fluid>
    <v-dialog
      v-model="addcupom"
      persistent
      content-class="dialogFull"
      transition="dialog-right-transition"
      width="auto "
      :fullscreen="$vuetify.breakpoint.xsOnly"
    >
      <AddCupom v-on:cuponCreated="eventEmit" @close="addcupom = false" />
    </v-dialog>

    <v-card
      class="my-5 text-center white--text rounded-pill"
      color="purple darken-2"
      @click.stop="addcupom = !addcupom"
    >
      <v-card-actions style="display: block">
        <v-icon
          size="30"
          color="white"
          style="position: absolute; left: 10px; top: 5px"
          >mdi-plus-circle-outline</v-icon
        >
        Add Cupom
      </v-card-actions>
    </v-card>
  </v-container>
</template>

<script>
import { mapGetters } from "vuex";
import AddCupom from "@/components/vendas/cupons/addCupom.vue";
import Cupon from "@/repositories/Cupon";
export default {
  components: {
    AddCupom,
  },
  computed: {
    ...mapGetters("cupons", ["allCupons"]),
    getAllCupons() {
      return this.allCupons.length;
    },
  },
  data() {
    return {
      cupons: [],
      cuponsActiveTotal: 0,
      fill: false,
      padding: 8,
      color: "red",
      radius: 10,
      value: [0, 2, 5, 9, 5, 10, 3, 5, 0],
      width: 8,
      addcupom: false,
      files: [
        {
          color: "black",
          icon: "mdi-ticket-percent",
          subtitle: "16 de setembro de 2022",
          title: "BLACKFRIDAY",
          count: "137 Vendas",
        },
        {
          color: "green",
          icon: "mdi-ticket-percent",
          subtitle: "16 de julho de 2021",
          title: "PRIMEIRACOMPRA",
          count: "137 Vendas",
        },
        {
          color: "blue",
          icon: "mdi-ticket-percent",
          subtitle: "27 de setembro de 2022",
          title: "NOVEMBROAZUL",
          count: "137 Vendas",
        },
        {
          color: "amber",
          icon: "mdi-ticket-percent",
          subtitle: "21 de fevereiro de 2022",
          title: "JULIALIZ",
          count: "137 Vendas",
        },
      ],
    };
  },
  methods: {
    // getCupons() {
    //   Cupon.getCupons().then((response) => {
    //     response
    //       .json()
    //       .then((data) => {
    //         data.map((item) => {
    //           if(item.cuponStatus === "Ativo"){
    //             this.cuponsActiveTotal += 1
    //           }
    //         })
    //       })
    //       .catch((error) => console.log("error", error));
    //   });
    // },
    eventEmit() {
      console.log("Caiu aqui");
    },
  },
  created() {
    // this.getCupons();
  },
};
</script>

<style scoped>
@media only screen and (min-width: 960px) {
  ::v-deep .dialogFull {
    height: 100% !important;
    width: 30% !important;
    position: absolute!important;
    right: 0!important;
    left: none!important;
  }
}
::v-deep .dialog-right-transition-enter,
::v-deep .dialog-right-transition-leave-to {
  transform: translateX(100%) !important;
}
::v-deep .v-dialog:not(.v-dialog--fullscreen) {
  max-height: 100% !important;
}
</style>