<template>
  <v-card>
    <v-card-title> Detalhes do Cliente</v-card-title>
    <v-divider></v-divider>
    <v-row no-gutters>
      <v-col>
        <v-list-item two-line>
          <v-list-item-avatar size="80">
            <img src="https://randomuser.me/api/portraits/women/81.jpg" />
          </v-list-item-avatar>

          <v-list-item-content>
            <v-list-item-title>{{ clientDetail.name }}</v-list-item-title>
            <v-list-item-subtitle>{{
              clientDetail.email
            }}</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </v-col>
      <v-col>
        <v-list-item>
          <v-list-item-content>
            <v-list-item-title>Endereço</v-list-item-title>
            <v-list-item-subtitle>
              {{
                clientDetail.endereco.rua + ", " + clientDetail.endereco.number
              }}
            </v-list-item-subtitle>
            <v-list-item-subtitle>
              {{ clientDetail.endereco.bairro }}
            </v-list-item-subtitle>
            <v-list-item-subtitle>
              {{
                clientDetail.endereco.cidade +
                ", " +
                clientDetail.endereco.estado
              }}
            </v-list-item-subtitle>
            <v-list-item-subtitle>{{ clientDetail.cep }}</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </v-col>
    </v-row>

    <v-divider></v-divider>
    <v-row no-gutters>
      <v-col>
        <v-card class="text-center">
          <v-card-title style="display: block;font-size:16px"> Total de Pedido </v-card-title>
          <v-card-subtitle> 2 </v-card-subtitle>
        </v-card>
      </v-col>

      <v-col>
        <v-card class="text-center">
          <v-card-title style="display: block;font-size:16px"> Total Gasto </v-card-title>
          <v-card-subtitle> R$ 500 </v-card-subtitle>
        </v-card>
      </v-col>

      <v-col>
        <v-card class="text-center">
          <v-card-title style="display: block;font-size:16px"> Itens já comprados </v-card-title>
          <v-card-subtitle> 3 </v-card-subtitle>
        </v-card>
      </v-col>
    </v-row>
    <v-divider></v-divider>
  </v-card>
</template>

<script>
export default {
  props: {
    clientDetail: Object,
  },
  data() {
    return {};
  },
};
</script>

<style>
</style>