<template>
  <div class="mx-auto">
    <!-- <v-card color="grey"> -->
    <!-- <v-card-title class="white--text"> Clientes que mais gastaram </v-card-title> -->
    <v-data-table :headers="header" :items="getAllClients" class="elevation-1">
      <template v-slot:[`item.totalOrder`]="{ item }">
        <span>{{ item.order.length }}</span>
      </template>

      <template v-slot:[`item.totalBuyer`]="{ item }">
        <span>{{ countItens(item) }}</span>
      </template>

      <template v-slot:[`item.totalCupons`]="{}">
        <span>0</span>
      </template>

      <template v-slot:[`item.totalSpend`]="{ item }">
        <span>
          {{
            new Intl.NumberFormat("pt-BR", {
              style: "currency",
              currency: "BRL",
            }).format(totalSpend(item))
          }}
        </span>
      </template>

      <template v-slot:[`item.details`]="{ item }">
        <v-icon @click="showDetails(item)">mdi-eye</v-icon>
      </template>
    </v-data-table>
    <!-- </v-card> -->
    <v-dialog v-model="showDetail" max-width="40%">
      <ClientDetails :clientDetail="clientDetail" />
    </v-dialog>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import ClientDetails from "./clientesDetails.vue";
export default {
  components: {
    ClientDetails,
  },
  computed: {
    ...mapGetters("clients", ["allClients"]),
    ...mapGetters("orders", ["allorders"]),
    getAllClients() {
      this.allClients.map((item) => {
        item.order = this.allorders.filter((object) => object.user === item.pk);
      });
      return this.allClients.filter(item => item.order.length > 0);
    },
  },
  data() {
    return {
      showDetail: false,
      clientDetail: {},
      header: [
        // { text: "Imagem", value: "clientPicture" },
        { text: "Nome", value: "name" },
        { text: "Total de pedidos", value: "totalOrder" },
        { text: "Itens já comprados", value: "totalBuyer" },
        { text: "Cupons aplicados", value: "totalCupons" },
        { text: "Total gasto", value: "totalSpend" },
      ],
    };
  },
  methods: {
    ...mapActions("clients", ["loadClients"]),
    ...mapActions("orders", ["loadOrders"]),
    showDetails(item) {
      this.showDetail = true;
      console.log(item);
      this.clientDetail = item;
    },
    countItens(item) {
      var total = 0;
      item.order.map((item) => {
        total += item.products.length;
      });
      return total;
    },
    totalSpend(item) {
      var total = 0;
      item.order.map((item) => {
        total += parseFloat(item.orderDetails.grossAmount._text);
      });
      return total.toFixed(2);
    },
  },
  created() {
    this.loadClients();
    this.loadOrders();
  },
};
</script>

<style>
</style>