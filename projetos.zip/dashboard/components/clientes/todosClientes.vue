<template>
  <div class="mx-auto">
    <!-- <v-card color="grey"> -->
    <!-- <v-card-title class="white--text"> Clientes que mais gastaram </v-card-title> -->
    <v-data-table
      :headers="miniheaders"
      :items="getAllClients"
      class="elevation-1"
    >
      <template v-slot:[`item.details`]="{ item }">
        <v-icon @click="showDetails(item)">mdi-eye</v-icon>
      </template>
    </v-data-table>
    <!-- </v-card> -->
    <v-dialog v-model="showDetail" max-width="40%">
      <ClientDetails :clientDetail="clientDetail" />
    </v-dialog>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import ClientDetails from "./clientesDetails.vue";
export default {
  components:{
    ClientDetails
  },
  computed: {
    ...mapGetters("clients", ["allClients"]),
    getAllClients() {
      return this.allClients;
    },
  },
  data() {
    return {
      showDetail: false,
      clientDetail: {},
      miniheaders: [
        // { text: "Imagem", value: "clientPicture" },
        { text: "Nome", value: "name" },
        { text: "Total de pedidos", value: "totalOrder" },
        { text: "Itens já comprados", value: "totalBuyer" },
        { text: "Cupons aplicados", value: "totalCupons" },
        { text: "Total gasto", value: "totalSpend" },
        { text: "Email", value: "email" },
        { text: "Contato", value: "cel" },
        { text: "UF", value: "endereco.estado" },
        { text: "Cidade", value: "endereco.cidade" },
        { text: "CEP", value: "cep" },
        { text: "Proximidade da Loja", value: "nextStore" },
        { text: "Data de cadastro", value: "createdAt" },
        { text: "Detalhes", value: "details" },
      ],
    };
  },
  methods: {
    ...mapActions("clients", ["loadClients"]),
    showDetails(item) {
      this.showDetail = true;
      console.log(item)
      this.clientDetail = item;
    },
  },
  created() {
    this.loadClients();
  },
};
</script>

<style>
</style>