<template>
  <div>
    <!-- Campo de pesquisa -->
    <v-text-field
      v-model="search"
      append-icon="mdi-magnify"
      label="Ex: Procurar por nome"
      style="width: 500px"
      single-line
      hide-details
    ></v-text-field>
    <v-data-table
      :headers="headers"
      :items="leads"
      :search="search"
      class="elevation-1"
      hide-default-footer
    >
      <template v-slot:[`item.createdAt`]={item}>
        <span>{{
          new Date(item.createdAt).toLocaleDateString("pt-BR", {
            day: "2-digit",
            month: "numeric",
            year: "numeric",
          })
        }}</span>
      </template>
    </v-data-table>
  </div>
</template>

<script>
import Leads from "@/repositories/Leads";
export default {
  data() {
    return {
      search: "",
      headers: [
        { text: "Data", value: "createdAt" },
        { text: "Email", value: "email" },
      ],
      leads: [],
    };
  },
  methods: {
    getLeads() {
      Leads.getLeads().then((response) => {
        response
          .json()
          .then((data) => {
            this.leads = data;
          })
          .catch((error) => console.log("error", error));
      });
    },
  },
  created() {
    this.getLeads();
  },
};
</script>

<style>
</style>