import colors from 'vuetify/es5/util/colors'

export default {
  target: 'static',
  // Global page headers (https://go.nuxtjs.dev/config-head)
  head: {
    titleTemplate: '%s - Agouti',
    title: 'Dashboard',
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: '' },
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.png' }
    ],
  },

  // Global CSS (https://go.nuxtjs.dev/config-css)
  css: [
  ],

  // Plugins to run before rendering page (https://go.nuxtjs.dev/config-plugins)
  plugins: [
    { src: '~plugins/vue-apexchart.js', ssr: false },
    { src: '~plugins/vuelidate.js', ssr: false },
    { src: '~plugins/vue-chartjs.js', ssr: false },
    { src: '~plugins/vue-vue-the-mask.js', ssr: false },
    { src: '~plugins/vue-tagInput.js', ssr: false },
  ],

  // Auto import components (https://go.nuxtjs.dev/config-components)
  components: true,

  // Modules for dev and build (recommended) (https://go.nuxtjs.dev/config-modules)
  buildModules: [
    // https://go.nuxtjs.dev/vuetify
    '@nuxtjs/vuetify',
    '@nuxtjs/moment'
  ],
  router: {
    middleware: ['auth']
  },
  // Modules (https://go.nuxtjs.dev/config-modules)
  modules: [
    [
      '@nuxtjs/firebase',
      {
        config: {
          apiKey: "AIzaSyCcRdA6bRTqYeTtz8cX_FVfkL9Vx_yIovE",
          authDomain: "dashboard-auth-ea93e.firebaseapp.com",
          projectId: "dashboard-auth-ea93e",
          storageBucket: "dashboard-auth-ea93e.appspot.com",
          messagingSenderId: "692771782238",
          appId: "1:692771782238:web:ee5e0873c5ad3fe415fecf",
          measurementId: "G-B0C8YYQ058"
        },
        services: {
          auth: {
            persistence: 'local', // default
            initialize: {
              onAuthStateChangedAction: 'onAuthStateChangedAction',
              subscribeManually: false
            },
            ssr: false,
          },
          firestore: true,
        }
      }
    ]
  ],

  // Vuetify module configuration (https://go.nuxtjs.dev/config-vuetify)
  vuetify: {
    customVariables: ['~/assets/variables.scss'],
    theme: {
      dark: false,
      themes: {
        dark: {
          primary: colors.blue.darken2,
          accent: colors.grey.darken3,
          secondary: colors.amber.darken3,
          info: colors.teal.lighten1,
          warning: colors.amber.base,
          error: colors.deepOrange.accent4,
          success: colors.green.accent3
        }
      }
    }
  },

  moment: {
    timezone: true
  },

  // Build Configuration (https://go.nuxtjs.dev/config-build)
  build: {
  }
}
