export { default as Logo } from '../../components/Logo.vue'
export { default as VuetifyLogo } from '../../components/VuetifyLogo.vue'
export { default as ClientesDetails } from '../../components/clientes/clientesDetails.vue'
export { default as Compradores } from '../../components/clientes/compradores.vue'
export { default as Leads } from '../../components/clientes/leads.vue'
export { default as TodosClientes } from '../../components/clientes/todosClientes.vue'
export { default as AddProdutos } from '../../components/produtos/add_produtos.vue'
export { default as Atributos } from '../../components/produtos/atributos.vue'
export { default as Categorias } from '../../components/produtos/categorias.vue'
export { default as EditProduto } from '../../components/produtos/editProduto.vue'
export { default as TagsPopulares } from '../../components/produtos/tagsPopulares.vue'
export { default as Produto } from '../../components/produtos/add_produtos_modules/produto.vue'
export { default as ProdutoCombo } from '../../components/produtos/add_produtos_modules/produto_combo.vue'
export { default as ProdutoVar } from '../../components/produtos/add_produtos_modules/produto_var.vue'
export { default as ProdutoEdit } from '../../components/produtos/edit_products_modules/produto_edit.vue'
export { default as ProdutoEditCopy } from '../../components/produtos/edit_products_modules/produto_edit_copy.vue'
export { default as ProdutoVarEdit } from '../../components/produtos/edit_products_modules/produto_var_edit.vue'
export { default as ButtonsCreate } from '../../components/produtos/todosProdutos/buttonsCreate.vue'
export { default as TableProdutos } from '../../components/produtos/todosProdutos/tableProdutos.vue'
export { default as AddCupom } from '../../components/vendas/cupons/addCupom.vue'
export { default as CuponsTable } from '../../components/vendas/cupons/cuponsTable.vue'
export { default as InfoCupons } from '../../components/vendas/cupons/infoCupons.vue'
export { default as HistoricoInfoCards } from '../../components/vendas/historicoVendas/historicoInfoCards.vue'
export { default as HistoricoVendas } from '../../components/vendas/historicoVendas/historicoVendas.vue'
export { default as VendaDetails } from '../../components/vendas/historicoVendas/vendaDetails.vue'
export { default as InfoCards } from '../../components/vendas/topVendas/infoCards.vue'
export { default as TabelaTopVendas } from '../../components/vendas/topVendas/tabelaTopVendas.vue'
export { default as VendaDetailsDaily } from '../../components/vendas/topVendas/vendaDetailsDaily.vue'
export { default as AddButtonVendedor } from '../../components/vendas/vendedores/addButtonVendedor.vue'
export { default as AddVendedor } from '../../components/vendas/vendedores/addVendedor.vue'
export { default as VendedorTable } from '../../components/vendas/vendedores/vendedorTable.vue'

export const LazyLogo = import('../../components/Logo.vue' /* webpackChunkName: "components/Logo" */).then(c => c.default || c)
export const LazyVuetifyLogo = import('../../components/VuetifyLogo.vue' /* webpackChunkName: "components/VuetifyLogo" */).then(c => c.default || c)
export const LazyClientesDetails = import('../../components/clientes/clientesDetails.vue' /* webpackChunkName: "components/clientes/clientesDetails" */).then(c => c.default || c)
export const LazyCompradores = import('../../components/clientes/compradores.vue' /* webpackChunkName: "components/clientes/compradores" */).then(c => c.default || c)
export const LazyLeads = import('../../components/clientes/leads.vue' /* webpackChunkName: "components/clientes/leads" */).then(c => c.default || c)
export const LazyTodosClientes = import('../../components/clientes/todosClientes.vue' /* webpackChunkName: "components/clientes/todosClientes" */).then(c => c.default || c)
export const LazyAddProdutos = import('../../components/produtos/add_produtos.vue' /* webpackChunkName: "components/produtos/add_produtos" */).then(c => c.default || c)
export const LazyAtributos = import('../../components/produtos/atributos.vue' /* webpackChunkName: "components/produtos/atributos" */).then(c => c.default || c)
export const LazyCategorias = import('../../components/produtos/categorias.vue' /* webpackChunkName: "components/produtos/categorias" */).then(c => c.default || c)
export const LazyEditProduto = import('../../components/produtos/editProduto.vue' /* webpackChunkName: "components/produtos/editProduto" */).then(c => c.default || c)
export const LazyTagsPopulares = import('../../components/produtos/tagsPopulares.vue' /* webpackChunkName: "components/produtos/tagsPopulares" */).then(c => c.default || c)
export const LazyProduto = import('../../components/produtos/add_produtos_modules/produto.vue' /* webpackChunkName: "components/produtos/add_produtos_modules/produto" */).then(c => c.default || c)
export const LazyProdutoCombo = import('../../components/produtos/add_produtos_modules/produto_combo.vue' /* webpackChunkName: "components/produtos/add_produtos_modules/produto_combo" */).then(c => c.default || c)
export const LazyProdutoVar = import('../../components/produtos/add_produtos_modules/produto_var.vue' /* webpackChunkName: "components/produtos/add_produtos_modules/produto_var" */).then(c => c.default || c)
export const LazyProdutoEdit = import('../../components/produtos/edit_products_modules/produto_edit.vue' /* webpackChunkName: "components/produtos/edit_products_modules/produto_edit" */).then(c => c.default || c)
export const LazyProdutoEditCopy = import('../../components/produtos/edit_products_modules/produto_edit_copy.vue' /* webpackChunkName: "components/produtos/edit_products_modules/produto_edit_copy" */).then(c => c.default || c)
export const LazyProdutoVarEdit = import('../../components/produtos/edit_products_modules/produto_var_edit.vue' /* webpackChunkName: "components/produtos/edit_products_modules/produto_var_edit" */).then(c => c.default || c)
export const LazyButtonsCreate = import('../../components/produtos/todosProdutos/buttonsCreate.vue' /* webpackChunkName: "components/produtos/todosProdutos/buttonsCreate" */).then(c => c.default || c)
export const LazyTableProdutos = import('../../components/produtos/todosProdutos/tableProdutos.vue' /* webpackChunkName: "components/produtos/todosProdutos/tableProdutos" */).then(c => c.default || c)
export const LazyAddCupom = import('../../components/vendas/cupons/addCupom.vue' /* webpackChunkName: "components/vendas/cupons/addCupom" */).then(c => c.default || c)
export const LazyCuponsTable = import('../../components/vendas/cupons/cuponsTable.vue' /* webpackChunkName: "components/vendas/cupons/cuponsTable" */).then(c => c.default || c)
export const LazyInfoCupons = import('../../components/vendas/cupons/infoCupons.vue' /* webpackChunkName: "components/vendas/cupons/infoCupons" */).then(c => c.default || c)
export const LazyHistoricoInfoCards = import('../../components/vendas/historicoVendas/historicoInfoCards.vue' /* webpackChunkName: "components/vendas/historicoVendas/historicoInfoCards" */).then(c => c.default || c)
export const LazyHistoricoVendas = import('../../components/vendas/historicoVendas/historicoVendas.vue' /* webpackChunkName: "components/vendas/historicoVendas/historicoVendas" */).then(c => c.default || c)
export const LazyVendaDetails = import('../../components/vendas/historicoVendas/vendaDetails.vue' /* webpackChunkName: "components/vendas/historicoVendas/vendaDetails" */).then(c => c.default || c)
export const LazyInfoCards = import('../../components/vendas/topVendas/infoCards.vue' /* webpackChunkName: "components/vendas/topVendas/infoCards" */).then(c => c.default || c)
export const LazyTabelaTopVendas = import('../../components/vendas/topVendas/tabelaTopVendas.vue' /* webpackChunkName: "components/vendas/topVendas/tabelaTopVendas" */).then(c => c.default || c)
export const LazyVendaDetailsDaily = import('../../components/vendas/topVendas/vendaDetailsDaily.vue' /* webpackChunkName: "components/vendas/topVendas/vendaDetailsDaily" */).then(c => c.default || c)
export const LazyAddButtonVendedor = import('../../components/vendas/vendedores/addButtonVendedor.vue' /* webpackChunkName: "components/vendas/vendedores/addButtonVendedor" */).then(c => c.default || c)
export const LazyAddVendedor = import('../../components/vendas/vendedores/addVendedor.vue' /* webpackChunkName: "components/vendas/vendedores/addVendedor" */).then(c => c.default || c)
export const LazyVendedorTable = import('../../components/vendas/vendedores/vendedorTable.vue' /* webpackChunkName: "components/vendas/vendedores/vendedorTable" */).then(c => c.default || c)
