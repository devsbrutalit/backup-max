import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0605bbff = () => interopDefault(import('../pages/clientes/index.vue' /* webpackChunkName: "pages/clientes/index" */))
const _5adde870 = () => interopDefault(import('../pages/estoque/index.vue' /* webpackChunkName: "pages/estoque/index" */))
const _4efa2da0 = () => interopDefault(import('../pages/produtos/index.vue' /* webpackChunkName: "pages/produtos/index" */))
const _3f3845c6 = () => interopDefault(import('../pages/statusPedido/index.vue' /* webpackChunkName: "pages/statusPedido/index" */))
const _817cf1c6 = () => interopDefault(import('../pages/vendas/index.vue' /* webpackChunkName: "pages/vendas/index" */))
const _37728514 = () => interopDefault(import('../pages/auth/signin.vue' /* webpackChunkName: "pages/auth/signin" */))
const _1cbc0c66 = () => interopDefault(import('../pages/auth/signout.vue' /* webpackChunkName: "pages/auth/signout" */))
const _4964f432 = () => interopDefault(import('../pages/clientes/compradores/index.vue' /* webpackChunkName: "pages/clientes/compradores/index" */))
const _01c2f8c7 = () => interopDefault(import('../pages/clientes/leads/index.vue' /* webpackChunkName: "pages/clientes/leads/index" */))
const _3c5c9a36 = () => interopDefault(import('../pages/clientes/todosClientes/index.vue' /* webpackChunkName: "pages/clientes/todosClientes/index" */))
const _6ef9f6b1 = () => interopDefault(import('../pages/estoque/baixoEstoque.vue' /* webpackChunkName: "pages/estoque/baixoEstoque" */))
const _615ce5a6 = () => interopDefault(import('../pages/estoque/emEstoque.vue' /* webpackChunkName: "pages/estoque/emEstoque" */))
const _8d23c7d4 = () => interopDefault(import('../pages/estoque/foraEstoque.vue' /* webpackChunkName: "pages/estoque/foraEstoque" */))
const _33777c1d = () => interopDefault(import('../pages/produtos/add_produtos/index.vue' /* webpackChunkName: "pages/produtos/add_produtos/index" */))
const _6cc209cc = () => interopDefault(import('../pages/produtos/atributos/index.vue' /* webpackChunkName: "pages/produtos/atributos/index" */))
const _71349bc5 = () => interopDefault(import('../pages/produtos/categorias/index.vue' /* webpackChunkName: "pages/produtos/categorias/index" */))
const _70298fb8 = () => interopDefault(import('../pages/produtos/todosProdutos/index.vue' /* webpackChunkName: "pages/produtos/todosProdutos/index" */))
const _fe2fba04 = () => interopDefault(import('../pages/vendas/cupons/index.vue' /* webpackChunkName: "pages/vendas/cupons/index" */))
const _fe61c696 = () => interopDefault(import('../pages/vendas/historicoVendas/index.vue' /* webpackChunkName: "pages/vendas/historicoVendas/index" */))
const _4058565a = () => interopDefault(import('../pages/vendas/topVendas/index.vue' /* webpackChunkName: "pages/vendas/topVendas/index" */))
const _1a97ce1d = () => interopDefault(import('../pages/vendas/vendedores/index.vue' /* webpackChunkName: "pages/vendas/vendedores/index" */))
const _49961673 = () => interopDefault(import('../pages/produtos/atributos/addAtributo.vue' /* webpackChunkName: "pages/produtos/atributos/addAtributo" */))
const _c5d0bd22 = () => interopDefault(import('../pages/produtos/categorias/addCategoria.vue' /* webpackChunkName: "pages/produtos/categorias/addCategoria" */))
const _b4a9df02 = () => interopDefault(import('../pages/vendas/cupons/addCupom.vue' /* webpackChunkName: "pages/vendas/cupons/addCupom" */))
const _638d64b3 = () => interopDefault(import('../pages/vendas/vendedores/addVendedor.vue' /* webpackChunkName: "pages/vendas/vendedores/addVendedor" */))
const _5f68d61b = () => interopDefault(import('../pages/vendas/vendedores/perfilVendedor/index.vue' /* webpackChunkName: "pages/vendas/vendedores/perfilVendedor/index" */))
const _16f838be = () => interopDefault(import('../pages/vendas/vendedores/editVendedor/_pk.vue' /* webpackChunkName: "pages/vendas/vendedores/editVendedor/_pk" */))
const _1e16bfd8 = () => interopDefault(import('../pages/produtos/atributos/_pk.vue' /* webpackChunkName: "pages/produtos/atributos/_pk" */))
const _5133e39b = () => interopDefault(import('../pages/produtos/categorias/_categorySlug.vue' /* webpackChunkName: "pages/produtos/categorias/_categorySlug" */))
const _c3c69e00 = () => interopDefault(import('../pages/produtos/todosProdutos/_pk.vue' /* webpackChunkName: "pages/produtos/todosProdutos/_pk" */))
const _69347f9f = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/clientes",
    component: _0605bbff,
    name: "clientes"
  }, {
    path: "/estoque",
    component: _5adde870,
    name: "estoque"
  }, {
    path: "/produtos",
    component: _4efa2da0,
    name: "produtos"
  }, {
    path: "/statusPedido",
    component: _3f3845c6,
    name: "statusPedido"
  }, {
    path: "/vendas",
    component: _817cf1c6,
    name: "vendas"
  }, {
    path: "/auth/signin",
    component: _37728514,
    name: "auth-signin"
  }, {
    path: "/auth/signout",
    component: _1cbc0c66,
    name: "auth-signout"
  }, {
    path: "/clientes/compradores",
    component: _4964f432,
    name: "clientes-compradores"
  }, {
    path: "/clientes/leads",
    component: _01c2f8c7,
    name: "clientes-leads"
  }, {
    path: "/clientes/todosClientes",
    component: _3c5c9a36,
    name: "clientes-todosClientes"
  }, {
    path: "/estoque/baixoEstoque",
    component: _6ef9f6b1,
    name: "estoque-baixoEstoque"
  }, {
    path: "/estoque/emEstoque",
    component: _615ce5a6,
    name: "estoque-emEstoque"
  }, {
    path: "/estoque/foraEstoque",
    component: _8d23c7d4,
    name: "estoque-foraEstoque"
  }, {
    path: "/produtos/add_produtos",
    component: _33777c1d,
    name: "produtos-add_produtos"
  }, {
    path: "/produtos/atributos",
    component: _6cc209cc,
    name: "produtos-atributos"
  }, {
    path: "/produtos/categorias",
    component: _71349bc5,
    name: "produtos-categorias"
  }, {
    path: "/produtos/todosProdutos",
    component: _70298fb8,
    name: "produtos-todosProdutos"
  }, {
    path: "/vendas/cupons",
    component: _fe2fba04,
    name: "vendas-cupons"
  }, {
    path: "/vendas/historicoVendas",
    component: _fe61c696,
    name: "vendas-historicoVendas"
  }, {
    path: "/vendas/topVendas",
    component: _4058565a,
    name: "vendas-topVendas"
  }, {
    path: "/vendas/vendedores",
    component: _1a97ce1d,
    name: "vendas-vendedores"
  }, {
    path: "/produtos/atributos/addAtributo",
    component: _49961673,
    name: "produtos-atributos-addAtributo"
  }, {
    path: "/produtos/categorias/addCategoria",
    component: _c5d0bd22,
    name: "produtos-categorias-addCategoria"
  }, {
    path: "/vendas/cupons/addCupom",
    component: _b4a9df02,
    name: "vendas-cupons-addCupom"
  }, {
    path: "/vendas/vendedores/addVendedor",
    component: _638d64b3,
    name: "vendas-vendedores-addVendedor"
  }, {
    path: "/vendas/vendedores/perfilVendedor",
    component: _5f68d61b,
    name: "vendas-vendedores-perfilVendedor"
  }, {
    path: "/vendas/vendedores/editVendedor/:pk?",
    component: _16f838be,
    name: "vendas-vendedores-editVendedor-pk"
  }, {
    path: "/produtos/atributos/:pk",
    component: _1e16bfd8,
    name: "produtos-atributos-pk"
  }, {
    path: "/produtos/categorias/:categorySlug",
    component: _5133e39b,
    name: "produtos-categorias-categorySlug"
  }, {
    path: "/produtos/todosProdutos/:pk",
    component: _c3c69e00,
    name: "produtos-todosProdutos-pk"
  }, {
    path: "/",
    component: _69347f9f,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
