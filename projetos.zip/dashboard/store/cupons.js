export const state = () => ({
    cupons: [],
})

export const mutations = {
    setCupons(state, data) {
        state.cupons = data
    },
}
export const getters ={
    allCupons: state => {
        return state.cupons
    }
}
import Cupon from "@/repositories/Cupon";
export const actions = {

    async loadCupons({ commit, state }) {
        Cupon.getCupons().then((response) => {
            response
                .json()
                .then((data) => {
                    commit('setCupons', data)
                })
                .catch((error) => console.log("error", error));
        });

    },
}