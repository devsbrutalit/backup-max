export const state = () => ({
    orders: [],
})

export const mutations = {
    setOrders(state, data) {
        state.orders = data
    },
}
export const getters ={
    allorders: state => {
        return state.orders
    }
}
import Order from "@/repositories/Orders";
export const actions = {

    async loadOrders({ commit, state }) {
        Order.getOrders().then((response) => {
            response
                .json()
                .then((data) => {
                    commit('setOrders', data)
                })
                .catch((error) => console.log("error", error));
        });

    },
}