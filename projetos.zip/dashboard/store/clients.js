export const state = () => ({
    clients: [],
})

export const mutations = {
    setClients(state, data) {
        state.clients = data
    },
}
export const getters ={
    allClients: state => {
        return state.clients
    }
}
import Client from "@/repositories/Client";
export const actions = {

    async loadClients({ commit, state }) {
        Client.getClients().then((response) => {
            response
                .json()
                .then((data) => {
                    commit('setClients', data)
                })
                .catch((error) => console.log("error", error));
        });

    },
}