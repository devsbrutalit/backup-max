export const state = () => ({
    attributes: []
})

export const mutations = {
    setAttributes(state, data) {
        state.attributes = data
    },
}
export const getters ={
    allAttributes: state => {
        return state.attributes
    }
}
import Attribute from "@/repositories/Attribute";
export const actions = {

    async loadAttributes({ commit, state }) {
        Attribute.getAttributes().then((response) => {
            response
                .json()
                .then((data) => {
                    commit('setAttributes', data)
                })
                .catch((error) => console.log("error", error));
        });

    }
}