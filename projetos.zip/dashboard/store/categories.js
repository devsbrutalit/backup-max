export const state = () => ({
    categories: []
})

export const mutations = {
    setCategories(state, data) {
        state.categories = data
    }, 
}
export const getters ={
    allcategories: state => {
        return state.categories
    }
}
import Category from "@/repositories/Category";
export const actions = {

    async loadCategories({ commit, state }) {
        Category.getCategorys().then((response) => {
            response
                .json()
                .then((data) => {
                    commit('setCategories', data)
                })
                .catch((error) => console.log("error", error));
        });

    },
}