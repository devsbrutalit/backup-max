export const state = () => ({
    sellers: [],
})

export const mutations = {
    setSellers(state, data) {
        state.sellers = data
    },
}
export const getters ={
    allSellers: state => {
        return state.sellers
    }
}
import Seller from "@/repositories/Seller";
export const actions = {

    async loadSellers({ commit, state }) {
        Seller.getSellers().then((response) => {
            response
                .json()
                .then((data) => {
                    commit('setSellers', data)
                })
                .catch((error) => console.log("error", error));
        });

    },
}