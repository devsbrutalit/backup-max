export const state = () => ({
    products: [],
    switchVar: "Não",
})

export const mutations = {
    setProducts(state, data) {
        state.products = data
    },
    setSwitch(state, data) {
        state.switchVar = data
    },
}
export const getters ={
    allproducts: state => {
        return state.products
    },
    getSwitch: state => {
        return state.switchVar
    },
}
import Product from "@/repositories/Product";
export const actions = {

    async loadProducts({ commit, state }) {
        Product.getproducts().then((response) => {
            response
                .json()
                .then((data) => {
                    commit('setProducts', data)
                })
                .catch((error) => console.log("error", error));
        });

    },

    async ChangeSwitch({ commit, state }, switchState) {
        commit('setSwitch', switchState)
    }
}