<template>
  <v-app dark>
    <v-navigation-drawer
      v-if="currentUser"
      v-model="drawer"
      :clipped="clipped"
      :expand="$vuetify.breakpoint.xsOnly"
      color="#41433E"
      width="180px"
      fixed
      app
    >
      <div class="my-5 text-center">
        <v-avatar color="teal" size="78">
          <h1>{{ currentUser.name.charAt(0) }}</h1>
          <!-- <img src="https://randomuser.me/api/portraits/women/85.jpg" /> -->
        </v-avatar>
      </div>
      <v-list>
        <v-list-item-group active-class="isActive">
          <v-list-item
            v-for="(item, i) in items"
            :key="i"
            :to="item.to"
            :value="item.active"
            class="py-6"
            router
            exact-path
          >
            <v-list-item-content>
              <v-icon large>{{ item.icon }}</v-icon>
            </v-list-item-content>
          </v-list-item>
          <v-list-item>
            <!-- <v-list-item-content
              @click="$router.push('/auth/signout')"
              class="py-6"
            >
              <v-icon large>mdi-exit-to-app</v-icon>
            </v-list-item-content> -->
            <v-list-item-content @click="signout()" class="py-6">
              <v-icon large>mdi-exit-to-app</v-icon>
            </v-list-item-content>
          </v-list-item>
        </v-list-item-group>
      </v-list>
    </v-navigation-drawer>

    <v-app-bar
      v-if="currentUser"
      :clipped-left="clipped"
      fixed
      app
      color="transparent"
      elevation="0"
    >
      <v-icon @click="drawer = !drawer" class="hidden-lg-and-up">
        mdi-menu
      </v-icon>
      <v-spacer />
      <v-icon class="mx-5" x-large>mdi-dots-horizontal</v-icon>
    </v-app-bar>
    <v-main style="background-color: #eee">
      <v-container style="max-width: 100%" class="pa-0">
        <nuxt />
      </v-container>
      <v-footer absolute color="transparent">
        <span
          >&copy; {{ new Date().getFullYear() }} - Powered by
          <a href="https://brutalit.com.br">Brutalit</a></span
        >
      </v-footer>
    </v-main>
  </v-app>
</template>

<script>
export default {
  computed: {
    currentUser: {
      get() {
        return this.$store.getters.getUser;
      },
    },
  },
  data() {
    return {
      clipped: false,
      drawer: true,
      fixed: false,
      items: [
        {
          icon: "mdi-home",
          title: "Home",
          to: "/",
        },
        {
          icon: "mdi-cube-outline",
          title: "Produtos",
          to: "/produtos",
        },
        {
          icon: "mdi-cart",
          title: "Vendas",
          to: "/vendas",
        },
        {
          icon: "mdi-account-group",
          title: "Clientes",
          to: "/clientes",
        },
        {
          icon: "mdi-package-variant",
          title: "Estoque",
          to: "/estoque",
        },
        {
          icon: "mdi-magnify",
          title: "Estoque",
          to: "/statusPedido",
        },
      ],
      miniVariant: true,
      title: "Vuetify.js",
    };
  },
  methods: {
    signout() {
      $nuxt.$fire.auth.signOut();
    },
  },
};
</script>

<style scoped>
.isActive {
  color: #aef82d;
}

.isActive .theme--light.v-list-item--active:hover::before,
.theme--light.v-list-item--active::before {
  opacity: 0;
}
</style>
