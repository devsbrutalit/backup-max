export default{
    async createCupon(Event) {
        const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/cupon'
        // trecho abaixo comentado por Max
        //const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/cupon'     
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
            },
            body: JSON.stringify(Event)
        }
        return fetch(api, params)
    },

    async getCupons() {
        
        const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/getcupon'
        // trecho abaixo comentado por Max
        //const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/cupons'
        const params = {
            method: 'GET',
            headers: {
                "Content-type": "application/json",
                "Accept": "application/json",
                
            }
        }
        return fetch(api, params)
    },

    async changeStatusCupom(Event) {
          const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/changecupom'
        // trecho abaixo comentado por Max
        //const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/changecupom'     
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
            },
            body: JSON.stringify(Event)
        }
        return fetch(api, params)
    },

    async deleteCupom(Event) {
           const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/deleteCupom'
        // trecho abaixo comentado por Max
        // const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/deleteCupom'     
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
            },
            body: JSON.stringify(Event)
        }
        return fetch(api, params)
    },
}