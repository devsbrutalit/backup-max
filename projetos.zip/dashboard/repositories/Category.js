
export default{
    async createCategory(Event) {
          const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/category'
        // trecho abaixo comentado por Max  
        //const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/category'     
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
            },
            body: JSON.stringify(Event)
        }
        return fetch(api, params)
    },

    async getCategorys() {

        const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/categorys'
        // trecho abaixo comentado por Max
       // const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/categorys'
        // -> trecho abaixo comentado pelo dev anterior.
        // const api = 'https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/categorys'
        const params = {
            method: 'GET',
            headers: {
                "Content-type": "application/json",
                "Accept": "application/json",
                
            }
        }
        return fetch(api, params)
    },

    async updateCategory(Event) {
        console.log(Event)
        let url = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/category/' + Event.pk
        // trecho abaixo comentado por Max
        //let url = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/category/' + Event.categoryID
        const params = {
            method: 'PUT',
            headers: {
                "Content-type": "application/json",
                
            },
            body: JSON.stringify(Event)
         
        }
        return fetch(url, params)
    },

    async deleteCategory(Event) {
        let url = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/delete/category'
        // trecho abaixo comentado por Max o brabo da programação
        //let url = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/delete/category'
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
                
            },
            body: JSON.stringify(Event)
         
        }
        return fetch(url, params)
    },
}