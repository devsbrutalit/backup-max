
export default{
    async createAttribute(Event) {
        const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/attribute'     
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
            },
            body: JSON.stringify(Event)
        }
        return fetch(api, params)
    },

    async getAttributes() {
        const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/attributes'
        const params = {
            method: 'GET',
            headers: {
                "Content-type": "application/json",
                "Accept": "application/json",
                
            }
        }
        return fetch(api, params)
    },

    async updateAttribute(Event) {

        let url = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/attribute/' + Event.attributeID
        //let url = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/attribute/{attributeID}'
        //let url = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/attribute/' + Event.attributeID
        const params = {
            method: 'PUT',
            headers: {
                "Content-type": "application/json",
                
            },
            body: JSON.stringify(Event)
         
        }
        return fetch(url, params)
    },

    async deleteAttribute(Event) {
          let url = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/delete/attribute'
        //let url = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/delete/attribute'
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
                
            },
            body: JSON.stringify(Event)
         
        }
        return fetch(url, params)
    },
}