import axios from "axios"

export default {
  async updateEstoque(Event) {
    
    const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/updateStock'
    // Max
    //const api = 'https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/updateStock'
    // return fetch(api, params)
    return axios.post(api, Event)
  }
}