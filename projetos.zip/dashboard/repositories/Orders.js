export default {

    async getOrders() {
        
           const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/orders'
        // const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/orders'
        // linha abaixo comentada por Max
        //const api = 'https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/orders'
        // const api = 'http://localhost:3000/dev/orders'
        const params = {
            method: 'GET',
            headers: {
                "Content-type": "application/json",
                "Accept": "application/json",

            }
        }
        return fetch(api, params)
    },

    async attTrackCode(Event) {
        
          const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/updateOrder'
        // Max
        //const api = 'https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/updateOrder'        
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
                "Accept": "application/json",

            },
            body: JSON.stringify(Event)
        }
        return fetch(api, params)
    },

    async orderReedem(Event) {
        
           const api = ' https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/updateReedem'
        // Max
        // const api = ' https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/updateReedem'
        // const api = 'http://localhost:3000/dev/updateReedem'
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
                "Accept": "application/json",

            },
            body: JSON.stringify(Event)
        }
        return fetch(api, params)
    },

    async localizarPedido(Event) {
        
           const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/orderlocation'
        // const api = 'https://ihkf7z812b.execute-api.sa-east-1.amazonaws.com/dev/orderlocation'
        // Max
        //const api = 'https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/orderlocation'
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
            },
            body: JSON.stringify(Event)
        }
        return fetch(api, params)
    },

}