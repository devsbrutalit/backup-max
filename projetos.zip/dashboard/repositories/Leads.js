export default{
    async getLeads() {
        const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/getLeads'
        //Max 
        //const api = 'https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/getLeads'
        const params = {
            method: 'GET',
            headers: {
                "Content-type": "application/json",
                "Accept": "application/json",
                
            }
        }
        return fetch(api, params)
    },


}