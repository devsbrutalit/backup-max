
export default {

    async getClients() {
        const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/users'
        // trecho abaico comentado por Max
        //const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/users'
        const params = {
            method: 'GET',
            headers: {
                "Content-type": "application/json",
                "Accept": "application/json",

            }
        }
        return fetch(api, params)
    },

    async getClient(Event) {
          let url = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/seller/' + Event.sellerId
          // treccho abaixo comentado por Max
        //let url = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/seller/' + Event.sellerId
        const params = {
            method: 'GET',
            headers: {
                "Content-type": "application/json",

            },
            body: JSON.stringify(Event)

        }
        return fetch(url, params)
    },

    // async updateSeller(Event) {
    //     let url = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/product/' + Event.productId
    //     const params = {
    //         method: 'PUT',
    //         headers: {
    //             "Content-type": "application/json",

    //         },
    //         body: JSON.stringify(Event)

    //     }
    //     return fetch(url, params)
    // },

    // async deleteSeller(Event) {
    //     let url = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/delete/product'
    //     const params = {
    //         method: 'POST',
    //         headers: {
    //             "Content-type": "application/json",

    //         },
    //         body: JSON.stringify(Event)

    //     }
    //     return fetch(url, params)
    // },
}