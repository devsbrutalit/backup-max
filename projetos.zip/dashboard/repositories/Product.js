import axios from "axios"

export default{
    async createProducts(Event) {
        
        const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/product'
        // dev <-
        // const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/product'  
        // Max 
        //const api = 'https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/product'
        // dev <-
        // const api = 'http://localhost:3000/dev/product'
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
            },
            body: JSON.stringify(Event)
        }

        // <-
        // return fetch(api, params)
        // max
        return axios.post(api, Event)
        //location.replace('/produtos/todosProdutos')
    },

    async getproducts() {
        
           const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/products'
        // <-
        // const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/products'
        // Max
        //const api = 'https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/products'
        // <-
        // const api = 'http://localhost:3000/dev/products'
        const params = {
            method: 'GET',
            headers: {
                "Content-type": "application/json",
                "Accept": "application/json",
                
            }
        }
        return fetch(api, params)
    },

    async updateProduct(Event) {
        
        const api = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/product/' + Event.productId
        // <-
        // const api = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/product/' + Event.productId
        // Max
        //const api = 'https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/product/' + Event.productId
        // <-
        // const api = 'http://localhost:3000/dev/product/' + Event.productId
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
                
            },
            body: JSON.stringify(Event)
         
        }
        return fetch(api, params)
    },

    async deleteProduct(Event) {
        const url = 'https://cd8wxyy7ba.execute-api.sa-east-1.amazonaws.com/dev/delete/product'
        // <-
        // const url = 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/delete/product'
        // Max
        //const url = 'https://61vlt9p6r7.execute-api.sa-east-1.amazonaws.com/prod/delete/product'
        const params = {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
                
            },
            body: JSON.stringify(Event)
         
        }
        return fetch(url, params)
    },
}