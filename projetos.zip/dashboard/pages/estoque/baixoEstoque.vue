<template>
  <div>
    <v-data-table
      :headers="headers"
      :items="getAllproducts"
      class="elevation-1"
      height="800px"
      fixed-header
      item-key="pk"
      :single-expand="true"
      :expanded.sync="expanded"
      show-expand
      hide-default-footer
      disable-pagination
    >
      <!-- Template Filtros -->
      <!-- Filtro de Categorias -->
      <template v-slot:[`header.productCtg`]>
        <div style="display: inline-block; padding: 16px 0">Por Categoria</div>
        <div style="display: inline-block; margin-top: 8px">
          <v-menu offset-y :close-on-content-click="false">
            <template v-slot:activator="{ on, attrs }">
              <v-btn color="indigo" icon v-bind="attrs" v-on="on">
                <v-icon small> mdi-filter-variant </v-icon>
              </v-btn>
            </template>
            <v-list>
              <v-list-item-group v-model="name" multiple>
                <v-list-item
                  v-for="(item, index) in allProductName"
                  :key="index"
                  :value="item"
                >
                  <template v-slot:default="{ active }">
                    <v-list-item-action>
                      <v-checkbox
                        :input-value="active"
                        :true-value="item"
                        color="primary"
                        :ripple="false"
                        dense
                      ></v-checkbox>
                    </v-list-item-action>
                    <v-list-item-title>{{ item }}</v-list-item-title>
                  </template>
                </v-list-item>
              </v-list-item-group>
              <v-divider></v-divider>
              <v-btn text block @click="clearAll()" color="warning"
                >Clear all</v-btn
              >
            </v-list>
          </v-menu>
        </div>
      </template>

      <!-- Filtro de Qtd -->
      <!-- <template v-slot:[`header.productQtd`]>
            <div style="display: inline-block; padding: 16px 0;">Por Qtd</div>
            <div style="display: inline-block; margin-top: 8px">
             <v-menu offset-y :close-on-content-click="false">
              <template v-slot:activator="{ on, attrs }">
              <v-btn color="indigo" icon v-bind="attrs" v-on="on">
                <v-icon small>
                  mdi-filter-variant
                </v-icon>
              </v-btn>
              </template>
              <v-list>
              <v-list-item-group v-model="qtd" multiple>
                <v-list-item
                  v-for="(item, index) in allQtd"
                  :key="index" :value="item"
                >
                <template v-slot:default="{ active }">
                  <v-list-item-action>
                <v-checkbox :input-value="active" :true-value="item" color="primary" :ripple="false" dense></v-checkbox>
                </v-list-item-action>
                  <v-list-item-title>{{ item }}</v-list-item-title>
                </template>
                </v-list-item>
              </v-list-item-group>
              <v-divider></v-divider>
              <v-btn text block @click="clearAll()" color="warning">Clear all</v-btn>
              </v-list>
            </v-menu>
            </div>
          </template> -->

      <!-- Filtro de Valor -->
      <!-- <template v-slot:[`header.productValue`]>
            <div style="display: inline-block; padding: 16px 0;">Por preço</div>
            <div style="display: inline-block; margin-top: 8px">
             <v-menu offset-y :close-on-content-click="false">
              <template v-slot:activator="{ on, attrs }">
              <v-btn color="indigo" icon v-bind="attrs" v-on="on">
                <v-icon small>
                  mdi-filter-variant
                </v-icon>
              </v-btn>
              </template>
              <v-list>
              <v-list-item-group v-model="value" multiple>
                <v-list-item
                  v-for="(item, index) in allValue"
                  :key="index" :value="item"
                >
                <template v-slot:default="{ active }">
                  <v-list-item-action>
                <v-checkbox :input-value="active" :true-value="item" color="primary" :ripple="false" dense></v-checkbox>
                </v-list-item-action>
                  <v-list-item-title>{{ item }}</v-list-item-title>
                </template>
                </v-list-item>
              </v-list-item-group>
              <v-divider></v-divider>
              <v-btn text block @click="clearAll()" color="warning">Clear all</v-btn>
              </v-list>
            </v-menu>
            </div>
          </template> -->

      <!-- Filtro de data Cadastro -->
      <template v-slot:[`header.createdAt`]>
        <div style="display: inline-block; padding: 16px 0">
          Por data de cadastro
        </div>
        <div style="display: inline-block; margin-top: 8px">
          <v-menu offset-y :close-on-content-click="false">
            <template v-slot:activator="{ on, attrs }">
              <v-btn color="indigo" icon v-bind="attrs" v-on="on">
                <v-icon small> mdi-filter-variant </v-icon>
              </v-btn>
            </template>
            <v-list>
              <v-list-item-group v-model="createAt" multiple>
                <v-list-item
                  v-for="(item, index) in allDate"
                  :key="index"
                  :value="item"
                >
                  <template v-slot:default="{ active }">
                    <v-list-item-action>
                      <v-checkbox
                        :input-value="active"
                        :true-value="item"
                        color="primary"
                        :ripple="false"
                        dense
                      ></v-checkbox>
                    </v-list-item-action>
                    <v-list-item-title>{{ item }}</v-list-item-title>
                  </template>
                </v-list-item>
              </v-list-item-group>
              <v-divider></v-divider>
              <v-btn text block @click="clearAll()" color="warning"
                >Clear all</v-btn
              >
            </v-list>
          </v-menu>
        </div>
      </template>
      <!-- Fim templates filtros -->

      <!-- <template v-slot:[`header.actions`]>
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Ex: Nome, SKU, etc..."
          single-line
          hide-details
        ></v-text-field>
      </template> -->

      <!-- Template para imagem -->
      <template v-slot:[`item.imagem`]="{ item }">
        <v-img
          max-width="80"
          class="my-2 ma-auto"
          :src="
            item.productVariations
              ? item.productVariations[0].productPicture.find(
                  (main) => main.mainImage === true
                ).image
              : item.productPicture.find((main) => main.mainImage === true)
                  .image
          "
        ></v-img>
      </template>

      <!-- item.productVariations[0].productVarImg[0] : (item.productPicture[0] ? item.productPicture[0] : '') -->
      <!-- Template para Categoria/Nome produto -->

      <template v-slot:[`item.productCtg`]="{ item }">
        <v-list-item two-line>
          <v-list-item-content>
            <v-list-item-title style="max-width: 190px">
              {{ item.productName }}
            </v-list-item-title>
            <v-list-item-subtitle>{{ item.productCtg }}</v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </template>

      <!-- Template para valor do produto -->
      <template v-slot:[`item.productValue`]="{ item }">
        <span
          v-text="
            item.productVariations
              ? 'R$ ' + item.productVariations[0].productValue
              : 'R$ ' + item.productValue
          "
        ></span>
      </template>

      <!-- Template para data de criação/dias passados -->
      <template v-slot:[`item.createdAt`]="{ item }">
        <v-list-item two-line>
          <v-list-item-content>
            <v-list-item-title
              class="text-left black--text"
              style="font-size: 14px"
              ><v-icon small>mdi-timer-outline</v-icon>
              {{
                daysPassed(item.createdAt) + " Dias atrás"
              }}</v-list-item-title
            >
            <v-list-item-subtitle
              class="text-left black--text"
              style="font-size: 14px"
              ><v-icon small>mdi-timer-outline</v-icon>
              {{ setDate(item.createdAt) }}</v-list-item-subtitle
            >
          </v-list-item-content>
        </v-list-item>
      </template>

      <template v-slot:[`item.type`]="{ item }">
        <span v-if="item.productVariations">Variado</span>
        <span v-else>Simples</span>
      </template>

      <template v-slot:[`item.variations`]="{ item }">
        <span v-if="item.productVariations">{{
          item.productVariations.length
        }}</span>
        <span v-else>N/A</span>
      </template>

      <!-- Template da linha expandida -->
      <template v-slot:expanded-item="{ headers, item }">
        <td :colspan="headers.length" v-if="item.productVariations">
          <div class="ma-auto">
            <v-simple-table style="background-color: transparent">
              <template v-slot:default>
                <thead>
                  <tr>
                    <th class="text-left">Name</th>
                    <th class="text-left">Estoque mínimo</th>
                    <th class="text-left">Em estoque</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(attribute, i) in item.productVariations" :key="i">
                    <td>
                      <span>
                        <v-avatar
                          size="20"
                          :color="attribute.productColor.cor"
                          class="mr-2"
                          style="border: 1px solid black !important"
                        >
                        </v-avatar>
                        {{ attribute.productColor.name }} /
                      </span>
                      <span>{{ attribute.attName }}: {{ attribute.name }}</span>
                    </td>
                    <td>
                      <v-text-field
                        name="productMinQtd"
                        id="productMinQtd"
                        type="number"
                        outlined
                        hide-details
                        color="#aef82d"
                        v-model="attribute.productMinQtd"
                      ></v-text-field>
                    </td>
                    <td>
                      <v-text-field
                        name="productQtd"
                        id="productQtd"
                        type="number"
                        outlined
                        hide-details
                        color="#aef82d"
                        v-model="attribute.productQtd"
                      ></v-text-field>
                    </td>
                    <td>
                      <v-btn
                        color="#aef82d"
                        class="text-none"
                        @click="updateQtn(item, attribute, i)"
                      >
                        Salvar
                      </v-btn>
                    </td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table>
          </div>
        </td>
      </template>

      <!-- Template para ações -->
      <template v-slot:[`item.estoqueMinimo`]="{ item }">
        <v-text-field
          v-if="!item.productVariations"
          name="productMinQtd"
          id="productMinQtd"
          type="number"
          outlined
          hide-details
          color="#aef82d"
          v-model="item.productMinQtd"
        ></v-text-field>
      </template>

      <template v-slot:[`item.productQtd`]="{ item }">
        <v-text-field
          v-if="!item.productVariations"
          name="productQtd"
          id="productQtd"
          type="number"
          outlined
          hide-details
          color="#aef82d"
          v-model="item.productQtd"
        ></v-text-field>
      </template>
      <template v-slot:[`item.actions`]="{ item }">
        <v-btn
          v-if="!item.productVariations"
          color="#aef82d"
          class="text-none"
          @click="updateQtn(item)"
          >Salvar
        </v-btn>
      </template>
    </v-data-table>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import Product from "@/repositories/Product";
import Estoque from "@/repositories/Estoque";

export default {
  props: {
    source: String,
  },
  computed: {
    ...mapGetters("products", ["allproducts"]),
    getAllproducts() {
      this.produtos = [...this.allproducts];
      return this.produtos.filter((item) => {
        if (item.productVariations) {
          return item.productVariations.map((object) => {
            if (object.productQtd === object.productMinQtd) {
              return item;
            }
          });
        } else {
          if (item.productQtd === item.productMinQtd) {
            return item;
          }
        }
      });
    },
    allProductName() {
      const category = [];
      this.produtos.map((f) => {
        if (!category.includes(f.productCtg)) {
          category.push(f.productCtg);
        }
      });
      return category;
    },
    allQtd() {
      const qtd = [];
      this.produtos.map((f) => {
        if (!qtd.includes(f.productQtd)) {
          qtd.push(f.productQtd);
        }
      });
      return qtd;
    },
    allValue() {
      const value = [];
      this.produtos.map((f) => {
        if (!value.includes(f.productValue)) {
          value.push(f.productValue);
        }
      });
      return value;
    },
    allDate() {
      const createdDate = [];
      this.produtos.map((f) => {
        const date = new Date(f.createdAt);
        const data =
          date.getDate() +
          " " +
          date.toLocaleString("default", { month: "long" }) +
          " " +
          date.getFullYear();
        if (!createdDate.includes(data)) {
          createdDate.push(data);
        }
      });
      return createdDate;
    },
    closeOnContentClick() {
      return this.name.length === 0 ? false : true;
    },
  },
  data() {
    return {
      noconfirm: false,
      confirmDelete: false,
      produtos: [],
      editItem: {},
      itemDeleteTemp: {},
      name: [],
      qtd: [],
      value: [],
      status: [],
      createAt: [],
      expanded: [],
      vendas: [],
      filters: { PRODUTO: [], QTD: [], VALOR: [] },
      created: false,
      addproduto: false,
      editproduto: false,
      addcategoria: false,
      addatributo: false,
      headers: [
        { text: "Thumb", align: "center", value: "imagem", sortable: false },
        // { text: "produtoSearch", value: "productName", align: " d-none" },
        { text: "categorySearch", value: "productCtg", align: " d-none" },
        { text: "valorSearch", value: "productValue", align: " d-none" },
        { text: "qtdSearch", value: "productQtd", align: " d-none" },
        {
          text: "produto",
          align: "start",
          value: "productCtg",
          filter: (f) => {
            return this.name.length > 0
              ? this.name.includes(f)
              : this.allProductName;
          },
        },
        { text: "SKU", align: "center", value: "productSku" },
        { text: "Preço", align: "center", value: "productValue" }, //filter: f => { return this.value.length > 0 ? this.value.includes(f) : this.allProductName }},
        {
          text: "CREATED AT",
          align: "center",
          value: "createdAt",
          filter: (f) => {
            const date = new Date(f);
            const data =
              date.getDate() +
              " " +
              date.toLocaleString("default", { month: "long" }) +
              " " +
              date.getFullYear();
            return this.createAt.length > 0
              ? this.createAt.includes(data)
              : this.allProductName;
          },
        },
        { text: "Tipo", align: "center", value: "type" },
        { text: "Variações", align: "center", value: "variations" },
        { value: "data-table-expand" },
        { text: "Estoque mínimo", align: "center", value: "estoqueMinimo" },
        { text: "Em estoque", align: "start", value: "productQtd" }, // filter: f => { return this.qtd.length > 0 ? this.qtd.includes(f) : this.allProductName }},
        { text: "Actions", align: "center", value: "actions", sortable: false },
      ],
    };
  },
  methods: {
    ...mapActions("products", ["loadProducts"]),

    confirmProductDelete(item) {
      this.confirmDelete = true;
      this.itemDeleteTemp = item;
    },

    deleteProduct() {
      Product.deleteProduct(this.itemDeleteTemp).then((response) => {
        response
          .json()
          .then((data) => {
            console.log(data);
            (this.itemDeleteTemp = {}), (this.confirmDelete = false);
            this.loadProducts();
          })
          .catch((error) => console.log("error", error));
      });
    },

    setEditItem(item) {
      console.log(item);
      this.editItem = Object.assign({}, item);
      this.editproduto = !this.editproduto;
    },

    updateQtn(item, attribute, index) {
      var newStock = {};

      if (item.productVariations) {
        newStock = {
          pk: item.pk,
          productQtd: parseInt(attribute.productQtd),
          productMinQtd: parseInt(attribute.productMinQtd),
          itemIndex: index,
        };
      } else {
        newStock = {
          pk: item.pk,
          productQtd: parseInt(item.productQtd),
          productMinQtd: parseInt(item.productMinQtd),
        };
      }

      Estoque.updateEstoque(newStock).then((response) => {
        response
          .json()
          .then(() => {
            this.snackbarText = "Produto atualizado";
            this.snackbar = true;
          })
          .catch((error) => {
            console.log("error", error);
            this.snackbarText = "Erro ao tentar atualizar o produto";
            this.snackbar = true;
          });
      });
    },

    eventEmit() {
      console.log("não caiu aqui");
      this.loadProducts();
    },

    clearAll() {
      this.name = [];
    },

    setDate(value) {
      // const data = date.getDay()
      const date = new Date(value);
      const data =
        date.getDate() +
        " " +
        date.toLocaleString("default", { month: "long" }) +
        " " +
        date.getFullYear();
      return data;
    },

    searchProducts(value) {
      if (value) {
        const fitler = this.produtos.includes(value);
        return filter;
      } else {
        return this.produtos;
      }
    },

    daysPassed(value) {
      const date = new Date(value);
      const now = new Date();
      const Difference_In_Time = now.getTime() - date.getTime();
      const Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
      return parseInt(Difference_In_Days);
    },
  },

  created() {
    this.loadProducts();
  },
};
</script>

<style>
</style>