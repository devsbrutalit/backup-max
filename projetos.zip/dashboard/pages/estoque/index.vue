<template>
  <v-container style="max-width: 1496px">
    <div class="text-center">
      <h1 style="color: #707070; font-size: 2.5rem">Estoque da loja</h1>
    </div>
    <v-row>
      <v-col
        v-for="item in cardOptions"
        :key="item.title"
        cols="12"
        xs="12"
        sm="6"
        md="6"
        lg="3"
      >
        <v-hover v-slot="{ hover }">
          <NuxtLink :to="item.to" style="text-decoration: none; color: inherit">
            <v-card
              class="text-center rounded-xl"
              style="color: #707070"
              :class="{ 'on-hover': hover }"
              height="350px"
            >
              <div
                style="
                  display: flex;
                  flex-direction: column;
                  justify-content: center;
                  height: 100%;
                "
              >
                <h1>{{ item.value }}</h1>
                <h1>{{ item.title }}</h1>
              </div>
            </v-card>
          </NuxtLink>
        </v-hover>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
export default {
  computed: {
    ...mapGetters("products", ["allproducts"]),
    getAllproducts() {
      return this.allproducts;
    },
  },
  watch: {
    getAllproducts(value) {
      var totalStock = 0;
      var lowStock = 0;
      var outStock = 0;

      value.map((item) => {
        if (item.productVariations) {
          item.productVariations.map((object) => {
            if (object.productQtd >= object.productMinQtd) {
              totalStock += 1;
              if ((object.productMinQtd = object.productQtd)) {
                lowStock += 1;
              }
            } else {
              outStock += 1;
            }
          });
        } else {
          if (item.productQtd >= item.productMinQtd) {
            if ((item.productMinQtd = item.productQtd)) {
              lowStock += 1;
            }
            totalStock += 1;
          } else {
            outStock += 1;
          }
        }
      });
      this.$set(this.cardOptions[0], "value", totalStock);
      this.$set(this.cardOptions[1], "value", lowStock);
      this.$set(this.cardOptions[2], "value", outStock);
    },
  },
  data() {
    return {
      cardOptions: [
        {
          title: "Em estoque",
          value: 0,
          to: "/estoque/emEstoque",
        },
        {
          title: "Baixo estoque",
          value: 0,
          to: "/estoque/baixoEstoque",
        },
        {
          title: "Fora de estoque",
          value: 0,
          to: "/estoque/foraEstoque",
        },
        {
          title: "Backorder",
          value: 30,
          to: "/estoque/backroder",
        },
      ],
    };
  },
  methods: {
    ...mapActions("products", ["loadProducts"]),
  },
  created() {
    this.loadProducts();
  },
};
</script>

<style scoped>
.on-hover {
  transition: background 0.5s;
  background: #41433e;
  color: #aef82d !important;
}

.on-hover-icon {
  color: #aef82d !important;
}
</style>