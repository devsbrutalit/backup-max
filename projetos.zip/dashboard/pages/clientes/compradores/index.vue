<template>
  <v-container fluid>
    <Compradores />
  </v-container>
</template>

<script>
import Compradores from "@/components/clientes/compradores.vue";

export default {
  components: {
    Compradores,
  },
};
</script>

<style>
</style>