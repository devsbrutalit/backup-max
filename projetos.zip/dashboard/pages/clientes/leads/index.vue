<template>
  <v-container fluid>
    <Leads />
  </v-container>
</template>

<script>
import Leads from "@/components/clientes/leads.vue";

export default {
  components: {
    Leads,
  },
};
</script>

<style>
</style>