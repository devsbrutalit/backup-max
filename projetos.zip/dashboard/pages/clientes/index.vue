<template>
  <v-container style="max-width: 1496px">
    <div class="text-center">
      <h1 style="color: #707070; font-size: 2.5rem">Clientes</h1>
    </div>
    <v-row>
      <v-col
        v-for="item in cardOptions"
        :key="item.title"
        cols="12"
        xs="12"
        sm="6"
        md="6"
        lg="3"
      >
        <v-hover v-slot="{ hover }">
          <NuxtLink :to="item.to" style="text-decoration: none; color: inherit">
            <v-card
              class="text-center rounded-xl"
              style="color: #707070"
              :class="{ 'on-hover': hover }"
              height="350px"
            >
              <div
                style="
                  display: flex;
                  flex-direction: column;
                  justify-content: center;
                  height: 100%;
                "
              >
                <h1>{{ item.title }}</h1>
              </div>
            </v-card>
          </NuxtLink>
        </v-hover>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      cardOptions: [
        {
          title: "Todos os usuários",
          to: "/clientes/todosClientes",
        },
        {
          title: "Compradores",
          to: "/clientes/compradores",
        },
        {
          title: "Leads",
          to: "/clientes/leads",
        },
        {
          title: "Perguntas & Reviews",
          to: "/clientes/perguntas&reviews",
        },
      ],
    };
  },
};
</script>

<style scoped>
.on-hover {
  transition: background 0.5s;
  background: #41433e;
  color: #aef82d !important;
}

.on-hover-icon {
  color: #aef82d !important;
}
</style>