<template>
  <v-container fluid>
    <TodosClientes />
  </v-container>
</template>

<script>
import TodosClientes from "@/components/clientes/todosClientes.vue";

export default {
  components: {
    TodosClientes,
  },
};
</script>

<style>
</style>