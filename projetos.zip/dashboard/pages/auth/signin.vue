<template>
  <v-row align="center" justify="center" class="mx-2" style="flex-direction:column">
    <div>
      <v-img height="250" :src="require('@/assets/img/logo.png')"></v-img>
    </div>
    <v-card
      width="360"
      class="elevation-4 text-left pa-5 rounded-xl"
      color="#41433E"
    >
      <v-card-text>
        <v-form>
          <v-text-field
            label="E-mail"
            name="E-mail"
            prepend-inner-icon="mdi-account"
            type="text"
            color="#aef82d"
            background-color="white"
            v-model="auth.email"
            solo
          ></v-text-field>

          <v-text-field
            label="Password"
            name="password"
            prepend-inner-icon="mdi-lock"
            type="password"
            color="#aef82d"
            background-color="white"
            v-model="auth.password"
            solo
          ></v-text-field>
        </v-form>
      </v-card-text>
      <v-card-actions class="text-center">
        <v-btn class="login-button" color="#aef82d" @click="login" block large>
          Login
        </v-btn>
        <!-- <v-btn class="reset-button" @click="forgotPassword" depressed large>
            Forgot Password
          </v-btn> -->
      </v-card-actions>
    </v-card>
    <v-snackbar :timeout="4000" v-model="snackbar" absolute bottom center>
      {{ snackbarText }}
    </v-snackbar>
  </v-row>
</template>

<script>
export default {
  data() {
    return {
      snackbar: false,
      snackbarText: "No error message",
      auth: {
        email: "",
        password: "",
      },
    };
  },
  methods: {
    login() {
      let that = this;
      this.$fire.auth
        .signInWithEmailAndPassword(this.auth.email, this.auth.password)
        .catch(function (error) {
          that.snackbarText = error.message;
          that.snackbar = true;
        })
        .then((user) => {
          //we are signed in
          $nuxt.$router.push("/");
        });
    },
    forgotPassword() {
      let that = this;
      this.$fire.auth
        .sendPasswordResetEmail(this.auth.email)
        .then(function () {
          that.snackbarText = "reset link sent to " + that.auth.email;
          that.snackbar = true;
        })
        .catch(function (error) {
          that.snackbarText = error.message;
          that.snackbar = true;
        });
    },
  },
};
</script>

<style>
</style>
