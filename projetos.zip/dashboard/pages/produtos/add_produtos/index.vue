<template>
  <div>
    <AddProduto />
  </div>
</template>

<script>
import AddProduto from "@/components/produtos/add_produtos.vue";
export default {
  components: {
    AddProduto,
  },
};
</script>

<style>
</style>