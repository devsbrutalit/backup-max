<template>
  <v-container fluid>
    <v-hover v-slot="{ hover }">
      <NuxtLink to="/produtos/categorias/addCategoria" style="text-decoration: none; color: inherit">
        <v-card
          class="my-5 text-center black--text ml-auto"
          style="max-width: 350px"
          :class="{ 'on-hover': hover }"
          elevation="0"
          color="transparent"
        >
          <v-card-actions
            style="
              display: flex;
              align-content: center;
              justify-content: center;
            "
          >
            <v-icon
              size="40"
              color="black"
              class="mr-2"
              :class="{ 'on-hover-icon': hover }"
            >
              mdi-plus-circle-outline
            </v-icon>
            <span style="font-size: 1.5rem">Add categoria</span>
          </v-card-actions>
        </v-card>
      </NuxtLink>
    </v-hover>

    <!-- Campo de pesquisa -->
    <!-- <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Ex: Procurar por nome ou slug"
          single-line
          hide-details
        ></v-text-field> -->
    <!-- Tabela com todas as categorias cadastradas -->
    <v-data-table
      :headers="headers"
      :items="allcategories"
      :search="search"
      class="elevation-1"
    >
      <!-- Template de Filtros -->
      <!-- Filtro de Nome -->
      <!-- Fim Template de Filtros -->

      <!-- Template para data de criação/dias passados -->
      <template v-slot:[`item.createdAt`]="{ item }">
        <div style="display: flex; flex-direction: column" class="py-2">
          <span>
            <v-icon small>mdi-timer-outline</v-icon>
            {{ daysPassed(item.createdAt) + " Dias atrás" }}
          </span>
          <span>
            <v-icon small>mdi-timer-outline</v-icon>
            {{ setDate(item.createdAt) }}
          </span>
        </div>
      </template>

      <template v-slot:[`item.actions`]="{ item }">
        <!--<v-icon @click="deleteProduct(item.productId)" color="red"> mdi-delete </v-icon> -->
        <NuxtLink :to="'/produtos/categorias/id=' + item.pk" style="text-decoration: none; color: inherit">
        <v-icon color="blue">
          mdi-pencil-circle
        </v-icon>
        </NuxtLink>
      </template>
    </v-data-table>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import AddCategoria from "@/components/produtos/categorias.vue";
// import Category from "@/repositories/Category";
export default {
  components: {
    AddCategoria,
  },
  computed: {
    ...mapGetters("categories", ["allcategories"]),
    category() {
      const todasCategorias = []
      todasCategorias.push(this.allcategories)

      // this.allcategories.map(item => {
      //   if(item.categorylvl2){
      //     item.categorylvl2.map(object => {
      //       console.log(object)
      //       todasCategorias.push(object);
      //     })
      //   }
      // })
      return todasCategorias;
    },
  },
  data() {
    return {
      // category: [],
      search: "",
      editItem: null,
      addcategoria: false,
      headers: [
        { text: "Nome", align: "center", value: "categoryName" },
        { text: "Slug", align: "center", value: "categorySlug" },
        { text: "CREATED AT", align: "center", value: "createdAt" },
        { text: "Actions", align: "center", value: "actions", sortable: false },
      ],
    };
  },
  methods: {
    ...mapActions("categories", ["loadCategories"]),
    editCategory(item) {
      console.log(item)
      this.editItem = item;
      this.addcategoria = !this.addcategoria;
    },
    eventEmit() {
      this.editItem = null;
    },
    // Função setDate retornando data formatada
    setDate(value) {
      const date = new Date(value);
      const data =
        date.getDate() +
        " " +
        date.toLocaleString("default", { month: "long" }) +
        " " +
        date.getFullYear();
      return data;
    },
    //  Função daysPassed retornando total de dias passados desde a data de criação
    daysPassed(value) {
      const date = new Date(value);
      const now = new Date();
      const Difference_In_Time = now.getTime() - date.getTime();
      const Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
      return parseInt(Difference_In_Days);
    },
  },
  created() {
    this.loadCategories();
  },
};
</script>

<style scoped>
.on-hover {
  transition: background 0.5s;
  background: #41433e !important;
  color: #aef82d !important;
}

.on-hover-icon {
  color: #aef82d !important;
}
</style>