<template>
  <div>
    <AddCategoria />
  </div>
</template>

<script>
import AddCategoria from "@/components/produtos/categorias.vue";
export default {
  components: {
    AddCategoria,
  },
};
</script>

<style>
</style>