<template>
  <div>
    <AddCategoria :editItem="this.editItem" />
  </div>
</template>

<script>
import AddCategoria from "@/components/produtos/categorias.vue";
import Category from "@/repositories/Category";
export default {
  components: {
    AddCategoria,
  },
  async asyncData({ params }) {
    const slug = params.categorySlug;

    const editItem = await Category.getCategorys().then((response) => {
      return response
        .json()
        .then((data) => {
          return data.find((item) => item.categorySlug === slug);
        })
        .catch((error) => console.log("error", error));
    });
    
    return { editItem };
  },
};
</script>

<style>
</style>