<template>
  <v-container fluid>
    <v-hover v-slot="{ hover }">
      <NuxtLink to="/produtos/atributos/addAtributo" style="text-decoration: none; color: inherit">
        <v-card
          class="my-5 text-center black--text ml-auto"
          style="max-width: 350px"
          :class="{ 'on-hover': hover }"
          elevation="0"
          color="transparent"
        >
          <v-card-actions
            style="
              display: flex;
              align-content: center;
              justify-content: center;
            "
          >
            <v-icon
              size="40"
              color="black"
              class="mr-2"
              :class="{ 'on-hover-icon': hover }"
            >
              mdi-plus-circle-outline
            </v-icon>
            <span style="font-size: 1.5rem">Add Atributo</span>
          </v-card-actions>
        </v-card>
      </NuxtLink>
    </v-hover>

    <!-- Campo de pesquisa -->
    <!-- <v-text-field
      v-model="search"
      append-icon="mdi-magnify"
      label="Ex: Procurar por nome"
      single-line
      hide-details
    ></v-text-field> -->

    <!-- Tabela com todas os atributos cadastrados -->
    <v-data-table
      :headers="headers"
      :items="attributes"
      :search="search"
      item-key="pk"
      :single-expand="true"
      :expanded.sync="expanded"
      show-expand
      hide-default-footer
      class="elevation-1"
    >
      <!-- Template da linha expandida -->
      <template v-slot:expanded-item="{ headers, item }">
        <td :colspan="headers.length">
          <div class="ma-auto">
            <v-simple-table style="background-color: transparent">
              <template v-slot:default>
                <thead>
                  <tr>
                    <th class="text-left">Name</th>
                    <th class="text-left">Qtn</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(attribute, i) in item.variations" :key="i">
                    <td>
                      <v-avatar
                        v-if="attribute.cor"
                        size="20"
                        :color="attribute.cor"
                        class="mr-2"
                        style="border: 1px solid black !important"
                      >
                      </v-avatar>
                      {{ attribute.name }}
                    </td>
                    <td>{{ attribute.qtn }}</td>
                  </tr>
                </tbody>
              </template>
            </v-simple-table>
          </div>
        </td>
      </template>

      <!-- Template da quatidade de itens associados -->
      <template v-slot:[`item.variations`]="{ item }">
        <span>{{ item.variations.length }}</span>
      </template>

      <!-- Template para data de criação/dias passados -->
      <template v-slot:[`item.createdAt`]="{ item }">
        <div style="display: flex; flex-direction: column" class="py-2">
          <span>
            <v-icon small>mdi-timer-outline</v-icon>
            {{ daysPassed(item.createdAt) + " Dias atrás" }}
          </span>
          <span>
            <v-icon small>mdi-timer-outline</v-icon>
            {{ setDate(item.createdAt) }}
          </span>
        </div>
      </template>

      <template v-slot:[`item.actions`]="{ item }">
        <v-icon @click="confirmDelete(item)" color="red"> mdi-delete </v-icon>
        <NuxtLink :to="'/produtos/atributos/' + item.pk " style="text-decoration: none; color: inherit">
        <v-icon color="blue">
          mdi-pencil-circle
        </v-icon>
        </NuxtLink>
      </template>
    </v-data-table>

    <!-- Modal para confirmação de deleção -->
    <v-dialog v-model="confirm" max-width="400" @keydown.esc="confirm = false">
      <v-card>
        <v-toolbar dark color="grey lighten-3" dense flat>
          <v-toolbar-title class="text-body-1 font-weight-bold grey--text">
            Confirmação para deleção de Atributo
          </v-toolbar-title>
        </v-toolbar>
        <v-card-text class="pa-4 black--text">
          Realmente deseja deletar esse atributo ?
        </v-card-text>
        <v-card-actions class="pt-3">
          <v-spacer></v-spacer>
          <v-btn
            v-if="!noconfirm"
            color="grey"
            text
            class="body-2 font-weight-bold"
            @click.native="confirm = false"
            >Cancel</v-btn
          >
          <v-btn
            color="primary"
            class="body-2 font-weight-bold"
            outlined
            @click.native="deleteItem()"
            >Deletar</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog
      v-model="productLinked"
      max-width="400"
      @keydown.esc="productLinked = false"
    >
      <v-card class="text-center pa-4">
        <v-icon color="orange">mdi-information</v-icon>
        <v-card-text class="black--text">
          Foi detectado que o atributo está presente em algum produto, por favor
          delete o produto primeiro.
        </v-card-text>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import { mapGetters } from "vuex";
import AddAttribute from "@/components/produtos/atributos.vue";
import Attribute from "@/repositories/Attribute";
export default {
  components: {
    AddAttribute,
  },
  data() {
    return {
      productLinked: false,
      confirm: false,
      noconfirm: false,
      itemDeleteTemp: null,
      componentKey: 0,
      expanded: [],
      attributes: [],
      search: "",
      editItem: null,
      addAttribute: false,
      headers: [
        { text: "Nome", align: "center", value: "attributeName" },
        { text: "Tipo", align: "center", value: "attributetype" },
        { text: "Qtd variações", align: "center", value: "variations" },
        // { text: "Qtd produtos", align: "center", value: "categoryQtd" },
        { text: "CREATED AT", align: "center", value: "createdAt" },
        { text: "Actions", align: "center", value: "actions", sortable: false },
        { value: "data-table-expand" },
      ],
    };
  },
  computed: {
    ...mapGetters("products", ["allproducts"]),
  },
  methods: {
    editAttribute(item) {
      this.editItem = Object.assign({}, item);
      this.componentKey += 1;
      this.addAttribute = !this.addAttribute;
    },

    // Função setDate retornando data formatada
    setDate(value) {
      const date = new Date(value);
      const data =
        date.getDate() +
        " " +
        date.toLocaleString("default", { month: "long" }) +
        " " +
        date.getFullYear();
      return data;
    },

    //  Função daysPassed retornando total de dias passados desde a data de criação
    daysPassed(value) {
      const date = new Date(value);
      const now = new Date();
      const Difference_In_Time = now.getTime() - date.getTime();
      const Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
      return parseInt(Difference_In_Days);
    },

    // Função setGraphic definindo valores para o grafico
    setGraphic() {
      this.attributes.find((object) => {
        if (object.attributeName) {
          this.chartOptions.labels.push(object.attributeName);
          this.series.push(object.variations.length);
        }
      });
    },

    // Função getCategorys retornado todas as categorias cadastradas
    getAttributes() {
      Attribute.getAttributes().then((response) => {
        response
          .json()
          .then((data) => {
            this.attributes = data;
            console.log(this.attributes);
            this.setGraphic();
          })
          .catch((error) => console.log("error", error));
      });
    },

    confirmDelete(item) {
      this.confirm = true;
      this.itemDeleteTemp = item;
    },

    deleteItem() {
      var status = false;
      this.allproducts.map((item) => {
        if (item.productVariations) {
          item.productVariations.find((object) => {
            object.productAttributes.find((o) => {
              this.itemDeleteTemp.variations.find((i) => {
                if (i.name === o.name) {
                  status = true;
                }
              });
            });
          });
        }
      });
      if (status) {
        this.confirm = false;
        this.itemDeleteTemp = {};
        this.productLinked = true;
      } else {
        Attribute.deleteAttribute(this.itemDeleteTemp).then((response) => {
          response
            .json()
            .then((data) => {
              console.log(data);
              this.itemDeleteTemp = {};
              this.confirm = false;
              this.getAttributes();
            })
            .catch((error) => console.log("error", error));
        });
      }
    },
  },
  
  created() {
    this.getAttributes();
  },
};
</script>

<style scoped>
@media screen and (max-width: 960px) {
  .positionMobileTable {
    order: 1;
    margin-bottom: 30px;
  }
  .positionMobileCards {
    order: 0;
    margin-bottom: 30px;
  }
}
.on-hover {
  transition: background 0.5s;
  background: #41433e !important;
  color: #aef82d !important;
}

.on-hover-icon {
  color: #aef82d !important;
}
</style>