<template>
  <div>
    <AddAtributo />
  </div>
</template>

<script>
import AddAtributo from "@/components/produtos/atributos.vue";
export default {
  components: {
    AddAtributo,
  },
};
</script>

<style>
</style>