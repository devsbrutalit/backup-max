<template>
  <div>
    <AddAtributo :editItem="this.editItem" />
  </div>
</template>

<script>
import AddAtributo from "@/components/produtos/atributos.vue";
import Attribute from "@/repositories/Attribute";
export default {
  components: {
    AddAtributo,
  },
  async asyncData({ params }) {
    const pk = params.pk;

    const editItem = await Attribute.getAttributes().then((response) => {
      return response
        .json()
        .then((data) => {
          return data.find((item) => item.pk === pk);
        })
        .catch((error) => console.log("error", error));
    });
    
    return { editItem };
  },
};
</script>

<style>
</style>