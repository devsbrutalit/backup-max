<template>
  <v-container style="max-width: 1496px">
    <div class="text-center">
      <h1 style="color: #707070; font-size: 2.5rem">Produtos</h1>
    </div>
    <v-row>
      <v-col
        v-for="item in cardOptions"
        :key="item.title"
        cols="12"
        xs="12"
        sm="6"
        md="6"
        lg="3"
      >
        <v-hover v-slot="{ hover }">
          <NuxtLink :to="item.to" style="text-decoration: none; color: inherit">
            <v-card
              class="text-center rounded-xl"
              style="color: #707070"
              :class="{ 'on-hover': hover }"
              height="350px"
            >
              <div
                style="
                  display: flex;
                  flex-direction: column;
                  justify-content: center;
                  height: 100%;
                "
              >
                <v-icon
                  :class="{ 'on-hover-icon': hover }"
                  size="71"
                  class="mb-5"
                >
                  {{ item.icon }}
                </v-icon>
                <h1>{{ item.title }}</h1>
              </div>
            </v-card>
          </NuxtLink>
        </v-hover>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      cardOptions: [
        {
          title: "Todos os Produtos",
          icon: "mdi-cube-outline",
          to: "/produtos/todosProdutos",
        },
        {
          title: "Add produtos",
          icon: "mdi-plus-circle-outline",
          to: "/produtos/add_produtos",
        },
        {
          title: "Categorias",
          icon: "mdi-layers-triple-outline",
          to: "/produtos/categorias",
        },
        {
          title: "Atributos",
          icon: "mdi-format-list-bulleted-type",
          to: "/produtos/atributos",
        },
      ],
    };
  },
};
</script>

<style scoped>
.on-hover {
  transition: background 0.5s;
  background: #41433e;
  color: #aef82d !important;
}

.on-hover-icon {
  color: #aef82d !important;
}
</style>