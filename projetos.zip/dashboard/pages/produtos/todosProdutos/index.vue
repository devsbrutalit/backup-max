<template>
  <v-container fluid class="pb-0">
    <v-row no-gutters>
      <!-- Tabela com todos os produtos cadastrados -->
      <v-col cols="12" md="9" class="positionMobileTable">
        <TodosProdutosTable />
      </v-col>

      <!-- Acesso para cadastro de produtos, categorias, atributos -->
      <v-col class="mx-auto positionMobileCards px-5" cols="12" sm="12" md="3">
        <ButtonsCreate />
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import { mapActions } from "vuex";
import TodosProdutosTable from "@/components/produtos/todosProdutos/tableProdutos.vue";
import ButtonsCreate from "@/components/produtos/todosProdutos/buttonsCreate.vue";
export default {
  components: {
    TodosProdutosTable,
    ButtonsCreate,
  },
  methods: {
    ...mapActions("products", ["loadProducts"]),
  },
  created() {
    this.loadProducts();
  },
};
</script>
<style scoped>
@media screen and (max-width: 960px) {
  .positionMobileTable {
    order: 1;
    margin-bottom: 30px;
  }
  .positionMobileCards {
    order: 0;
    margin-bottom: 30px;
  }
}
@media only screen and (min-width: 960px) {
  ::v-deep .dialogFull {
    height: 100% !important;
    width: 60% !important;
    position: fixed;
    left: 39% !important;
  }
}
::v-deep .dialog-right-transition-enter,
::v-deep .dialog-right-transition-leave-to {
  transform: translateX(100%) !important;
}
::v-deep .v-dialog:not(.v-dialog--fullscreen) {
  max-height: 100% !important;
}
</style>