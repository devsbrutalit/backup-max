<template>
  <div>
    <EditProduto :editItem="this.product" />
  </div>
</template>

<script>
import Product from "@/repositories/Product";
import EditProduto from "@/components/produtos/editProduto.vue";
export default {
  components: {
    EditProduto,
  },
  async asyncData({ params }) {
    const pk = params.pk;

    const product = await Product.getproducts().then((response) => {
      return response
        .json()
        .then((data) => {
          return data.find((item) => item.pk === pk);
        })
        .catch((error) => console.log("error", error));
    });
    console.log(product)

    return { product };
  },
};
</script>

<style>
</style>