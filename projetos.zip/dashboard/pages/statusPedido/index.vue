<template>
  <v-container>
    <div v-for="(orderItem, index) in getAllOrders" :key="index" class="my-5">
      <v-card v-if="orderItem.orderType != 'retirarLoja'">
        <v-row no-gutters>
          <v-col cols="4" class="ml-2 mt-2">
            <v-text-field
              class="inputTrack"
              style="max-width: 420px; border-radius: 0"
              v-model="orderItem.trackCode"
              label="Código de rastreamento"
              dense
              solo
              flat
            >
              <template v-slot:append-outer style="margin-top: 0">
                <v-btn
                  color="#83CB16"
                  tile
                  depressed
                  large
                  height="38px"
                  @click="trackCodeATT(orderItem.pk, orderItem.trackCode)"
                  >Inserir</v-btn
                >
              </template>
            </v-text-field>
          </v-col>
        </v-row>

        <v-row justify="center" no-gutters>
          <v-expansion-panels flat>
            <v-expansion-panel>
              <v-expansion-panel-header>
                Pedido: {{ orderItem.pk }}
              </v-expansion-panel-header>
              <v-expansion-panel-content>
                <v-data-table
                  :headers="ordersHeader"
                  :items="orderItem.products"
                  :items-per-page="5"
                  class="elevation-1"
                  hide-default-header
                  hide-default-footer
                >
                  <template v-slot:[`item.productName`]="{ item }">
                    <v-list-item>
                      <v-list-item-avatar tile>
                        <v-img
                          size="30"
                          class="mr-3 my-3"
                          height="60px"
                          width="30px"
                          contain
                          :src="
                            item.productVarImg
                              ? item.productVarImg[0]
                              : item.productPicture[0]
                          "
                        ></v-img>
                      </v-list-item-avatar>
                      <v-list-item-content>
                        {{ item.productName }}
                      </v-list-item-content>
                    </v-list-item>
                  </template>

                  <template v-slot:[`item.productValue`]="{ item }">
                    <span>{{
                      new Intl.NumberFormat("pt-BR", {
                        style: "currency",
                        currency: "BRL",
                      }).format(item.productValue)
                    }}</span>
                  </template>

                  <template v-slot:[`item.createdAt`]>
                    <span>{{
                      new Date(orderItem.createdAt).toLocaleDateString(
                        "pt-BR",
                        {
                          day: "2-digit",
                          month: "long",
                          year: "numeric",
                        }
                      )
                    }}</span>
                  </template>
                </v-data-table>

                <v-timeline align-top dense v-if="orderItem.trackObject">
                  <v-timeline-item
                    v-for="item in orderItem.trackObject"
                    :key="item.status"
                    color="blue"
                    class="text-left"
                    small
                  >
                    <strong>{{ item.status }}</strong>
                    <div class="caption">{{ item.local }}</div>
                    <div class="caption" v-if="item.origem">
                      Origem: {{ item.origem }}
                    </div>
                    <div class="caption" v-if="item.destino">
                      Destino: {{ item.destino }}
                    </div>
                    <div class="caption">{{ item.data }}</div>
                    <div class="caption">{{ item.hora }}</div>
                  </v-timeline-item>
                </v-timeline>
              </v-expansion-panel-content>
            </v-expansion-panel>
          </v-expansion-panels>
        </v-row>

        <v-btn color="#77E164" block @click="setItem(orderItem.pk)">
          Ver detalhes do pedido
        </v-btn>
      </v-card>

      <v-card v-else>
        <v-row justify="center" no-gutters>
          <v-expansion-panels flat>
            <v-expansion-panel>
              <v-expansion-panel-header>
                Pedido: {{ orderItem.pk }}
              </v-expansion-panel-header>
              <v-expansion-panel-content>
                <v-data-table
                  :headers="ordersHeader"
                  :items="orderItem.products"
                  :items-per-page="5"
                  class="elevation-1"
                  hide-default-header
                  hide-default-footer
                >
                  <template v-slot:[`item.productName`]="{ item }">
                    <v-row no-gutters class="mt-5 ml-3">
                      <v-checkbox
                        v-model="orderItem.orderReedem"
                        :disabled="orderItem.orderReedem === true"
                        class="mt-0 pt-0 mr-5"
                        label="Pedido retirado"
                        color="green"
                      ></v-checkbox>

                      <v-btn
                      :disabled="orderItem.orderReedem === true"
                        color="#83CB16"
                        tile
                        depressed
                        small
                        @click="orderReedem(orderItem.pk, orderItem.orderReedem)"
                      >
                        Salvar
                      </v-btn>
                    </v-row>
                    <v-list-item>
                      <v-list-item-avatar tile>
                        <v-img
                          size="30"
                          class="mr-3 my-3"
                          height="60px"
                          width="30px"
                          contain
                          :src="
                            item.productVarImg
                              ? item.productVarImg[0]
                              : item.productPicture[0]
                          "
                        ></v-img>
                      </v-list-item-avatar>
                      <v-list-item-content>
                        {{ item.productName }}
                      </v-list-item-content>
                    </v-list-item>
                  </template>

                  <template v-slot:[`item.productValue`]="{ item }">
                    <span>{{
                      new Intl.NumberFormat("pt-BR", {
                        style: "currency",
                        currency: "BRL",
                      }).format(item.productValue)
                    }}</span>
                  </template>

                  <template v-slot:[`item.createdAt`]>
                    <span>{{
                      new Date(orderItem.createdAt).toLocaleDateString(
                        "pt-BR",
                        {
                          day: "2-digit",
                          month: "long",
                          year: "numeric",
                        }
                      )
                    }}</span>
                  </template>
                </v-data-table>

                <v-timeline align-top dense v-if="orderItem.trackObject">
                  <v-timeline-item
                    v-for="item in orderItem.trackObject"
                    :key="item.status"
                    color="blue"
                    class="text-left"
                    small
                  >
                    <strong>{{ item.status }}</strong>
                    <div class="caption">{{ item.local }}</div>
                    <div class="caption" v-if="item.origem">
                      Origem: {{ item.origem }}
                    </div>
                    <div class="caption" v-if="item.destino">
                      Destino: {{ item.destino }}
                    </div>
                    <div class="caption">{{ item.data }}</div>
                    <div class="caption">{{ item.hora }}</div>
                  </v-timeline-item>
                </v-timeline>
              </v-expansion-panel-content>
            </v-expansion-panel>
          </v-expansion-panels>
        </v-row>

        <v-btn color="#77E164" block @click="setItem(orderItem.pk)">
          Ver detalhes do pedido
        </v-btn>
      </v-card>
    </div>

    <v-dialog
      v-model="detailVenda"
      max-width="50%"
      :fullscreen="$vuetify.breakpoint.smAndDown"
    >
      <VendaDetails :orderDetail="orderDetail" @close="closeModal" />
    </v-dialog>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import VendaDetails from "@/components/vendas/historicoVendas/vendaDetails";
import Pedido from "@/repositories/Orders";
export default {
  components: {
    VendaDetails,
  },
  computed: {
    ...mapGetters("orders", ["allorders"]),
    getAllOrders() {
      console.log(this.allorders);
      this.order = Object.assign(this.allorders);
      return this.order;
    },
  },
  data() {
    return {
      order: [],
      orderDetail: [],
      detailVenda: false,
      checkbox: false,
      ordersHeader: [
        { text: "Produto", value: "productName" },
        { text: "Valor", value: "productValue" },
        { text: "Quantidade", value: "Qtn" },
        { text: "Data", value: "createdAt" },
      ],
    };
  },
  methods: {
    ...mapActions("orders", ["loadOrders"]),
    orderReedem(item, status) {
      const Code = {
        orderId: item,
        status: status
      };
      Pedido.orderReedem(Code).then((response) => {
        response
          .json()
          .then(() => {
            location.reload();
          })
          .catch((error) => console.log("error", error));
      });
    },
    trackCodeATT(item, value) {
      this.loadingBtn = true;
      const Code = {
        orderId: item,
        trackCode: value,
      };
      Pedido.attTrackCode(Code).then((response) => {
        response
          .json()
          .then(() => {
            location.reload();
            this.loadingBtn = false;
          })
          .catch((error) => console.log("error", error));
      });
    },

    closeModal(value) {
      this.detailVenda = value;
    },

    async setItem(value) {
      await this.order.find((item) => {
        if (value === item.pk) {
          this.orderDetail = item;
        }
      });
      this.detailVenda = true;
    },
  },

  created() {
    this.loadOrders();
  },
};
</script>

<style scoped>
::v-deep .v-input__append-outer {
  margin: 0 !important;
}
::v-deep .inputTrack .v-input__slot {
  border: 1px solid rgb(128, 125, 125) !important;
}
</style>