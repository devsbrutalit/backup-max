<template>
  <v-container fluid>
    <v-card max-width="90%" class="ma-auto">
      <v-row align="center" justify="center" no-gutters class="mr-5">
        <v-col cols="12" sm="6">
          <v-card-title> Estatísticas do site</v-card-title>
        </v-col>
        <v-btn-toggle v-model="filtroDia" mandatory class="ml-auto">
          <v-btn @click="queryReport('7daysAgo')"> 1 sem </v-btn>
          <v-btn @click="queryReport('30daysAgo')"> 1 mês </v-btn>
        </v-btn-toggle>
      </v-row>
      <v-divider></v-divider>
      <v-row no-gutters>
        <v-col>
          <client-only>
            <div>
              <apexchart
                height="250"
                type="bar"
                :options="options"
                :series="series"
              ></apexchart>
            </div>
          </client-only>
        </v-col>
      </v-row>

      <v-divider></v-divider>
      <v-row no-gutters>
        <v-col>
          <v-card class="text-center" elevation="0">
            <v-card-title style="display: block; font-size: 16px">
              Visualizações hoje
            </v-card-title>
            <h2>{{ todaysVisited }}</h2>
          </v-card>
        </v-col>

        <v-col>
          <v-card
            class="text-center"
            elevation="0"
            tile
            style="
              border-right: 1px solid #d2d2d2;
              border-left: 1px solid #d2d2d2;
            "
          >
            <v-card-title style="display: block; font-size: 16px">
              Melhor dia em geral
            </v-card-title>
            <h2 class="mb-2">{{ bestDayVisited.total }} Visualizações</h2>
            <span>{{ bestDayVisited.date }}</span>
          </v-card>
        </v-col>

        <v-col>
          <v-card class="text-center" elevation="0">
            <v-card-title style="display: block; font-size: 16px">
              Visualizações até o momento
            </v-card-title>
            <h2>{{ totalVisited }}</h2>
          </v-card>
        </v-col>
      </v-row>
      <v-divider></v-divider>
    </v-card>
      
    <v-card max-width="50%" class="ma-auto mt-5">
      <v-card-title>Páginas mais populares</v-card-title>
      <v-divider></v-divider>
      <v-data-table
        :headers="headers"
        :items="pageViews"
        hide-default-footer
      ></v-data-table>
      <v-divider></v-divider>
    </v-card>

  </v-container>

</template>

<script>
import Report from "@/repositories/GoogleReport";
// import moment from "moment";

export default {
  data() {
    return {
      totalVisited: 0,
      todaysVisited: 0,
      bestDayVisited: {
        total: 0,
        date: "",
      },
      pageViews: [],
      headers: [
        { text: "Título", value: "title" },
        { text: "Visualizações", value: "view" },
      ],
      options: {
        chart: {
          id: "vuechart-example",
        },
        noData: {
          text: "Loading...",
          align: "center",
          verticalAlign: "middle",
          style: {
            color: "black",
            fontSize: "30px",
            fontFamily: "roboto",
          },
        },
      },
      series: [
        {
          name: "Usuários",
          data: [],
        },
      ],
    };
  },
  methods: {
    queryReport(item) {
      const filter = {
        filter: item,
      };
      Report.createReport(filter).then((response) => {
        response
          .json()
          .then((data) => {
            var dataFormated = [];
            this.pageViews = [];
            data.rowsUsers.map((item) => {
              var date = item[0];
              date =
                date.substring(0, 4) + "-" + date.substring(4, date.length);
              date =
                date.substring(0, 7) + "-" + date.substring(7, date.length);

              var mydate = this.$moment(date).format("DD/MM/YYYY");

              if (
                this.$moment(date).format("DD/MM/YYYY") ===
                this.$moment().format("DD/MM/YYYY")
              ) {
                this.todaysVisited = item[1];
              }

              if (this.bestDayVisited.total < item[1]) {
                this.bestDayVisited = {
                  total: item[1],
                  date: this.$moment(date).format("DD/MM/YYYY"),
                };
              }

              const newItem = {
                x: mydate,
                y: item[1],
              };

              dataFormated.push(newItem);
            });

            if (data.rowsPageViews) {
              data.rowsPageViews.map((item) => {
                const newItem = {
                  title: item[0],
                  view: item[1],
                };

                this.pageViews.push(newItem);
              });
            }
            this.series = [
              {
                data: dataFormated,
              },
            ];
            this.totalVisited = data.totalsUsers["ga:users"];
          })
          .catch((error) => console.log("error", error));
      });
    },
  },
  mounted() {
    this.queryReport("7daysAgo");
  },
};
</script>