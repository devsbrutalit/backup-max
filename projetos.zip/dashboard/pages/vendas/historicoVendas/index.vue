<template>
  <v-container fluid>
    <HistoricoInfoCard />
    <HistoricoVendas />
  </v-container>
</template>

<script>
import HistoricoVendas from "@/components/vendas/historicoVendas/historicoVendas.vue";
import HistoricoInfoCard from "@/components/vendas/historicoVendas/historicoInfoCards.vue";
export default {
  components: {
    HistoricoVendas,
    HistoricoInfoCard,
  },
};
</script>

<style>
</style>