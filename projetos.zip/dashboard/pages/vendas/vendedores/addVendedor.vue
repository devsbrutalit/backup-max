<template>
  <div>
    <AddVendedor />
  </div>
</template>

<script>
import AddVendedor from "@/components/vendas/vendedores/addVendedor.vue";
export default {
  components: {
    AddVendedor,
  },
};
</script>

<style>
</style>