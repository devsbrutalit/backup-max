<template>
  <v-container fluid>
    <AddButtonVendedor />

    <v-data-table
      :headers="headers"
      :items="getAllSellers"
      :search="search"
      class="elevation-1"
    >
      <template v-slot:[`header.actions`]>
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Ex: Nome, SKU, etc..."
          single-line
          hide-details
        ></v-text-field>
      </template>

      <!-- Template para ações -->
      <template v-slot:[`item.actions`]="{ item }">
        <!-- <v-icon @click="deleteProduct(item.productId)" color="red"> mdi-delete </v-icon> -->
        <NuxtLink
          :to="'/vendas/vendedores/editVendedor/' + item.pk"
          style="text-decoration: none; color: inherit"
        >
          <v-icon color="blue"> mdi-pencil-circle </v-icon>
        </NuxtLink>
        <v-icon @click="showSellerDetails(item)">mdi-eye</v-icon>
      </template>
    </v-data-table>
  </v-container>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import AddButtonVendedor from "@/components/vendas/vendedores/addButtonVendedor.vue";
export default {
  components: {
    AddButtonVendedor,
  },
  computed: {
    ...mapGetters("seller", ["allSellers"]),
    getAllSellers() {
      console.log(this.allSellers);
      return this.allSellers;
    },
  },
  data() {
    return {
      editItem: {},
      isEdit: false,
      search: "",
      name: [],
      qtd: [],
      value: [],
      status: [],
      createAt: [],
      vendas: [],
      filters: { PRODUTO: [], QTD: [], VALOR: [] },
      created: false,
      addproduto: false,
      addcategoria: false,
      addatributo: false,
      headers: [
        // { text: "imagem", align: "center", value: "imagem", sortable: false },
        { text: "Nome do vendedor", value: "name" },
        { text: "Vendas", value: "totalSold" },
        { text: "Unidade", value: "unidade" },
        {
          text: "Média de produtos por pedido",
          align: "start",
          value: "mediaItens",
        }, // filter: f => { return this.qtd.length > 0 ? this.qtd.includes(f) : this.allProductName }},
        { text: "Cupom ativo", align: "center", value: "cuponseller" }, //filter: f => { return this.value.length > 0 ? this.value.includes(f) : this.allProductName }},
        { text: "Meta do mês", align: "start", value: "meta" },
        { text: "Actions", align: "center", value: "actions", sortable: false },
      ],
    };
  },
  methods: {
    ...mapActions("seller", ["loadSellers"]),

    showSellerDetails(item) {
      this.$router.push({
        name: "vendas-meusVendedores-perfilVendedor",
        params: { id: "item.pk" },
        query: { seller: item },
      });
    },

    // showDetails(item) {
    //   this.showDetail = true;
    //   this.sellerDetails = item;
    // },
    // daysPassed(value) {
    //   const date = new Date(value);
    //   const now = new Date();
    //   const Difference_In_Time = now.getTime() - date.getTime();
    //   const Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
    //   return parseInt(Difference_In_Days);
    // },
  },
  created() {
    this.loadSellers();
  },
};
</script>

<style scoped>
</style>