<template>
  <v-container>
    <v-card elevation="0" style="background-color: transparent">
      <v-card-title
        class="text-center headline black--text"
        style="display: block"
      >
        Cadastrar Vendedor
      </v-card-title>
      <v-card-subtitle class="text-center black--text" style="display: block"
        >Adicione aqui os dados necessários para cadastrar um novo vendedor.
      </v-card-subtitle>

      <v-card-text>
        <v-row>
          <!-- Coluna Nome -->
          <v-col cols="12" sm="6" md="4">
            <v-text-field
              class="mt-2"
              name="name"
              label="Nome Completo"
              v-model="seller.name"
              :error-messages="nameErrors"
              @input="$v.seller.name.$touch()"
              @blur="$v.seller.name.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo CPF -->
          <v-col cols="12" sm="6" md="4">
            <v-text-field
              name="cpf"
              v-mask="'###.###.###-##'"
              v-model="seller.cpf"
              class="mt-2"
              label="CPF"
              :error-messages="cpfErrors"
              @input="$v.seller.cpf.$touch()"
              @blur="$v.seller.cpf.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo RG -->
          <v-col cols="12" sm="6" md="4">
            <v-text-field
              name="rg"
              v-mask="'###.###.###-##'"
              v-model="seller.rg"
              class="mt-2"
              label="RG"
              :error-messages="cpfErrors"
              @input="$v.seller.cpf.$touch()"
              @blur="$v.seller.cpf.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo CEP -->
          <v-col cols="12" sm="3">
            <v-text-field
              name="cep"
              v-model="seller.cep"
              v-mask="'#####-###'"
              label="CEP"
              :error-messages="cepErrors"
              @input="$v.seller.cep.$touch()"
              @blur="
                $v.seller.cep.$touch();
                GetAdress();
              "
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Cel -->
          <v-col cols="12" sm="5">
            <v-text-field
              name="cel"
              v-model="seller.cel"
              v-mask="'(##) #####-####'"
              label="Telefone Celular"
              :error-messages="celErrors"
              @input="$v.createCel.$touch()"
              @blur="$v.createCel.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Email -->
          <v-col cols="12" sm="4">
            <v-text-field
              name="email"
              v-model="seller.email"
              label="E-mail"
              :error-messages="emailErrors"
              @input="$v.seller.email.$touch()"
              @blur="$v.seller.email.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Endereço -->
          <v-col cols="12">
            <v-text-field
              name="endereco"
              v-model="seller.endereco"
              label="Endereço"
              readonly
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Numero -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="numero"
              v-model="seller.number"
              label="Número"
              :error-messages="numberErrors"
              @input="$v.seller.number.$touch()"
              @blur="$v.seller.number.$touch()"
              required
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Complemento -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="complemento"
              v-model="seller.complemento"
              label="Complemento"
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Bairro -->
          <v-col cols="12" sm="5">
            <v-text-field
              name="bairro"
              v-model="seller.bairro"
              label="Bairro"
              readonly
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Cidade -->
          <v-col cols="12" sm="4">
            <v-text-field
              name="cidade"
              v-model="seller.cidade"
              label="Cidade"
              readonly
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Estado -->
          <v-col cols="12" sm="3">
            <v-text-field
              name="estado"
              v-model="seller.estado"
              label="Estado"
              readonly
              outlined
            ></v-text-field>
          </v-col>

          <!-- Campo Cargo -->
          <v-col cols="12" sm="9">
            <v-text-field
              name="cargo"
              v-model="seller.cargo"
              label="Cargo"
              outlined
            ></v-text-field>
          </v-col>

          <!-- ID -->
          <v-col cols="12" sm="3">
            <v-text-field
              name="id"
              v-model="seller.id"
              label="ID"
              outlined
            ></v-text-field>
          </v-col>

          <!-- Meta mensal padrãp -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="meta"
              v-model="createMeta"
              label="Ponto de Referencia"
              outlined
            ></v-text-field>
          </v-col>

          <!-- Unidade -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="unidade"
              v-model="seller.unidade"
              label="Unidade"
              outlined
            ></v-text-field>
          </v-col>

          <!-- Dias de Trabalho -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="dayWork"
              v-model="seller.dayswork"
              label="Dias de trabalho"
              outlined
            ></v-text-field>
          </v-col>

          <!-- Horários de trabalho -->
          <v-col cols="12" sm="6">
            <v-text-field
              name="horario"
              v-model="seller.hourwork"
              label="Horários de trabalho"
              outlined
            ></v-text-field>
          </v-col>
        </v-row>
      </v-card-text>
      <v-card-actions>
        <v-container class="text-center">
          <v-btn
            color="white"
            width="45%"
            height="40px"
            class="mx-2 red--text"
            @click="backPage()"
          >
            Cancel
          </v-btn>
          <v-btn
            color="#41433e"
            style="color: #aef82d"
            width="45%"
            height="40px"
            class="mx-2"
            @click="submit()"
          >
            Atualizar vendedor
          </v-btn>
        </v-container>
      </v-card-actions>
    </v-card>
  </v-container>
</template>

<script>
import { required, maxLength, email } from "vuelidate/lib/validators";
import Seller from "@/repositories/Seller";
export default {
  validations: {
    seller:{
      name: { required },
      cpf: { required, maxLength: maxLength(14) },
      cep: { required },
      email: { required, email },
      number: { required },
    },
    createDate: { required },
    createCel: { required },
  },
  async asyncData({ params }) {
    const pk = params.pk;

    const seller = await Seller.getSellers().then((response) => {
      return response
        .json()
        .then((data) => {
          return data.find((item) => item.pk === pk);
        })
        .catch((error) => console.log("error", error));
    });
    console.log(seller);

    return { seller };
  },
  data() {
    return {
      createMeta: "",
      dialog: false,
      category: [],
    };
  },
  methods: {
    GetAdress() {
      fetch("https://viacep.com.br/ws/" + this.seller.cep + "/json/").then(
        (response) => {
          response
            .json()
            .then((data) => {
              this.seller.bairro = data.bairro;
              this.seller.endereco = data.logradouro;
              this.seller.cidade = data.localidade;
              this.seller.estado = data.uf;
            })
            .catch((error) => console.log("error", error));
        }
      );
    },
    validarCPF(createCPF) {
      createCPF = createCPF.replace(/[^\d]+/g, "");
      if (createCPF == "") return false;
      // Elimina CPFs invalidos conhecidos
      if (
        createCPF.length != 11 ||
        createCPF == "00000000000" ||
        createCPF == "11111111111" ||
        createCPF == "22222222222" ||
        createCPF == "33333333333" ||
        createCPF == "44444444444" ||
        createCPF == "55555555555" ||
        createCPF == "66666666666" ||
        createCPF == "77777777777" ||
        createCPF == "88888888888" ||
        createCPF == "99999999999"
      )
        return false;
      // Valida 1o digito
      var add = 0;
      for (var i = 0; i < 9; i++)
        add += parseInt(createCPF.charAt(i)) * (10 - i);
      var rev = 11 - (add % 11);
      if (rev == 10 || rev == 11) rev = 0;
      if (rev != parseInt(createCPF.charAt(9))) return false;
      // Valida 2o digito
      add = 0;
      for (i = 0; i < 10; i++) add += parseInt(createCPF.charAt(i)) * (11 - i);
      rev = 11 - (add % 11);
      if (rev == 10 || rev == 11) rev = 0;
      if (rev != parseInt(createCPF.charAt(10))) return false;
      return true;
    },
    backPage() {
      this.$router.push("/vendas/vendedores");
    },
    async submit() {
      const newSeller = {
        createName: this.seller.name,
        createCPF: this.seller.cpf,
        createRG: this.createRG,
        createCEP: this.seller.cep,
        createCel: this.seller.cel,
        createEmail: this.seller.email,
        createEndereco: this.seller.endereco,
        createNumber: this.seller.number,
        createComplemento: this.seller.complemento,
        createBairro: this.seller.bairro,
        createCidade: this.seller.cidade,
        createEstado: this.seller.estado,
        createCargo: this.seller.cargo,
        createID: this.seller.id,
        createMeta: this.createMeta,
        createUnidade: this.seller.unidade,
        createDayWork: this.seller.dayswork,
        createHorario: this.seller.hourwork,
        createCuponSeller: "TESTE",
      };

      // console.log(newSeller);

      // Seller.createSeller(newSeller).then((response) => {
      //   response
      //     .json()
      //     .then((data) => {
      //       console.log(data);
      //       setTimeout(() => {
      //         this.$router.push("/vendas/vendedores");
      //       }, 1500);
      //     })
      //     .catch((error) => console.log("error", error));
      // });
    },
  },
  computed: {
    emailErrors() {
      const errors = [];
      if (!this.$v.seller.email.$dirty) return errors;
      !this.$v.seller.email.email && errors.push("E-mail deve ser valido");
      !this.$v.seller.email.required && errors.push("Campo obrigatório");
      return errors;
    },
    nameErrors() {
      const errors = [];
      if (!this.$v.seller.name.$dirty) return errors;
      !this.$v.seller.name.required && errors.push("Insira um nome");
      return errors;
    },
    cpfErrors() {
      const errors = [];
      if (!this.$v.seller.cpf.$dirty) return errors;
      !this.$v.seller.cpf.required && errors.push("Campo obrigatório");
      !this.validarCPF(this.seller.cpf) && errors.push("CPF deve ser valido");
      return errors;
    },
    dateErrors() {
      const errors = [];
      if (!this.$v.createDate.$dirty) return errors;
      !this.$v.createDate.required && errors.push("Campo obrigatório");
      return errors;
    },
    cepErrors() {
      const errors = [];
      if (!this.$v.seller.cep.$dirty) return errors;
      !this.$v.seller.cep.required && errors.push("Campo obrigatório");
      return errors;
    },

    numberErrors() {
      const errors = [];
      if (!this.$v.seller.number.$dirty) return errors;
      !this.$v.seller.number.required && errors.push("Campo obrigatório");
      return errors;
    },
    celErrors() {
      const errors = [];
      if (!this.$v.createCel.$dirty) return errors;
      !this.$v.createCel.required && errors.push("Campo obrigatório");
      return errors;
    },
  },
};
</script>

<style>
</style>