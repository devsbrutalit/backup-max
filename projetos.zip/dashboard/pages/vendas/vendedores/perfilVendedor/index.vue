<template>
  <v-container fluid>
    <div style="display: flex; flex-wrap: nowrap">
      <div>
        <v-list-item two-line class="px-10">
          <v-list-item-avatar size="80">
            <img src="https://randomuser.me/api/portraits/women/81.jpg" />
          </v-list-item-avatar>

          <v-list-item-content>
            <v-list-item-title
              class="text-h5"
              v-text="seller.name"
            ></v-list-item-title>
            <v-list-item-subtitle v-text="seller.cargo"></v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </div>
      <div><span v-text="'Cadastrado em: ' + seller.createdAt"></span></div>
      <!-- <div><span v-text="'Status:' + seller.status"></span></div> -->
    </div>

    <v-row class="ma-0">
      <!-- Coluna Esqueda -->
      <v-col cols="12" sm="6" md="3" class="px-2">
        <!-- Card 1 -->
        <v-card class="ma-auto my-5">
          <v-list one-line>
            <v-list-item>
              <v-list-item-icon>
                <v-icon color="indigo"> mdi-phone </v-icon>
              </v-list-item-icon>

              <v-list-item-content>
                <v-list-item-title v-text="seller.cel"></v-list-item-title>
              </v-list-item-content>
            </v-list-item>

            <v-divider inset></v-divider>

            <v-list-item>
              <v-list-item-icon>
                <v-icon color="indigo"> mdi-email </v-icon>
              </v-list-item-icon>

              <v-list-item-content>
                <v-list-item-title v-text="seller.email"
                  >aliconnors@example.com</v-list-item-title
                >
              </v-list-item-content>
            </v-list-item>

            <v-divider inset></v-divider>

            <v-list-item>
              <v-list-item-icon>
                <v-icon color="indigo"> mdi-map-marker </v-icon>
              </v-list-item-icon>

              <v-list-item-content>
                <v-list-item-title>1400 Main Street</v-list-item-title>
                <v-list-item-subtitle>Orlando, FL 79938</v-list-item-subtitle>
              </v-list-item-content>
            </v-list-item>

            <v-divider inset></v-divider>

            <v-list-item>
              <v-list-item-icon>
                <v-icon color="indigo"> mdi-map-marker </v-icon>
              </v-list-item-icon>

              <v-list-item-content>
                <v-list-item-title v-text="seller.unidade"
                  >Caxias</v-list-item-title
                >
              </v-list-item-content>
            </v-list-item>

            <v-divider inset></v-divider>

            <v-list-item>
              <v-list-item-icon>
                <v-icon color="indigo"> mdi-map-marker </v-icon>
              </v-list-item-icon>

              <v-list-item-content>
                <v-list-item-title v-text="seller.id">Caxias</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </v-list>
        </v-card>

        <!-- Card com informações -->
        <v-card>
          <v-card-title primary-title> Recent Orders </v-card-title>
          <v-card-text class="mb-11">
            <v-list>
              <v-list-item>
                <v-list-item-avatar>
                  <v-img
                    src="https://cdn.vuetifyjs.com/images/john.png"
                  ></v-img>
                </v-list-item-avatar>
                <v-list-item-content>
                  <v-list-item-title class="title">
                    Ahamad Nazeri
                  </v-list-item-title>
                  <v-list-item-subtitle
                    >Preorder . at 13:27 . 1 Person</v-list-item-subtitle
                  >
                </v-list-item-content>
              </v-list-item>
            </v-list>
            <v-divider></v-divider>
            <v-list nav dense>
              <v-list-item-group color="primary">
                <v-list-item v-for="(item, i) in items" :key="i">
                  <v-list-item-avatar tile>
                    <v-img :src="item.src"></v-img>
                  </v-list-item-avatar>

                  <v-list-item-content>
                    <v-list-item-title
                      >{{ item.text }}
                      <span style="position: absolute; right: 3%"
                        >x{{ item.qtn }}</span
                      ></v-list-item-title
                    >
                  </v-list-item-content>
                </v-list-item>
              </v-list-item-group>
            </v-list>
          </v-card-text>
          <span class="ml-3">Total Price</span
          ><span style="position: absolute; right: 5%">$39.89</span>
          <v-card-actions class="mt-5 pb-5">
            <div class="ml-auto">
              <v-btn small color="primary">Cancel</v-btn>
              <v-btn small color="primary">Accept</v-btn>
            </div>
          </v-card-actions>
        </v-card>
      </v-col>
      <!-- Fim Coluna Esquerda -->
      <!-- Columa Meio -->
      <v-col cols="12" sm="6" md="9">
        <!-- Cards Informativos -->
        <v-row>
          <v-col
            v-for="info in infos"
            :key="info.title"
            cols="12"
            sm="6"
            md="4"
          >
            <v-card>
              <v-card-title v-text="info.title" class="pb-0"></v-card-title>
              <v-list-item>
                <v-list-item-content class="px-2">
                  <v-list-item-title
                    class="font-weight-bold"
                    style="font-size: 20px"
                    v-text="info.value"
                  ></v-list-item-title>
                </v-list-item-content>
                <v-list-item-avatar tile>
                  <v-icon large v-text="info.icon"></v-icon>
                </v-list-item-avatar>
              </v-list-item>
            </v-card>
          </v-col>
        </v-row>

        <!-- Grafico Meio -->
        <v-card class="mt-2 mb-5">
          <component
            v-if="chartTopVendedores"
            :is="chartTopVendedores"
          ></component>
        </v-card>
        <!-- Tabela de botões acesso rápido -->
        <v-card>
          <AcessoRapido />
        </v-card>
      </v-col>
      <!-- Fim Coluna Meio -->

      <!-- Coluna Direta -->
      <!-- <v-col cols="12" sm="6" md="3" class="px-2"> -->
        <!-- Card com produtos mais vendidos -->
        <!-- <v-card>
          <v-card-title primary-title> TOP SELLING </v-card-title> -->
          <!-- <v-card-actions>
            <v-btn text color="primary">View ALL</v-btn>
          </v-card-actions> -->
          <!-- <TopSelling /> -->
        <!-- </v-card> -->

        <!-- <v-card>
          <v-card-title primary-title> Recent Chats </v-card-title>
          <v-card-actions>
            <v-btn text color="primary">View ALL</v-btn>
          </v-card-actions>
        </v-card> -->
      <!-- </v-col> -->
      <!-- Fim Coluna Direta -->
    </v-row>
  </v-container>
</template>
<script>
export default {
  data() {
    return {
      id: "",
      seller: {},
      picker: new Date().toISOString().substr(0, 10),
      chartTopVendedores: null,
      chartInfo: null,
      items: [
        {
          text: "Seafood Salad",
          src:
            "https://i.pinimg.com/originals/87/2e/0f/872e0fbb84144901f4170e3f6a0230ae.jpg",
          qtn: 1,
        },
        {
          text: "Steak with Vegetables",
          src:
            "https://www.bordbia.ie/globalassets/bordbia.ie/lifestyle/recipes/bord-bia-recipe-images/steak-with-grilled-vegetables2.png",
          qtn: 1,
        },
        {
          text: "Vanilla Cappucino",
          src:
            "https://vacandlesupply.com/assets/images/frenchvanillacappuccino.jpg",
          qtn: 1,
        },
      ],
      infos: [
        {
          title: "Ranking geral",
          value: "1",
          icon: "mdi-calendar-today",
        },
        {
          title: "Total já vendido",
          value: "R$ 40.010,80",
          icon: "mdi-chart-histogram",
        },
        {
          title: "Cupom Ativo",
          value: "SARAKAM",
          icon: "mdi-ticket",
        },
      ],
    };
  },
  created() {
    this.id = this.$route.params.id;
    if (this.$route.query.seller) {
      this.seller = this.$route.query.seller;
    }
  },
};
</script>
