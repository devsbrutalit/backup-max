<template>
  <v-container fluid>
    <v-hover v-slot="{ hover }">
      <v-card
        class="my-5 text-center black--text ml-auto"
        style="max-width: 350px"
        :class="{ 'on-hover': hover }"
        elevation="0"
        color="transparent"
      >
        <NuxtLink
          to="/vendas/cupons/addCupom"
          style="text-decoration: none; color: inherit"
        >
          <v-card-actions
            style="
              display: flex;
              align-content: center;
              justify-content: center;
            "
          >
            <v-icon
              size="40"
              color="black"
              class="mr-2"
              :class="{ 'on-hover-icon': hover }"
            >
              mdi-plus-circle-outline
            </v-icon>
            <span style="font-size: 1.5rem">Add cupom</span>
          </v-card-actions>
        </NuxtLink>
      </v-card>
    </v-hover>
    <CuponsTable />
  </v-container>
</template>

<script>
import CuponsTable from "@/components/vendas/cupons/cuponsTable.vue";
import InfoCards from "@/components/vendas/cupons/infoCupons.vue";
export default {
  components: {
    CuponsTable,
    InfoCards,
  },
};
</script>


<style scoped>
.on-hover {
  transition: background 0.5s;
  background: #41433e !important;
  color: #aef82d !important;
}

.on-hover-icon {
  color: #aef82d !important;
}
</style>