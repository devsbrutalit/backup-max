<template>
  <div>
    <AddCupom />
  </div>
</template>

<script>
import AddCupom from "@/components/vendas/cupons/addCupom.vue";
export default {
  components: {
    AddCupom,
  },
};
</script>

<style>
</style>