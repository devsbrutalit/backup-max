<template>
  <v-container fluid>
    <TopVendas />
  </v-container>
</template>

<script>
import TopVendas from "@/components/vendas/topVendas/tabelaTopVendas.vue";
export default {
  components: {
    TopVendas,
  },
};
</script>

<style>
</style>