const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();
const { "v4": uuidv4 } = require('uuid')
const bcrypt = require('bcryptjs')
const salt = bcrypt.genSaltSync(10)
const s3bucket = new AWS.S3({
  Bucket: 'agoutiproductimg',
});

const itemTable = process.env.ITEM_TABLE

// Criação do Response
function response(statusCode, message) {
  return {
    headers: {
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*"
    },
    statusCode: statusCode,
    body: JSON.stringify(message)
  };
}

// Criando um vendedor
module.exports.createSeller = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);

  const seller = {
    pk: uuidv4(),
    sk: "Vendedor",
    name: reqBody.createName,
    email: reqBody.createEmail,
    cpf: reqBody.createCPF,
    rg: reqBody.createRG,
    cep: reqBody.createCEP,
    cel: reqBody.createCel,
    endereco: reqBody.createEndereco,
    cargo: reqBody.createCargo,
    id: reqBody.createID,
    meta: reqBody.createMeta,
    unidade: reqBody.createUnidade,
    dayswork: reqBody.createDayWork,
    hourwork: reqBody.createHorario,
    cuponseller: reqBody.createCuponSeller,
    totalSold: 0,
    createdAt: new Date().toISOString(),
  };

  return db
  .put({
    TableName: itemTable,
    Item: seller,
    ConditionExpression: "attribute_not_exists(pk)"
  })
  .promise()
  .then(() => {
    callback(null, response(201, seller));
  })
  .catch((err) => {
    callback(null, response(err.statusCode, 'Erro ao criar Vendedor'));
  });
};

// Editando um vendedor

// Resgatar todos os vendedores
module.exports.getAllSellers = (event, context, callback) => {
  const sk = "Vendedor";
  const IndexName = "gs1";
  var params = {

    KeyConditionExpression: 'sk = :sk',
    ExpressionAttributeValues: {
      ':sk': sk
    },
    TableName: itemTable,
    IndexName: IndexName,

  }

  return db
    .query(params)
    .promise()
    .then((res) => {
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};


// Restatar um vendedor  baseado em sua PK
module.exports.getSeller = (event, context, callback) => {
  const pk = event.pathParameters.pk;

  var params = {

    KeyConditionExpression: 'pk = :pk',
    ExpressionAttributeValues: {
      ':pk': pk
    },
    TableName: itemTable,

  }

  return db
    .query(params)
    .promise()
    .then((res) => {
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};
// Deletar um vendedor
