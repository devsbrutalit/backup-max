const { calcularPrecoPrazo, rastrearEncomendas } = require("correios-brasil");
const AWS = require('aws-sdk')
var axios = require('axios');
var qs = require('qs');
const lambda = new AWS.Lambda()
const convert = require('xml-js');
const QueryString = require("qs");
const sgMail = require('@sendgrid/mail')
sgMail.setApiKey('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')
const recursionLimit = 4
const db = new AWS.DynamoDB.DocumentClient();
const itemTable = process.env.ITEM_TABLE
require('dotenv').config()

// Criação do Response
function response(statusCode, message) {
  return {
    headers: {
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*"
    },
    statusCode: statusCode,
    body: JSON.stringify(message)
    // body: message
  };
}
module.exports.notificacao = async (event, context, callback) => {
  const reqBody = qs.parse(event.body);

  console.log(reqBody)

  var config = {
    method: 'get',
    // url: `https://ws.pagseguro.uol.com.br/v3/transactions/notifications/CB7E93-3F009A009ADC-C554CDEF9A84-EDA007?email=${process.env.ACESS_EMAIL}&token=${process.env.ACESS_TOKEN}`,
    // url: `https://ws.pagseguro.uol.com.br/v3/transactions/notifications/54D88A-CF0013001396-CEE497FF9302-B11403?email=${process.env.ACESS_EMAIL}&token=${process.env.ACESS_TOKEN}`,
    url: `https://ws.pagseguro.uol.com.br/v3/transactions/notifications/${reqBody.notificationCode}?email=${process.env.ACESS_EMAIL}&token=${process.env.ACESS_TOKEN}`,
    // url: `https://ws.sandbox.pagseguro.uol.com.br/v3/transactions/notifications/${reqBody.notificationCode}?email=devsbrutalit@gmail.com&token=5833881AFC964AB8A8A371BF5854FAB0`,
    headers: { 'Content-Type': 'application/json' }
  };

  console.log(config)

  await new Promise(resolve => {
    axios(config)
      .then(async (item) => {
        const itemToReturn = JSON.parse(convert.xml2json(item.data, { compact: true }))
        const { transaction } = itemToReturn;
        const { date, code, status, paymentMethod, grossAmount, installmentCount, items, sender, shipping, paymentLink } = transaction

        const id = items.item.id._text
        const idArray = id.split("_");

        var paramsOrder = {}
        paramsOrder = {
          Key: {
            pk: code._text,
            sk: "Order"
          },
          TableName: itemTable,
          ConditionExpression: 'attribute_exists(pk)',
          UpdateExpression: `set #orderDtl = :tra`,
          ExpressionAttributeNames: {
            '#orderDtl': 'orderDetails'
          },
          ExpressionAttributeValues: {
            ":tra": transaction,
          },
          ReturnValues: 'UPDATED_NEW'
        };

        await db
          .update(paramsOrder)
          .promise()
          .then((res) => {
            console.log('Pedido atualizado')
            console.log(res);
          })
          .catch((err) => callback(null, response(err.statusCode, err)));

        // console.log(id)
        // console.log(idArray[1])
        // console.log(transaction)

        var params = {}
        if (idArray[1] >= 0) {
          params = {
            Key: {
              pk: idArray[0],
              sk: "Produto"
            },
            TableName: itemTable,
            ConditionExpression: 'attribute_exists(pk)',
            UpdateExpression: `set #prodVar[${idArray[1]}].#prodQtd = #prodVar[${idArray[1]}].#prodQtd - :decr`,
            ExpressionAttributeNames: {
              '#prodVar': 'productVariations',
              '#prodQtd': 'productQtd'
            },
            ExpressionAttributeValues: {
              ":decr": 1,
            },
            ReturnValues: 'UPDATED_NEW'
          };
        } else {
          params = {
            Key: {
              pk: idArray[0],
              sk: "Produto"
            },
            TableName: itemTable,
            ConditionExpression: 'attribute_exists(pk)',
            UpdateExpression: `set #prodQtd = #prodQtd - :decr`,
            ExpressionAttributeNames: {
              '#prodQtd': 'productQtd'
            },
            ExpressionAttributeValues: {
              ":decr": 1,
            },
            ReturnValues: 'UPDATED_NEW'
          };
        }

        await db
          .update(params)
          .promise()
          .then((res) => {
            console.log('produto atualizado')
            console.log(res);
          })
          .catch((err) => callback(null, response(err.statusCode, err)));

        // Enviar Email
        function calcItemsValue() {
          var total = 0
          if (items.item.length > 1) {
            items.item.forEach(element => {
              total += parseFloat(element.amount._text)
            });
          } else {
            total += parseFloat(items.item.amount._text)
          }
          return (total.toFixed(2))
        };

        function listItems() {
          if (items.item.length > 1) {
            return items.item
          } else {
            return [items.item]
          }
        };

        var data = {
          name: sender.name._text,
          email: sender.email._text,
          items: listItems(),
          shipping: shipping,
          installmentCount: installmentCount,
          grossAmount: grossAmount,
          paymentMethod: paymentMethod,
          itemAmount: calcItemsValue(),
        }

        if (paymentMethod.type._text === "1") {


          if (status._text === "3") {
            var msg = {
              to: sender.email._text,
              from: 'suporte@agouti.com.br',
              template_id: "d-1ecb6092705044fcac9dcb7fc6a02cff",

              "dynamic_template_data": {
                "name": data.name,
                "email": data.email,
                "items": data.items,
                "shipping": data.shipping,
                "installmentCount": data.installmentCount,
                "grossAmount": data.grossAmount,
                "paymentMethod": data.paymentMethod,
                "itemAmount": data.itemAmount,
                "cartao": true
              }
            };
          }
        } else {
          var msg = {
            to: sender.email._text,
            from: 'suporte@agouti.com.br',
            template_id: "d-1ecb6092705044fcac9dcb7fc6a02cff",

            "dynamic_template_data": {
              "name": data.name,
              "email": data.email,
              "items": data.items,
              "shipping": data.shipping,
              "installmentCount": data.installmentCount,
              "grossAmount": data.grossAmount,
              "paymentMethod": data.paymentMethod,
              "itemAmount": data.itemAmount,
              "boleto": true,
              "paymentLink": paymentLink
            }
          };
        }
        templates = {
          confirm_order: "d-1ecb6092705044fcac9dcb7fc6a02cff",
          change_state_order: "d-bb2356704792408080f6cd7c76fb6f0b"
        };

        await sgMail
          .send(msg)
          .then(() => {
            console.log('Email sent')
          })
          .catch((error) => {
            console.error(error)
          })
        // var string = JSON.stringify(item.data)
        callback(null, response(201, 'Email sent'));
        resolve()
      })
      .catch((err) => {
        console.log(err)
        callback(null, response(error.response.status, error))
      });
  });
}

module.exports.consultarFrete = async (event, context, callback) => {
  const reqBody = JSON.parse(event.body);

  let args1 = {
    sCepOrigem: "22790701",
    sCepDestino: reqBody.cep,
    nVlPeso: reqBody.peso,
    nCdFormato: "1",
    nVlComprimento: reqBody.comprimento,
    nVlAltura: reqBody.altura,
    nVlLargura: reqBody.largura,
    nCdServico: ["04014"], //Array com os códigos de serviço
    nVlDiametro: "0",
  };

  let args2 = {
    sCepOrigem: "22790701",
    sCepDestino: reqBody.cep,
    nVlPeso: reqBody.peso,
    nCdFormato: "1",
    nVlComprimento: reqBody.comprimento,
    nVlAltura: reqBody.altura,
    nVlLargura: reqBody.largura,
    nCdServico: ["04510"], //Array com os códigos de serviço
    nVlDiametro: "0",
  };
  var options = [];
  await calcularPrecoPrazo(args1).then((item) => {
    options.push(item)
  }).catch((err) => callback(null, response(err.statusCode, err)))
  await calcularPrecoPrazo(args2).then((item) => {
    options.push(item)
  }).catch((err) => callback(null, response(err.statusCode, err)))

  callback(null, response(201, options));
};

module.exports.rastrearPedido = async (event, context, callback) => {
  const reqBody = JSON.parse(event.body);

  let codRastreio = [reqBody.trackCode] // array de códigos de rastreios

  await rastrearEncomendas(codRastreio).then((item) => {
    callback(null, response(201, item));
  }).catch((err) => callback(null, response(err.statusCode, err)));
};


module.exports.getSession = (event, context, callback) => {

  var data = qs.stringify({
    'email': process.env.ACESS_EMAIL,
    'token': process.env.ACESS_TOKEN
    // 'email': "devsbrutalit@gmail.com",
    // 'token': "5833881AFC964AB8A8A371BF5854FAB0",
  });
  var config = {
    method: 'post',
    url: 'https://ws.pagseguro.uol.com.br/v2/sessions',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    data: data
  };

  // var data = JSON.parse(convert.xml2json(item.data, { compact: true }))
  return axios(config).then((item) => {
    var data = JSON.parse(convert.xml2json(item.data, { compact: true }))
    callback(null, response(201, data.session.id._text));
  }).catch((err) => {
    console.log(err.response.status)
    callback(null, response(err.response.status, err))
  })

}

module.exports.getPaymentMethods = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);

  var config = {
    method: 'get',
    url: `https://ws.pagseguro.uol.com.br/payment-methods?callback=callbackPaymentMethods&sessionId=${reqBody.sessionId}&amount=500.00&Accept=application/vnd.pagseguro.com.br.v1%2Bjson;charset=ISO-8859-1`,
    headers: { 'Content-Type': 'application/json' }
  };

  axios(config)
    .then((item) => {
      console.log(item.data)
      // var string = JSON.stringify(item.data)
      // console.log(string)
      callback(null, response(201, item.data));
    })
    .catch((err) => {
      console.log(err)
      // callback(null, response(error.response.status, error))
    });
}

module.exports.setCheckout = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)

  console.log(reqBody.QtdParcelas)
  console.log(reqBody.ValorParcelas)


  var newOrder = {
    'email': process.env.ACESS_EMAIL,
    'token': process.env.ACESS_TOKEN,
    // 'email': "devsbrutalit@gmail.com",
    // 'token': "5833881AFC964AB8A8A371BF5854FAB0",
    'paymentMode': 'default',
    'paymentMethod': 'creditCard',
    'receiverEmail': process.env.ACESS_EMAIL,
    // 'receiverEmail': "devsbrutalit@gmail.com",
    'currency': 'BRL',
    'extraAmount': '0.00',
    // MODIFICADO POR MAXJRRJ
    //'notificationURL': 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/notificacao',
    'reference': 'REF1234',
    'senderName': reqBody.NomeComprador,
    'senderCPF': reqBody.CPFComprador.replace(/[.-]+/g, ""),
    'senderAreaCode': reqBody.areaCode.replace(/[()]+/g, "").substring(0, 2),
    'senderPhone': reqBody.phoneNumber.replace(/[() -]+/g, "").substring(2, 11),
    'senderEmail': reqBody.senderEmail,
    // 'senderEmail': "c22848621441748974122@sandbox.pagseguro.com.br",
    'senderHash': reqBody.senderHash,
    'shippingAddressRequired': 'true',
    'shippingAddressStreet': reqBody.Endereco,
    'shippingAddressNumber': reqBody.Numero,
    'shippingAddressComplement': reqBody.Complemento,
    'shippingAddressDistrict': reqBody.Bairro,
    'shippingAddressPostalCode': reqBody.CEP,
    'shippingAddressCity': reqBody.Cidade,
    'shippingAddressState': reqBody.UF,
    'shippingAddressCountry': 'BRA',
    'shippingType': '2',
    'shippingCost': reqBody.shippingCost.replace(',', '.'),
    'creditCardToken': reqBody.creditCardToken,
    'installmentQuantity': reqBody.QtdParcelas,
    'installmentValue': reqBody.ValorParcelas,
    'noInterestInstallmentQuantity': '3', // a partir de quantas parcelas será cobrado juros
    'creditCardHolderName': reqBody.NomeCartao,
    'creditCardHolderCPF': reqBody.CPFCartao.replace(/[.-]+/g, ""),
    'creditCardHolderBirthDate': reqBody.dateBorn,
    'creditCardHolderAreaCode': reqBody.areaCodeCard.replace(/[()]+/g, "").substring(0, 2),
    'creditCardHolderPhone': reqBody.phoneNumberCard.replace(/[() -]+/g, "").substring(2, 11),
    'billingAddressStreet': reqBody.Endereco,
    'billingAddressNumber': reqBody.Numero,
    'billingAddressComplement': reqBody.Complemento,
    'billingAddressDistrict': reqBody.Bairro,
    'billingAddressPostalCode': reqBody.CEP,
    'billingAddressCity': reqBody.Cidade,
    'billingAddressState': reqBody.UF,
    'billingAddressCountry': 'BRA'
  }

  for (let index = 0; index < reqBody.ProductList.length; index++) {
    newOrder["itemId" + (index + 1)] = /*index + 1*/ reqBody.ProductList[index].pk + "_" + reqBody.ProductList[index].productIndex
    newOrder["itemDescription" + (index + 1)] = reqBody.ProductList[index].productsDetails
    newOrder["itemQuantity" + (index + 1)] = reqBody.ProductList[index].Qtn

    if (reqBody.ProductList[index].productValue != reqBody.ProductList[index].productValueDiscount) {
      newOrder["itemAmount" + (index + 1)] = reqBody.ProductList[index].productValueDiscount
    } else {
      newOrder["itemAmount" + (index + 1)] = reqBody.ProductList[index].productValue
    }
  }
  var data = qs.stringify(newOrder);
  var config = {
    method: 'post',
    url: 'https://ws.pagseguro.uol.com.br/v2/transactions/',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    data: data
  };

  return axios(config)
    .then((item) => {
      const itemToReturn = JSON.parse(convert.xml2json(item.data, { compact: true }))
      console.log(itemToReturn)
      callback(null, response(201, itemToReturn));
    })
    .catch(function (error) {
      console.log(error);
    });
};

module.exports.setBoleto = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)

  var newOrder = {
    'email': process.env.ACESS_EMAIL,
    'token': process.env.ACESS_TOKEN,
    // 'email': "devsbrutalit@gmail.com",
    // 'token': "5833881AFC964AB8A8A371BF5854FAB0",
    'paymentMode': 'default',
    'paymentMethod': 'boleto',
    'receiverEmail': process.env.ACESS_EMAIL,
    // 'receiverEmail': "devsbrutalit@gmail.com",
    'currency': 'BRL',
    // MODIFICADDO POR MAXJRRJ
    //'notificationURL': 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/notificacao',
    'reference': 'REF1234',
    'senderName': reqBody.NomeComprador,
    'senderCPF': reqBody.CPFComprador,
    'senderAreaCode': reqBody.areaCode.replace(/[()]+/g, "").substring(0, 2),
    'senderPhone': reqBody.phoneNumber.replace(/[() -]+/g, "").substring(2, 11),
    'senderEmail': reqBody.senderEmail,
    // 'senderEmail': "c22848621441748974122@sandbox.pagseguro.com.br",
    'senderHash': reqBody.senderHash,
    'shippingAddressRequired': 'true',
    'shippingAddressStreet': reqBody.Endereco,
    'shippingAddressNumber': reqBody.Numero,
    'shippingAddressComplement': reqBody.Complemento,
    'shippingAddressDistrict': reqBody.Bairro,
    'shippingAddressPostalCode': reqBody.CEP,
    'shippingAddressCity': reqBody.Cidade,
    'shippingAddressState': reqBody.UF,
    'shippingAddressCountry': 'BRA',
    'shippingType': '1',
    'shippingCost': reqBody.shippingCost.replace(',', '.'),
  }

  for (let index = 0; index < reqBody.ProductList.length; index++) {
    newOrder["itemId" + (index + 1)] = /*index + 1*/ reqBody.ProductList[index].pk + "_" + reqBody.ProductList[index].productIndex
    newOrder["itemDescription" + (index + 1)] = reqBody.ProductList[index].productsDetails
    newOrder["itemQuantity" + (index + 1)] = reqBody.ProductList[index].Qtn

    if (reqBody.ProductList[index].productValue != reqBody.ProductList[index].productValueDiscount) {
      newOrder["itemAmount" + (index + 1)] = reqBody.ProductList[index].productValueDiscount
    } else {
      newOrder["itemAmount" + (index + 1)] = reqBody.ProductList[index].productValue
    }
  }
  var data = qs.stringify(newOrder);
  var config = {
    method: 'post',
    url: 'https://ws.pagseguro.uol.com.br/v2/transactions/',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    data: data
  };

  return axios(config)
    .then((item) => {
      // console.log(JSON.stringify(convert.xml2json(response.data)));
      const itemToReturn = JSON.parse(convert.xml2json(item.data, { compact: true }))
      console.log(itemToReturn)
      callback(null, response(201, itemToReturn));
    })
    .catch(function (error) {
      console.log(error);
    });
};

module.exports.Checkout = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)

  var newOrder = {
    'currency': 'BRL',
    'extraAmount': '0.00',
    // MODIFICADO POR MAXJRRJ
    //'notificationURL': 'https://gbrn3ip8bb.execute-api.sa-east-1.amazonaws.com/dev/notificacao',
    'reference': 'REF1234',
    'senderName': reqBody.NomeComprador,
    'senderCPF': reqBody.CPFComprador,
    'senderAreaCode': '11',
    'senderPhone': '56273440',
    'senderEmail': reqBody.senderEmail,
    'shippingAddressRequired': 'true',
    'shippingAddressStreet': reqBody.Endereco,
    'shippingAddressNumber': reqBody.Numero,
    'shippingAddressComplement': reqBody.Complemento,
    'shippingAddressDistrict': reqBody.Bairro,
    'shippingAddressPostalCode': reqBody.CEP,
    'shippingAddressCity': reqBody.Cidade,
    'shippingAddressState': reqBody.UF,
    'shippingAddressCountry': 'BRA',
    'shippingType': '1',
    'shippingCost': reqBody.shippingCost.replace(',', '.'),
  }
  var Produtos = []

  for (let index = 0; index < reqBody.ProductList.length; index++) {
    newOrder["itemId" + (index + 1)] = index + 1,
      newOrder["itemDescription" + (index + 1)] = reqBody.ProductList[index].productsDetails,
      newOrder["itemAmount" + (index + 1)] = reqBody.ProductList[index].productValue,
      newOrder["itemQuantity" + (index + 1)] = reqBody.ProductList[index].Qtn
  }
  var data = qs.stringify(newOrder);
  var config = {
    method: 'post',
    url: `https://ws.pagseguro.uol.com.br/v2/checkout/?email=${process.env.ACESS_EMAIL}&token=${process.env.ACESS_TOKEN}`,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    data: data
  };

  return axios(config)
    .then((item) => {
      // console.log(JSON.stringify(convert.xml2json(response.data)));
      const itemToReturn = JSON.parse(convert.xml2json(item.data, { compact: true }))
      console.log(itemToReturn.checkout.code)
      callback(null, response(201, itemToReturn.checkout.code));
    })
    .catch(function (error) {
      console.log(error);
    });

  // axios(config).then(function (response) {
  //   console.log(JSON.stringify(response.data));
  //   var itemjson = JSON.parse(convert.xml2json(item.data, { compact: true }))
  //   callback(null, response(201, itemjson));
  // })
  //   .catch((err) => callback(null, response(err.statusCode, err)))
};