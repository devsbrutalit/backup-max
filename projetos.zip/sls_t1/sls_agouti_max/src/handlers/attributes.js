const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();
const { "v4": uuidv4 } = require('uuid')
const bcrypt = require('bcryptjs')
const salt = bcrypt.genSaltSync(10)
const s3bucket = new AWS.S3({
  Bucket: 'agoutiproductimg',
});

const itemTable = process.env.ITEM_TABLE

// Criação do Response
function response(statusCode, message) {
  return {
    headers: {
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*"
    },
    statusCode: statusCode,
    body: JSON.stringify(message)
  };
}

// Criar Atributo
module.exports.createAttribute = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)
  let attributeID = uuidv4()
  // Validação dos Campos do Body do Form
  if (
    !reqBody.attributeName ||
    reqBody.attributeName.trim() === ''

  ) {
    return callback(
      null,
      response(400, {
        error: 'Atributo deve ter nome'
      })
    );
  }

  // Construindo Objeto
  const attribute = {
    pk: attributeID,
    sk: "Atributo",
    attributeName: reqBody.attributeName,
    attributetype: reqBody.attributetype,
    variations: reqBody.variations,
    createdAt: new Date().toISOString(),
  }
  // callback(null, response(201, category))

  // Executando o PUT para Banco
  return db
    .put({
      TableName: itemTable,
      Item: attribute,
      ConditionExpression: 'attribute_not_exists(pk)',
    })
    .promise()
    .then(() => {
      callback(null, response(201, attribute));
    })
    .catch((err) => callback(null, response(err.statusCode, err)))

};

// Resgatar todos os Atributos
module.exports.getAllAttributes = (event, context, callback) => {
  const sk = "Atributo";
  const IndexName = "gs1";
  var params = {

    KeyConditionExpression: 'sk = :sk',
    ExpressionAttributeValues: {
      ':sk': sk
    },
    TableName: itemTable,
    IndexName: IndexName,

  }

  return db
    .query(params)
    .promise()
    .then((res) => {
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Atualizar um Atributo
module.exports.updateAttribute = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const attributeID = reqBody.attributeID;
  const { attributeName, variations } = reqBody;

  if (
    !reqBody
  ) {
    return callback(
      null,
      response(400, {
        error: 'Corpo da requisição vazio'
      })
    );
  }
  
  const params = {
    Key: {
      pk: attributeID,
      sk: "Atributo"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: 'set attributeName = :title, variations = :var',
    ExpressionAttributeValues: {
      ':title': reqBody.attributeName,
      ':var': reqBody.variations
    },
    ReturnValues: 'UPDATED_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      console.log(res);
      callback(null, response(200, res.Attributes));
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Delete um Atributo
module.exports.deleteAttribute = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)
  const attributeID = reqBody.pk;

  const params = {
    Key: {
      pk: attributeID,
      sk: "Atributo"
    },
    TableName: itemTable
  };
  return db
    .delete(params)
    .promise()
    .then(() =>
      callback(null, response(200, { message: 'Atributo excluído' }))
    )
    .catch((err) => callback(null, response(err.statusCode, err)));
};