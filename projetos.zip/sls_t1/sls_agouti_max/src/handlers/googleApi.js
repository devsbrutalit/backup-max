const { google } = require('googleapis')
require('dotenv').config()

// Criação do Response
function response(statusCode, message) {
  return {
    headers: {
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*"
    },
    statusCode: statusCode,
    body: JSON.stringify(message)
  };
}

const scopes = 'https://www.googleapis.com/auth/analytics.readonly'
const clientEmail = "agouti-report@agoutitest.iam.gserviceaccount.com"
const privateKey = "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDC2UQLN8afYbY4\nvkKu5Wj0nCOL796R/lYanNMaaGvs0/EJ7SaoWcLNgZWqv5en5zwlnYTV0xbkUnOp\ns4WtA+8gxAIb65QOCWqAhx13SRgqL9oOxTvlfci/ttJYD/3yUgmOSIxtkzDiPxJL\n75+7SCsKC3h03C7BDsEXLyK2DLk+sJVqXRzkySNr7glniFiuejojCN/G2SgY+4bJ\nIcIHIah7j1D2+H4+/zUGO3ng8/NpiFbi/jAO4neiE27tdRsBtWqgvbx97h3WNYPD\nWp1x3F/WGV49dni5ZTaHQA9G5j+txv+PjQ4i2hmXTbrVN2cuXZzuo2UFFg1csB22\n3nOZuIIHAgMBAAECggEADnyJxw28CjCBFEHtAkTTI1CSgf5w/Ui8DRl4xn9Z+s8d\nHiBQHfcieRX30yyQcW7LNX67GAysKIiKyeSrfRwMRNLd10aSCOMhVHH3Ol2oWsaY\n/z0hwWOzL7G/fMWfm0sHI9l3+1OUsFWBHj0wEoQAkywcJhASt87Jg1hBS+ixQxxL\nZ3gGzEU4BLe9G7Q+uJZ4UnS2qqPCPHNt2WPFzLB7k6WIB/nd35E2W+8ebM5xFg5Q\nD+EEmJd+KsklH1je3NNxR+eMqc2a/uD6Nv/SdKD4YTZaZxfRhCqO4U7LOINmzbio\nKR94CcsF1mPKqf5u9T8EHJQ3XSKTETVxh3fF/XZh9QKBgQD7En8HTkFCQMAi/SM1\n/1eSQfRIorZ2N5yHzhsil17C5tdiNm+6dueAiapeEGDyjhSh7FahYXFSVpYHORIl\nAhztQHcecuOoa12i6b6UUGZN3Xlk4SUu4UAAks7qPE10110BdKRuuBUyTtyPHqv1\nVWGJ+lHxImTuocDj2ehGl+8QhQKBgQDGrEa6webHCJF/knAlgPgacjGB0VY3c6IS\n0ufFoo1scZcIjHkCwQWA/Wv4buIvuQsy+FTjJ9reTIzvd8GMOb28HdklrqltpG2j\nU8M02KvYHYWX0sh4GzwW4nbYAIC2ZKQpCqrGY0duf6eSplTA26OoNwALmhXNR1iv\n5fuJfaf0GwKBgFgEaPHntisCxhi+A10Hsex9IKViHXMeFcrqL0sWI8tR38n3aX3F\n92xxVn95YHNH6eXGE6ypm2+RGTFZCYpdzkRCKEBNaI//a6kUJpKaCPNdJBSAdWeU\n4boRvWYSU9kVMu6ytH54HD4xtVKbHw93qiUT0ywksZuSqyt1ld9BnjZ9AoGAGeBm\ndfy7akEbclpIcRoTNp6ZBCeX6zEMcxc1SPCbKvzAh0SEnm81oE9huMH4g+6+Hq1p\noQyX3UxrLuWSOAltRQs+NUJCnx1DinpmeoOeHk/6DoRNyBcEBJcKk6e9HASPvSi+\nhYh4zVOjJ96yO0xgTJCdWOWA4XPhgUebM5VCQvECgYBUJ5LNM50sypGaxh7wsW9P\nT6XGzXc7o1mMHhfqGnmJwXXRyV6XPWKKKADS89XqOuTaEp6cnSUhtDLe3Px56lWx\nNAiucAUHWg1oX8u+9qVySARyP5IMP1ywk196B1LEiBNdnFgemhtzfVWEbSwZcZSK\nWVf75ZUaMeHq0MzqYgftPA==\n-----END PRIVATE KEY-----\n"
const jwt = new google.auth.JWT(clientEmail, null, privateKey, scopes)

const view_id = '242008331'

module.exports.googleReport = async (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  
  const startDate = reqBody.filter

  const respo = await jwt.authorize()
  const result = await google.analytics('v3').data.ga.get({
    'auth': jwt,
    'ids': 'ga:' + view_id,
    'start-date': startDate,
    'end-date': 'today',
    'metrics': 'ga:users',
    'dimensions': 'ga:date'
  })
  const resultPerPage = await google.analytics('v3').data.ga.get({
    'auth': jwt,
    'ids': 'ga:' + view_id,
    'start-date': startDate,
    'end-date': 'today',
    'metrics': 'ga:pageviews',
    'dimensions': 'ga:pagePath'
  })
  const { totalsForAllResults: resulTotal, rows: resultRows } = result.data
  const { totalsForAllResults: resultPerPageTotal, rows: resultPerPageRows } = resultPerPage.data

  const data = {
    totalsUsers: resulTotal,
    totalPageViews: resultPerPageTotal,
    rowsUsers: resultRows,
    rowsPageViews: resultPerPageRows,
  }

  callback(null, response(200, data))
  // console.dir(result.data)

}
