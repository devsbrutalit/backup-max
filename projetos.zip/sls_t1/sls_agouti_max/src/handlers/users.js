const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();
// var axios = require('axios');
// var qs = require('qs');
const convert = require('xml-js');
const { "v4": uuidv4 } = require('uuid')
const bcrypt = require('bcryptjs')
const salt = bcrypt.genSaltSync(10)
const s3bucket = new AWS.S3({
  Bucket: 'agoutiproductimg',
});

const itemTable = process.env.ITEM_TABLE

// Criação do Response
function response(statusCode, message) {
  return {
    headers: {
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*"
    },
    statusCode: statusCode,
    body: JSON.stringify(message)
  };
}

// Criar Usuario
module.exports.createUser = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);


  if (
    !reqBody.email ||
    reqBody.email.trim() === ''

  ) {
    return callback(
      null,
      response(400, {
        error: 'Email não pode estar vazio.'
      })
    );
  }
  const user = {
    pk: reqBody.userID,
    sk: "Cliente",
    email: reqBody.email,
    cpf: reqBody.cpf,
    name: reqBody.name,
    date: reqBody.date,
    cep: reqBody.cep,
    endereco: reqBody.endereco,
    cel: reqBody.cel,
    acceptTerm: reqBody.acceptTerm,
    receiverSettings: reqBody.receiverSettings,
    favoriteItens: [],
    createdAt: new Date().toISOString(),

  };

  return db
    .put({
      TableName: itemTable,
      Item: user,
      ConditionExpression: "attribute_not_exists(pk)"
    })
    .promise()
    .then(() => {
      callback(null, response(201, user));
    })
    .catch((err) => {

      callback(null, response(400, 'Email já cadastrado'));
    });
};

// Resgatar todos Clientes
module.exports.getAllUsers = (event, context, callback) => {
  const sk = "Cliente";
  const IndexName = "gs1";
  var params = {

    KeyConditionExpression: 'sk = :sk',
    ExpressionAttributeValues: {
      ':sk': sk
    },
    TableName: itemTable,
    IndexName: IndexName,

  }

  return db
    .query(params)
    .promise()
    .then((res) => {
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Resgatar apenas um usuario baseado em seu ID
module.exports.getUser = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)

  const pk = reqBody.pk

  var params = {

    FilterExpression: 'pk = :pk',
    ExpressionAttributeValues: {
      ':pk': pk
    },
    TableName: itemTable,
  }

  return db
    .scan(params)
    .promise()
    .then((res) => {
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Alterar dados cadastrais
module.exports.updateUser = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const pk = reqBody.userId;
  const { name, cep, endereco, cel } = reqBody;

  if (
    !reqBody
  ) {
    return callback(
      null,
      response(400, {
        error: 'Corpo da requisição vazio'
      })
    );
  }
  const params = {
    Key: {
      pk: pk,
      sk: "Cliente"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: 'set #name = :n, cep = :cep, endereco = :e, cel = :cel',
    ExpressionAttributeNames: {
      "#name": "name"
    },
    ExpressionAttributeValues: {
      ':n': reqBody.name,
      ':cep': reqBody.cep,
      ':e': reqBody.endereco,
      ':cel': reqBody.cel
    },
    ReturnValues: 'UPDATED_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      console.log(res);
      callback(null, response(200, res.Attributes));
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Update Favorito User
module.exports.updateFavUser = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const pk = reqBody.userId;
  const { favoriteItens } = reqBody;

  if (
    !reqBody
  ) {
    return callback(
      null,
      response(400, {
        error: 'Corpo da requisição vazio'
      })
    );
  }

  const params = {
    Key: {
      pk: pk,
      sk: "Cliente"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: 'set #favorite = list_append(#favorite, :vals)',
    ExpressionAttributeNames: {
      "#favorite": 'favoriteItens'
    },
    ExpressionAttributeValues: {
      ":vals": [reqBody.favoriteItens],
    },
    ReturnValues: 'UPDATED_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      console.log(res);
      callback(null, response(200, res.Attributes));
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Delete favorito de User
module.exports.deleteFavUser = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const pk = reqBody.userId;
  const { favoriteItens } = reqBody;

  if (
    !reqBody
  ) {
    return callback(
      null,
      response(400, {
        error: 'Corpo da requisição vazio'
      })
    );
  }

  const index = reqBody.favoriteItens
  const params = {
    Key: {
      pk: pk,
      sk: "Cliente"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: `remove  favoriteItens[${index}]`,
    ReturnValues: 'ALL_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      console.log(res);
      callback(null, response(200, res.Attributes));
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Alterar dados cadastrais
module.exports.updateUser = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const pk = reqBody.userId;
  const { name, cep, endereco, cel } = reqBody;

  if (
    !reqBody
  ) {
    return callback(
      null,
      response(400, {
        error: 'Corpo da requisição vazio'
      })
    );
  }
  const params = {
    Key: {
      pk: pk,
      sk: "Cliente"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: 'set #name = :n, cep = :cep, endereco = :e, cel = :cel',
    ExpressionAttributeNames: {
      "#name": "name"
    },
    ExpressionAttributeValues: {
      ':n': reqBody.name,
      ':cep': reqBody.cep,
      ':e': reqBody.endereco,
      ':cel': reqBody.cel
    },
    ReturnValues: 'UPDATED_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      console.log(res);
      callback(null, response(200, res.Attributes));
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

//Log IN
module.exports.logIn = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);


  if (
    !reqBody.email ||
    reqBody.email.trim() === ''

  ) {
    return callback(
      null,
      response(400, {
        error: 'Email não informado'
      })
    );
  }

  if (
    !reqBody.password ||
    reqBody.password.trim() === ''
  ) {
    return callback(
      null,
      response(400, {
        error: 'Senha não informada'
      })
    );
  }

  const params = {
    Key: {
      email: reqBody.email
    },
    TableName: itemTable
  }

  return db
    .get(params)
    .promise()
    .then((data) => {
      if (data) {
        let result = bcrypt.compareSync(reqBody.password, data.Item.password)
        if (result) {
          callback(null, response(200, data));
        } else {
          callback(null, response(401, 'Senha ou email incorretos'));
        }
      } else {
        callback(null, response(401, 'Senha ou email incorretos'));
      }
    })
    .catch((err) => callback(null, response(401, 'Senha ou email incorretos')));
};

module.exports.newAddress = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const pk = reqBody.userId;

  if (
    !reqBody
  ) {
    return callback(
      null,
      response(400, {
        error: 'Corpo da requisição vazio'
      })
    );
  }
  const params = {
    Key: {
      pk: pk,
      sk: "Cliente"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: 'set #end = list_append(#end, :e)',
    ExpressionAttributeNames: {
      "#end": "endereco"
    },
    ExpressionAttributeValues: {
      ':e': [reqBody.endereco],
    },
    ReturnValues: 'UPDATED_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      console.log(res);
      callback(null, response(200, res.Attributes));
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

module.exports.createLead = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  let leadID = uuidv4()


  if (
    !reqBody.email ||
    reqBody.email.trim() === ''

  ) {
    return callback(
      null,
      response(400, {
        error: 'Email não pode estar vazio.'
      })
    );
  }
  const user = {
    pk: leadID,
    sk: "Lead",
    email: reqBody.email,
    createdAt: new Date().toISOString(),
  };

  return db
    .put({
      TableName: itemTable,
      Item: user,
      ConditionExpression: "attribute_not_exists(pk)"
    })
    .promise()
    .then(() => {
      callback(null, response(201, user));
    })
    .catch((err) => {

      callback(null, response(400, 'Email já cadastrado'));
    });
};

module.exports.getLeads = (event, context, callback) => {
  const sk = "Lead";
  const IndexName = "gs1";
  var params = {

    KeyConditionExpression: 'sk = :sk',
    ExpressionAttributeValues: {
      ':sk': sk
    },
    TableName: itemTable,
    IndexName: IndexName,

  }

  return db
    .query(params)
    .promise()
    .then((res) => {
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};