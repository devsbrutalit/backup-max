const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();
const { "v4": uuidv4 } = require('uuid')
const bcrypt = require('bcryptjs')
const salt = bcrypt.genSaltSync(10)
const s3bucket = new AWS.S3({
  Bucket: 'agoutiproductimg',
});

const itemTable = process.env.ITEM_TABLE
// const itemTable = "awsAgout-prod"

// Criação do Response
function response(statusCode, message) {
  return {
    headers: {
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*"
    },
    statusCode: statusCode,
    body: JSON.stringify(message)
  };
}

// Criação produto Novo
module.exports.createProduct = async (event, context, callback) => {
  const reqBody = JSON.parse(event.body)

  let productId = uuidv4()

  // Validação dos Campos do Body do Form
  if (
    !reqBody.productName ||
    reqBody.productName.trim() === ''

  ) {
    return callback(
      null,
      response(400, {
        error: 'Produto deve ter nome'
      })
    );
  }

  if (
    !reqBody.productCtg ||
    reqBody.productCtg.trim() === ''

  ) {
    return callback(
      null,
      response(400, {
        error: 'Produto deve ter categoria '
      })
    );
  }

  // callback(null, response(201, reqBody))

  // Construindo Objeto
  var product = {}
  if (reqBody.productVariations) {
    product = {
      pk: productId,
      sk: "Produto",
      productName: reqBody.productName,
      // productMarca: reqBody.productMarca,
      productCtg: reqBody.productCtg,
      productCtg1: reqBody.productCtg1,
      productSku: reqBody.productSku,
      productDescription: reqBody.productDescription,
      productRelacionship: reqBody.productRelacionship,
      productRelacionshipType: reqBody.productRelacionshipType,
      productVariations: reqBody.productVariations,
      productShow: reqBody.productShow,
      productTag: reqBody.productTag,
      productRating: 0,
      productReview: [],
      createdAt: new Date().toISOString(),
    };

    // Salvando fotos no bucket
    for (i = 0; i < product.productVariations.length; i++) {
      if (product.productVariations[i].productPicture) {
        var { productPicture } = product.productVariations[i]
        let productListPicture = []
        await new Promise(async resolve => {

          for (const file of productPicture) {
            const productPictureKey = uuidv4();
            var base64result = file.image.split(',')[1];
            let decodedImage = Buffer.from(base64result, 'base64')

            let s3bucket = new AWS.S3({
              Bucket: 'agoutiproductimg',
            });

            var params = {
              Bucket: 'agoutiproductimg',
              Key: `${productPictureKey}.jpeg`,
              Body: decodedImage,
              ContentEncoding: 'base64',
              ContentType: `image/jpeg`,
            };

            try {
              const data = await s3bucket.putObject(params).promise()
              console.log(data)
              console.log("subiu no bucket")
              // MODIFICADO POR MAXJRRJ
              //let productIMGLink = 'https://agoutiproductimg.s3.amazonaws.com/' + productPictureKey + `.jpeg`

              var newProductPicture = {
                image: productIMGLink,
                mainImage: file.mainImage
              }

              productListPicture.push(newProductPicture)

            } catch (err) {
              console.log(err)
            }
          }
          product.productVariations[i].productPicture = productListPicture
          resolve()
        });
      }
    }

    return db
      .put({
        TableName: itemTable,
        Item: product,
        ConditionExpression: 'attribute_not_exists(pk)',
      })
      .promise()
      .then(() => {
        callback(null, response(200, product));
      })
      .catch((err) => callback(null, response(err.statusCode, err)))

  } else if (reqBody.productCombo) {
    product = {
      pk: productId,
      sk: "Produto",
      productName: reqBody.productName,
      // productMarca: reqBody.productMarca,
      productCtg: reqBody.productCtg,
      productCtg1: reqBody.productCtg1,
      productValue: reqBody.productValue,
      productSku: reqBody.productSku,
      productTag: reqBody.productTag,
      productQtd: reqBody.productQtd,
      productMinQtd: 2,
      productDiscount: reqBody.productDiscount,
      productValueDiscount: reqBody.productValueDiscount,
      productDescription: reqBody.productDescription,
      productPeso: reqBody.productPeso,
      productAltura: reqBody.productAltura,
      productLargura: reqBody.productLargura,
      productComprimento: reqBody.productComprimento,
      productRelacionshipType: reqBody.productRelacionshipType,
      productRelacionship: reqBody.productRelacionship,
      productCombo: reqBody.productCombo,
      productRating: 0,
      productReview: [],
      productShow: reqBody.productShow,
      createdAt: new Date().toISOString(),
    };

    // Executando o PUT para Banco
    if (reqBody.productPicture === []) {

      return db
        .put({
          TableName: itemTable,
          Item: product,
          ConditionExpression: 'attribute_not_exists(pk)',
        })
        .promise()
        .then(() => {
          callback(null, response(201, product));
        })
        .catch((err) => callback(null, response(err.statusCode, err)))

    } else {

      var productPicture = []

      for (i = 0; i < reqBody.productIMG.length; i++) {
        const productImgKey = uuidv4()
        let decodedImage = Buffer.from(reqBody.productIMG[i].file.base64, 'base64')

        let s3bucket = new AWS.S3({
          Bucket: 'agoutiproductimg',
        });

        var params = {
          Bucket: 'agoutiproductimg',
          Key: `${productImgKey}.jpeg`,
          Body: decodedImage,
          ContentEncoding: 'base64',
          ContentType: `image/jpeg`,
        };
        // console.log(params)
        try {
          const data = await s3bucket.putObject(params).promise()
          // console.log(data)
          console.log("subiu no bucket")
          let productIMGLink = 'https://agoutiproductimg.s3.amazonaws.com/' + productImgKey + `.jpeg`
          productPicture.push(productIMGLink)

        } catch (err) {
          console.log(err)
        }
      }
      // console.log(productPicture)
      product.productPicture = productPicture
      return db
        .put({
          TableName: itemTable,
          Item: product,
          ConditionExpression: 'attribute_not_exists(pk)',
        })
        .promise()
        .then(() => {
          callback(null, response(201, product));
        })
        .catch((err) => callback(null, response(err.statusCode, err)))

      // let decodedImage = Buffer.from(reqBody.roomPicture.replace(/^data:image\/\w+;base64,/, ""), 'base64')
      // let decodedImage = reqBody.productIMG[0].file.base64
      // const type = reqBody.roomPicture.split(';')[0].split('/')[1]
    }
  } else {

    product = {
      pk: productId,
      sk: "Produto",
      productName: reqBody.productName,
      // productMarca: reqBody.productMarca,
      productCtg: reqBody.productCtg,
      productCtg1: reqBody.productCtg1,
      productValue: reqBody.productValue,
      productSku: reqBody.productSku,
      productTag: reqBody.productTag,
      productQtd: reqBody.productQtd,
      productMinQtd: 2,
      productDiscount: reqBody.productDiscount,
      productValueDiscount: reqBody.productValueDiscount,
      productDescription: reqBody.productDescription,
      productPeso: reqBody.productPeso,
      productAltura: reqBody.productAltura,
      productLargura: reqBody.productLargura,
      productComprimento: reqBody.productComprimento,
      productRelacionship: reqBody.productRelacionship,
      productRelacionshipType: reqBody.productRelacionshipType,
      productRating: 0,
      productReview: [],
      productShow: reqBody.productShow,
      createdAt: new Date().toISOString(),
    };

    var productPictureList = []

    for (i = 0; i < reqBody.productPicture.length; i++) {

      const productImgKey = uuidv4()
      var base64result = reqBody.productPicture[i].image.split(',')[1];
      let decodedImage = Buffer.from(base64result, 'base64')

      let s3bucket = new AWS.S3({
        Bucket: 'agoutiproductimg',
      });

      var params = {
        Bucket: 'agoutiproductimg',
        Key: `${productImgKey}.jpeg`,
        Body: decodedImage,
        ContentEncoding: 'base64',
        ContentType: `image/jpeg`,
      };

      try {
        const data = await s3bucket.putObject(params).promise()
        console.log(data)
        console.log("subiu no bucket")
        let productIMGLink = 'https://agoutiproductimg.s3.amazonaws.com/' + productImgKey + `.jpeg`

        var newProductPictureObject = {
          image: productIMGLink,
          mainImage: reqBody.productPicture[i].mainImage
        }

        productPictureList.push(newProductPictureObject)

      } catch (err) {
        console.log(err)
      }
    }

    product.productPicture = productPictureList


    return db
      .put({
        TableName: itemTable,
        Item: product,
        ConditionExpression: 'attribute_not_exists(pk)',
      })
      .promise()
      .then(() => {
        callback(null, response(201, product));
      })
      .catch((err) => callback(null, response(err.statusCode, err)))

    // let decodedImage = Buffer.from(reqBody.roomPicture.replace(/^data:image\/\w+;base64,/, ""), 'base64')
    // let decodedImage = reqBody.productIMG[0].file.base64
    // const type = reqBody.roomPicture.split(';')[0].split('/')[1]
  }
};

// Resgatar todos os produtos
module.exports.getAllProducts = (event, context, callback) => {
  const sk = "Produto";
  const IndexName = "gs1";
  var params = {

    KeyConditionExpression: 'sk = :sk',
    ExpressionAttributeValues: {
      ':sk': sk
    },
    TableName: itemTable,
    IndexName: IndexName,

  }

  return db
    .query(params)
    .promise()
    .then((res) => {
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Resgatar apenas um produto baseado em seu ID
module.exports.getProduct = (event, context, callback) => {
  // const sk = "Produto"
  // const IndexName = "gs1";
  const pk = event.pathParameters.productId;



  var params = {
    // KeyConditionExpression: 'sk = :sk',
    KeyConditionExpression: 'pk = :pk',
    // FilterExpression: 'pk = :pk',
    ExpressionAttributeValues: {
      // ':sk': sk,
      ':pk': pk
    },
    TableName: itemTable,
    // IndexName: IndexName,

  }

  return db
    .query(params)
    .promise()
    .then((res) => {
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Atualizar um produto
module.exports.updateProduct = async (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const productId = reqBody.productId;

  if (reqBody.productVariations) {

    const { productVariations } = reqBody;
    var newProductVariations = [...productVariations]

    if (
      !reqBody
    ) {
      return callback(
        null,
        response(400, {
          error: 'Corpo da requisição vazio'
        })
      );
    }

    for (i = 0; i < productVariations.length; i++) {
      if (productVariations[i].productPicture) {
        var { productPicture } = productVariations[i]

        await new Promise(async resolve => {
          for (const [index, file] of productPicture.entries()) {
            if (file.image.startsWith("data:image")) {
              const productPictureKey = uuidv4();
              var base64result = file.image.split(',')[1];
              let decodedImage = Buffer.from(base64result, 'base64')

              let s3bucket = new AWS.S3({
                Bucket: 'agoutiproductimg',
              });

              var params = {
                Bucket: 'agoutiproductimg',
                Key: `${productPictureKey}.jpeg`,
                Body: decodedImage,
                ContentEncoding: 'base64',
                ContentType: `image/jpeg`,
              };
              try {
                const data = await s3bucket.putObject(params).promise()
                console.log(data)
                console.log("subiu no bucket")
                let productIMGLink = 'https://agoutiproductimg.s3.amazonaws.com/' + productPictureKey + `.jpeg`

                var newProductPicture = {
                  image: productIMGLink,
                  mainImage: file.mainImage
                }
                newProductVariations[i].productPicture[index] = newProductPicture
              } catch (err) {
                console.log(err)
              }
            }
            resolve()
          }
        });
      }
    }

    const params = {
      Key: {
        pk: productId,
        sk: "Produto"
      },
      TableName: itemTable,
      ConditionExpression: 'attribute_exists(pk)',
      UpdateExpression: 'set productName = :title, productCtg = :category, productSku = :sku, productDescription = :description, productTag = :tag, productVariations = :variations, productShow = :show, productRelacionship = :relation, productRelacionshipType = :relationtype',
      ExpressionAttributeValues: {
        ':title': reqBody.productName,
        ':category': reqBody.productCtg,
        ':sku': reqBody.productSku,
        ':description': reqBody.productDescription,
        ':variations': newProductVariations,
        ':show': reqBody.productShow,
        ':tag': reqBody.productTag,
        ':relation': reqBody.productRelacionship,
        ':relationtype': reqBody.productRelacionshipType,
      },
      ReturnValues: 'UPDATED_NEW'
    };

    return db
      .update(params)
      .promise()
      .then((res) => {
        callback(null, response(200, res.Attributes));
      })
      .catch((err) => callback(null, response(err.statusCode, err)));
  } else {

    if (
      !reqBody
    ) {
      return callback(
        null,
        response(400, {
          error: 'Corpo da requisição vazio'
        })
      );
    }

    var productPictureList = [...reqBody.productPicture]

    for (i = 0; i < reqBody.productPicture.length; i++) {

      if (reqBody.productPicture[i].image.startsWith("data:image")) {

        const productImgKey = uuidv4()
        var base64result = reqBody.productPicture[i].image.split(',')[1];
        let decodedImage = Buffer.from(base64result, 'base64')

        let s3bucket = new AWS.S3({
          Bucket: 'agoutiproductimg',
        });

        var param = {
          Bucket: 'agoutiproductimg',
          Key: `${productImgKey}.jpeg`,
          Body: decodedImage,
          ContentEncoding: 'base64',
          ContentType: `image/jpeg`,
        };

        try {
          const data = await s3bucket.putObject(param).promise()
          console.log(data)
          console.log("subiu no bucket")
          let productIMGLink = 'https://agoutiproductimg.s3.amazonaws.com/' + productImgKey + `.jpeg`

          var newProductPictureObject = {
            image: productIMGLink,
            mainImage: reqBody.productPicture[i].mainImage
          }

          productPictureList[i] = newProductPictureObject

        } catch (err) {
          console.log(err)
        }
      }
    }

    const params = {
      Key: {
        pk: productId,
        sk: "Produto"
      },
      TableName: itemTable,
      ConditionExpression: 'attribute_exists(pk)',
      UpdateExpression: 'set productName = :title, productCtg = :category, productValue = :value, productDiscount = :discount, productValueDiscount = :valueDiscount, productSku = :sku, productQtd = :qtd, productTag = :tag, productDescription = :description, productPeso = :productPeso, productAltura = :productAltura, productLargura = :productLargura, productComprimento = :productComprimento, productPicture = :picture, productRelacionship = :relation, productRelacionshipType = :relationtype ',
      // productMarca = :marca
      ExpressionAttributeValues: {
        ':title': reqBody.productName,
        ':category': reqBody.productCtg,
        ':value': reqBody.productValue,
        ':discount': reqBody.productDiscount,
        ':valueDiscount': reqBody.productValueDiscount,
        ':sku': reqBody.productSku,
        ':qtd': reqBody.productQtd,
        ':tag': reqBody.productTag,
        // ':marca': reqBody.productMarca,
        ':description': reqBody.productDescription,
        ':productPeso': reqBody.productPeso,
        ':productAltura': reqBody.productAltura,
        ':productLargura': reqBody.productLargura,
        ':productComprimento': reqBody.productComprimento,
        ':picture': productPictureList,
        ':relation': reqBody.productRelacionship,
        ':relationtype': reqBody.productRelacionshipType,
      },
      ReturnValues: 'UPDATED_NEW'
    };

    return db
      .update(params)
      .promise()
      .then((res) => {
        // console.log(res);
        callback(null, response(200, res.Attributes));
      })
      .catch((err) => callback(null, response(err.statusCode, err)));
  }
};

// Delete um produto
module.exports.deleteProduct = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)
  const productId = reqBody.pk;

  // for (i = 0; i < reqBody.productPicture.length; i++) {
  //   var str = reqBody.productPicture[i]
  //   var res = str.split("/");
  //   var valueKey = res[3]

  //   let s3bucket = new AWS.S3({
  //     Bucket: 'agoutiproductimg',
  //   });

  //   var params = {
  //     Bucket: 'agoutiproductimg',
  //     Key: valueKey,
  //   };
  //   // console.log(params)
  //   s3bucket.deleteObject(params, function (err, data) {
  //     if (err) console.log(err, err.stack);  // error
  //     else console.log("Deletado do Bucket"); // deleted
  //   });
  // }

  const parametros = {
    Key: {
      pk: productId,
      sk: "Produto"
    },
    TableName: itemTable
  };
  return db
    .delete(parametros)
    .promise()
    .then(() =>
      callback(null, response(200, { message: 'Produto excluído' }))
    )
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Criando uma Avaliação do produto
module.exports.createReview = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const pk = reqBody.productId;
  const { title, text, rating, recomended } = reqBody;

  if (
    !reqBody
  ) {
    return callback(
      null,
      response(400, {
        error: 'Corpo da requisição vazio'
      })
    );
  }
  const newReview = {
    userId: reqBody.userId,
    title: reqBody.title,
    text: reqBody.text,
    rating: reqBody.rating,
    recomended: reqBody.recomended,
    createdAt: new Date().toISOString(),
  }
  const params = {
    Key: {
      pk: pk,
      sk: "Produto"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: 'set productReview = list_append(productReview, :values)',
    ExpressionAttributeValues: {
      ':values': [newReview]
    },
    ReturnValues: 'UPDATED_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      console.log(res);
      callback(null, response(200, res.Attributes));
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};