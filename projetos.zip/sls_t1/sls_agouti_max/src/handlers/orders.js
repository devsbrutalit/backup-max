const AWS = require('aws-sdk');
const { rastrearEncomendas } = require("correios-brasil");
const db = new AWS.DynamoDB.DocumentClient();
const { "v4": uuidv4 } = require('uuid')
const bcrypt = require('bcryptjs')
const salt = bcrypt.genSaltSync(10)
const s3bucket = new AWS.S3({
  Bucket: 'agoutiproductimg',
});

// const itemTable = process.env.ITEM_TABLE
const itemTable = "awsAgout-prod"

// Criação do Response
function response(statusCode, message) {
  return {
    headers: {
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*"
    },
    statusCode: statusCode,
    body: JSON.stringify(message)
  };
}

// Criando um Pedido
module.exports.createOrder = async (event, context, callback) => {
  const reqBody = JSON.parse(event.body);

  if (reqBody.cupon) {
    var params = {}
    params = {
      Key: {
        pk: reqBody.cupon.pk,
        sk: "Cupon"
      },
      TableName: itemTable,
      ConditionExpression: 'attribute_exists(pk)',
      UpdateExpression: `set #cQtd = #cQtd - :decr`,
      ExpressionAttributeNames: {
        '#cQtd': 'cuponQtd',
      },
      ExpressionAttributeValues: {
        ":decr": 1,
      },
      ReturnValues: 'UPDATED_NEW'
    };

    await db
      .update(params)
      .promise()
      .then((res) => {
        console.log('produto atualizado')
        console.log(res);
      })
      .catch((err) => callback(null, response(err.statusCode, err)));
  }
  const order = {
    pk: reqBody.orderDetails.code._text,
    sk: "Order",
    user: reqBody.user,
    products: reqBody.products,
    orderDetails: reqBody.orderDetails,
    cupon: reqBody.cupon,
    createdAt: new Date().toISOString(),
  }

  return db
    .put({
      TableName: itemTable,
      Item: order,
      ConditionExpression: "attribute_not_exists(pk)"
    })
    .promise()
    .then(() => {
      callback(null, response(201, order));
    })
    .catch((err) => {
      callback(null, response(err.statusCode, 'Erro ao gerar pedido'));
    });
};

// Atualizar um código de rastreio pedido
module.exports.updateOrder = async (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const orderId = reqBody.orderId;

  let codRastreio = [reqBody.trackCode] // array de códigos de rastreios
  var objetoRatreio = []

  await rastrearEncomendas(codRastreio).then((item) => {
    objetoRatreio = item[0]
  }).catch((err) => callback(null, response(err.statusCode, err)));


  const params = {
    Key: {
      pk: orderId,
      sk: "Order"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: 'set trackCode = :track, #trackObject = :object',
    ExpressionAttributeNames: {
      '#trackObject': 'trackObject',
    },
    ExpressionAttributeValues: {
      ':track': reqBody.trackCode,
      ':object': objetoRatreio,
    },
    ReturnValues: 'UPDATED_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      console.log(res);
      callback(null, response(200, res.Attributes));
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Atualizar pedido retirado na loja
module.exports.updateReedem = async (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const orderId = reqBody.orderId;

  const params = {
    Key: {
      pk: orderId,
      sk: "Order"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: 'set orderReedem = :status',
    ExpressionAttributeValues: {
      ':status': reqBody.status,
    },
    ReturnValues: 'UPDATED_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      console.log(res);
      callback(null, response(200, res.Attributes));
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Resgatando Pedido
module.exports.getAllOrders = (event, context, callback) => {
  const sk = "Order";
  const IndexName = "gs1";
  var params = {

    KeyConditionExpression: 'sk = :sk',
    ExpressionAttributeValues: {
      ':sk': sk
    },
    TableName: itemTable,
    IndexName: IndexName,

  }
  return db
    .query(params)
    .promise()
    .then((res) => {
      res.Items.map(async (obj) => {
        // console.log(obj)
        if (obj.trackCode) {
          var codRastreio = [obj.trackCode] // array de códigos de rastreios
          var objetoRatreio = []

          await rastrearEncomendas(codRastreio).then((item) => {
            objetoRatreio = item[0]
          }).catch((err) => callback(null, response(err.statusCode, err)));

          const params = {
            Key: {
              pk: obj.pk,
              sk: "Order"
            },
            TableName: itemTable,
            ConditionExpression: 'attribute_exists(pk), #trackObject != :object',
            UpdateExpression: 'set #trackObject = :object',
            ExpressionAttributeNames: {
              '#trackObject': 'trackObject',
            },
            ExpressionAttributeValues: {
              ':object': objetoRatreio,
            },
            ReturnValues: 'UPDATED_NEW'
          };

          db
            .update(params)
            .promise()
            .then((res) => {
              obj.trackObject = res.Attributes.trackObject
            })
            .catch((err) => callback(null, response(err.statusCode, err)));
        }
      })
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};