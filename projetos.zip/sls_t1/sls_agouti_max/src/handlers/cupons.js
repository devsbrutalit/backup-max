const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();
const { "v4": uuidv4 } = require('uuid')
const bcrypt = require('bcryptjs')
const salt = bcrypt.genSaltSync(10)
const s3bucket = new AWS.S3({
  Bucket: 'agoutiproductimg',
});

const itemTable = process.env.ITEM_TABLE

// Criação do Response
function response(statusCode, message) {
  return {
    headers: {
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*"
    },
    statusCode: statusCode,
    body: JSON.stringify(message)
  };
}

// Criando um cupom
module.exports.createCupon = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  var cuponExp = new Date().toISOString();
  // var numberOfDaysToExp = 30;
  // cuponExp.setDate(cuponExp.getDate() + numberOfDaysToExp)

  const cupon = {
    pk: uuidv4(),
    sk: "Cupon",
    cuponName: reqBody.cuponName,
    cuponCode: reqBody.cuponCode,
    cuponDiscount: reqBody.cuponDiscount,
    cupomPrivate: reqBody.cupomPrivate,
    cuponQtd: parseInt(reqBody.cuponQtd),
    cuponExp: reqBody.cuponExp,
    cuponStatus: "Ativo",
    createdAt: new Date().toISOString(),
  }

  return db
    .put({
      TableName: itemTable,
      Item: cupon,
      ConditionExpression: "attribute_not_exists(pk)"
    })
    .promise()
    .then(() => {
      callback(null, response(201, cupon));
    })
    .catch((err) => {
      callback(null, response(err.statusCode, 'Erro ao gerar cupon'));
    });
};

// Resgatar apenas um cupon
module.exports.getCupon = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)

  const sk = "Cupon";
  const IndexName = "gs1";
  const Value = reqBody.cuponCode

  var params = {

    KeyConditionExpression: 'sk = :sk',
    FilterExpression: 'cuponCode = :cuponCode',
    ExpressionAttributeValues: {
      ':sk': sk,
      ':cuponCode': Value
    },
    TableName: itemTable,
    IndexName: IndexName,

  }

  return db
    .query(params)
    .promise()
    .then((res) => {
      const myDate = new Date();
      const today = new Date(myDate);
      today.setHours(today.getHours() - 3);

      var cuponExpDate = new Date(res.Items[0].cuponExp)
      console.log(res.Items[0].cuponQtd)
      if (res.Items[0].cuponQtd === 0 || res.Items[0].cuponStatus === "Desativado") {
        callback(null, response(200, "Cupon não disponivel"));
      } else if (today > cuponExpDate) {

        const params = {
          Key: {
            pk: res.Items[0].pk,
            sk: "Cupon"
          },
          TableName: itemTable,
          ConditionExpression: 'attribute_exists(pk)',
          UpdateExpression: 'set #cuponStatus = :n',
          ExpressionAttributeNames: {
            "#cuponStatus": "cuponStatus"
          },
          ExpressionAttributeValues: {
            ':n': "Desativado",
          },
          ReturnValues: 'UPDATED_NEW'
        };

        db
          .update(params)
          .promise()
          .then(() => { })
          .catch((err) => callback(null, response(err.statusCode, err)));

        callback(null, response(200, "Cupon não disponivel"));
      } else {
        callback(null, response(200, res.Items));
      }
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Resgatar todos os Cupoms
module.exports.getAllCupons = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)
  const sk = "Cupon";
  const IndexName = "gs1";
  var params = {

    KeyConditionExpression: 'sk = :sk',
    ExpressionAttributeValues: {
      ':sk': sk
    },
    TableName: itemTable,
    IndexName: IndexName,

  }

  return db
    .query(params)
    .promise()
    .then((res) => {
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Alterar o status de um cupom
module.exports.changeStatusCupom = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)

  const params = {
    Key: {
      pk: reqBody.cupomId,
      sk: "Cupon"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: 'set #cuponStatus = :n',
    ExpressionAttributeNames: {
      "#cuponStatus": "cuponStatus"
    },
    ExpressionAttributeValues: {
      ':n': reqBody.newStatus,
    },
    ReturnValues: 'UPDATED_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      callback(null, response(201, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Delete um Cupom
module.exports.deleteCupom = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)
  const cupomId = reqBody.cupomId;

  const params = {
    Key: {
      pk: cupomId,
      sk: "Cupon"
    },
    TableName: itemTable
  };
  return db
    .delete(params)
    .promise()
    .then(() =>
      callback(null, response(200, { message: 'Cupom excluído' }))
    )
    .catch((err) => callback(null, response(err.statusCode, err)));
};