const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();
const { "v4": uuidv4 } = require('uuid')
const bcrypt = require('bcryptjs')
const salt = bcrypt.genSaltSync(10)
const s3bucket = new AWS.S3({
  Bucket: 'agoutiproductimg',
});

const itemTable = process.env.ITEM_TABLE

// Criação do Response
function response(statusCode, message) {
  return {
    headers: {
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*"
    },
    statusCode: statusCode,
    body: JSON.stringify(message)
  };
}

// Criar Categoria
module.exports.createCategory = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)
  let categoryID = uuidv4()
  // Validação dos Campos do Body do Form
  if (
    !reqBody.categoryName ||
    reqBody.categoryName.trim() === ''

  ) {
    return callback(
      null,
      response(400, {
        error: 'Categoria deve ter nome'
      })
    );
  }

  // Construindo Objeto
  // const category = {
  //   pk: categoryID,
  //   sk: "Categoria",
  //   categoryName: reqBody.categoryName,
  //   categorySlug: reqBody.categorySlug,
  //   createdAt: new Date().toISOString(),
  // }
  let category = {}
  if(reqBody.categorylvl1){
    category = {
      pk: categoryID,
      sk: "Categoria",
      categoryName: reqBody.categoryName,
      categorySlug: reqBody.categorySlug,
      categorylvl1: reqBody.categorylvl1,
      categoryType: "categorylvl2",
      createdAt: new Date().toISOString(),
    }
  }
  else if(reqBody.categorylvl2){
    category = {
      pk: categoryID,
      sk: "Categoria",
      categoryName: reqBody.categoryName,
      categorySlug: reqBody.categorySlug,
      categorylvl2: reqBody.categorylvl2,
      categoryType: "categorylvl3",
      createdAt: new Date().toISOString(),
    }
  }
  else if(reqBody.categorylvl3){
    category = {
      pk: categoryID,
      sk: "Categoria",
      categoryName: reqBody.categoryName,
      categorySlug: reqBody.categorySlug,
      categorylvl3: reqBody.categorylvl3,
      categoryType: "categorylvl4",
      createdAt: new Date().toISOString(),
    }
  }else{
    category = {
      pk: categoryID,
      sk: "Categoria",
      categoryName: reqBody.categoryName,
      categorySlug: reqBody.categorySlug,
      categoryType: "categoria",
      createdAt: new Date().toISOString(),
    }
  }
  // callback(null, response(201, category))

  // Executando o PUT para Banco
  return db
    .put({
      TableName: itemTable,
      Item: category,
      ConditionExpression: 'attribute_not_exists(pk)',
    })
    .promise()
    .then(() => {
      callback(null, response(201, category));
    })
    .catch((err) => callback(null, response(err.statusCode, err)))

};

// Resgatar todos as Categorias
module.exports.getAllCategorys = (event, context, callback) => {
  const sk = "Categoria";
  const IndexName = "gs1";
  var params = {

    KeyConditionExpression: 'sk = :sk',
    ExpressionAttributeValues: {
      ':sk': sk
    },
    TableName: itemTable,
    IndexName: IndexName,

  }

  return db
    .query(params)
    .promise()
    .then((res) => {
      callback(null, response(200, res.Items));

    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Atualizar um Categoria
module.exports.updateCategory = (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const categoryID = reqBody.categoryID;
  const { categoryName } = reqBody;

  if (
    !reqBody
  ) {
    return callback(
      null,
      response(400, {
        error: 'Corpo da requisição vazio'
      })
    );
  }

  // if (
  //   !id ||
  //   id.trim() === ''

  // ) {
  //   return callback(
  //     null,
  //     response(400, {
  //       error: 'id não identificado'
  //     })
  //   );
  // }

  const params = {
    Key: {
      pk: categoryID,
      sk: "Categoria"
    },
    TableName: itemTable,
    ConditionExpression: 'attribute_exists(pk)',
    UpdateExpression: 'set categoryName = :title',
    ExpressionAttributeValues: {
      ':title': reqBody.categoryName
    },
    ReturnValues: 'UPDATED_NEW'
  };

  return db
    .update(params)
    .promise()
    .then((res) => {
      console.log(res);
      callback(null, response(200, res.Attributes));
    })
    .catch((err) => callback(null, response(err.statusCode, err)));
};

// Delete uma Categoria
module.exports.deleteCategory = (event, context, callback) => {
  const reqBody = JSON.parse(event.body)
  const categoryID = reqBody.categoryID;

  const params = {
    Key: {
      pk: categoryID,
      sk: "Categoria"
    },
    TableName: itemTable
  };
  return db
    .delete(params)
    .promise()
    .then(() =>
      callback(null, response(200, { message: 'Categoria excluída' }))
    )
    .catch((err) => callback(null, response(err.statusCode, err)));
};

