const AWS = require('aws-sdk');
const db = new AWS.DynamoDB.DocumentClient();
const { "v4": uuidv4 } = require('uuid')
const bcrypt = require('bcryptjs')
const salt = bcrypt.genSaltSync(10)
const s3bucket = new AWS.S3({
  Bucket: 'agoutiproductimg',
});

const itemTable = process.env.ITEM_TABLE
// const itemTable = "awsAgout-prod"

// Criação do Response
function response(statusCode, message) {
  return {
    headers: {
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*"
    },
    statusCode: statusCode,
    body: JSON.stringify(message)
  };
}

// Atualizar um estoque de produto
module.exports.updateStock = async (event, context, callback) => {
  const reqBody = JSON.parse(event.body);
  const productId = reqBody.pk;

  if (reqBody.itemIndex) {

    const params = {
      Key: {
        pk: productId,
        sk: "Produto"
      },
      TableName: itemTable,
      ConditionExpression: 'attribute_exists(pk)',
      UpdateExpression: `set productVariations[${reqBody.itemIndex}].productQtd = :qtd ,productVariations[${reqBody.itemIndex}].productMinQtd = :minqtd`,
      ExpressionAttributeValues: {
        ':qtd': reqBody.productQtd,
        ':minqtd': reqBody.productMinQtd,
      },
      ReturnValues: 'UPDATED_NEW'
    };

    return db
      .update(params)
      .promise()
      .then((res) => {
        callback(null, response(200, res.Attributes));
      })
      .catch((err) => callback(null, response(err.statusCode, err)));
  } else {

    console.log(reqBody)

    const params = {
      Key: {
        pk: productId,
        sk: "Produto"
      },
      TableName: itemTable,
      ConditionExpression: 'attribute_exists(pk)',
      UpdateExpression: 'set productQtd = :qtd, productMinQtd = :minqtd',
      ExpressionAttributeValues: {
        ':qtd': reqBody.productQtd,
        ':minqtd': reqBody.productMinQtd,
      },
      ReturnValues: 'UPDATED_NEW'
    };

    return db
      .update(params)
      .promise()
      .then((res) => {
        callback(null, response(200, res.Attributes));
      })
      .catch((err) => callback(null, response(err.statusCode, err)));
  }
};
